<?php

/**
 * 404 error page
 *
 * @package DevkitComponents
 */

get_header();

esc_html_e('404 - not found', 'devkit-components');

get_footer();
