module.exports = {
	extends: './node_modules/@eightshift/frontend-libs/babel/babel.config.js',
};
