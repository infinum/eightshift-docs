import React from 'react';
import { DevkitComponentsEditor } from './components/devkit-components-editor';

export const DevKitComponents = (props) => <DevkitComponentsEditor {...props} />;
