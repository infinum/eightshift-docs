# Icons

We createad a bunch of custom icons to make everything look better and to enhance the editing experience.
These icons are designed to be used in different places inside the Block Editor.

## Block icons
These icons are used to easily identify a block. They can be seen in the block picker, in the block toolbar and in the options panel.

To use them, find the `icon` key in the block manifest, and to its `src` key assign a value that represents the icon's name.
For example:
```json
{
	"blockName": "my-block",
	...
	"icon": {
		"src": "es-example"
	},
}
```


## UI icons
These icons are used inside the user interface of the editor, mostly besides labels in the Options panel.

To use them, import them from eighshift-frontend-libs:
```js
import { icons } from '@eightshift/frontend-libs/scripts';
```

Then you can use them, for example in an `Icon` component from WP core:
```jsx
<Icon icon={icons.color} />
```
