import React, { useState } from 'react';
import { MarkdownView } from '../markdown-view';
import { ItemShowcase } from '../item-showcase';
import {
	Select,
	AsyncSelect,
	MultiSelect,
	AsyncMultiSelect,
	RSOption,
	RSSingleValue,
	RSMultiValue,
	RSDropdownIndicator,
	RSMultiValueRemove,
	RSClearIndicator,
	RSMultiValueContainer,
	icons,
} from '@eightshift/frontend-libs/scripts';
import { CodeBlock } from '../code-block';

export const SelectDocs = () => {
	const data = [
		{
			'label': 'Item 1',
			'value': 'item-1',
		},
		{
			'label': 'Item 2',
			'value': 'item-2',
		},
		{
			'label': 'Item 3',
			'value': 'item-3',
		},
		{
			'label': 'Item 4',
			'value': 'item-4',
		},
		{
			'label': 'Item 5',
			'value': 'item-5',
		},
		{
			'label': 'Item 6',
			'value': 'item-6',
		},
	];

	const getData = (inputValue) => {
		const filterData = ({ label }) => label.toLowerCase().includes(inputValue.toLowerCase());
		return new Promise((resolve) => {
			setTimeout(() => {
				if (!inputValue) {
					resolve(data.slice(0, 3));
				}

				resolve(data.filter(filterData));
			}, 3000);
		});
	};

	const CustomMenuOption = props => (
		<RSOption {...props}>
			<div className='es-h-spaced es-nested-size-4.5!'>
				<span role='img' className='es-line-h-0'>{icons.emptyCircle}</span>
				<span>{props.label}</span>
			</div>
		</RSOption>
	);

	const CustomValueDisplay = (props) => {
		return (
			<RSSingleValue {...props}>
				<span className='es-bg-admin-accent es-color-pure-white es-p-1 es-line-h-1 es-rounded-1.5 es-font-weight-500'>
					{props.children}
				</span>
			</RSSingleValue>
		);
	};

	const CustomMultiValueDisplay = (props) => {
		const colors = ['es-bg-red-500', 'es-bg-blue-500', 'es-bg-green-500', 'es-bg-yellow-500', 'es-bg-cool-gray-900'];
		const colorIndex = props.options.findIndex((option) => option.value === props.data.value) % colors.length;

		return (
			<RSMultiValue {...props}>
				<span className={`${colors[colorIndex]} es-color-pure-white es-p-1 es-line-h-1 es-rounded-1 es-font-weight-500`}>
					{props.children}
				</span>
			</RSMultiValue>
		);
	};

	const CustomDropdownIndicator = (props) => {
		return (
			<RSDropdownIndicator {...props}>
				<span className='es-nested-size-6! es-color-admin-accent! es-line-h-0! -es-ml-1'>
					{props.selectProps.menuIsOpen ? icons.arrowUpSquareAlt : icons.arrowDownSquareAlt}
				</span>
			</RSDropdownIndicator>
		);
	};

	const CustomMultiValueContainer = (props) => {
		const customProps = {
			...props,
			innerProps: {
				...props.innerProps,
				style: {
					backgroundColor: '#FCFAFF',
					borderColor: '#610BEF',
					flexDirection: 'row-reverse',
					padding: '0.125rem 0.25rem',
					borderRadius: '0.25rem',
				},
			}
		};
		return (
			<RSMultiValueContainer {...customProps} />
		);
	};

	const CustomMultiValueRemoveButton = (props) => {
		props.innerProps.className = 'es-color-admin-accent es-hover-nested-color-red-500 es-line-h-0';
		return (
			<RSMultiValueRemove {...props}>
				{icons.trashAlt}
			</RSMultiValueRemove>
		);
	};

	const CustomClearIndicator = (props) => {
		return (
			<RSClearIndicator {...props}>
				<span className='es-color-admin-accent es-hover-color-red-500 es-line-h-0 es-nested-size-6! -es-ml-1!'>{icons.errorCircleFill}</span>
			</RSClearIndicator>
		);
	};

	const [v, setV] = useState();
	const [v2, setV2] = useState();
	const [v3, setV3] = useState();
	const [v4, setV4] = useState([]);
	const [v5, setV5] = useState([]);

	return (
		<>
			<MarkdownView
				content={`# Select dropdowns
				Based on [react-select](https://react-select.com/home), this is a very powerful and customizable set of select components.`}
			/>

			<div className='devkit-component-config'>
				<ItemShowcase title='Single item select'>
					<Select
						icon={icons.emptyCircle}
						label='Pick an item'
						onChange={(v) => setV(v)}
						value={v}
						options={data}
						noBottomSpacing
					/>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`const data = [{label: 'Item 1', value: 'item-1'}, ...];

<Select
	icon={icons.emptyCircle}
	label='Pick an item'
	onChange={(value) => setValue(value)}
	value={value}
	options={data}
/>`}
				/>
			</div>

			<div className='devkit-component-config'>
				<ItemShowcase title='Disabling type-to-search'>
					<Select
						icon={icons.emptyCircle}
						label='Pick an item'
						onChange={(v) => setV(v)}
						value={v}
						options={data}
						noBottomSpacing
						noSearch
					/>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`const data = [{label: 'Item 1', value: 'item-1'}, ...];

<Select
	icon={icons.emptyCircle}
	label='Pick an item'
	onChange={(value) => setValue(value)}
	value={value}
	options={data}
	noSearch
/>`}
				/>
			</div>

			<div className='devkit-component-config'>
				<ItemShowcase title='Custom placeholder'>
					<Select
						icon={icons.emptyCircle}
						label='Pick an item'
						onChange={(v) => setV(v)}
						value={v}
						options={data}
						noBottomSpacing
						placeholder='Pick me!'
					/>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`const data = [{label: 'Item 1', value: 'item-1'}, ...];

<Select
	icon={icons.emptyCircle}
	label='Pick an item'
	onChange={(value) => setValue(value)}
	value={value}
	options={data}
	placeholder='Pick me!'
/>`}
				/>
			</div>

			<div className='devkit-component-config'>
				<ItemShowcase title='Clearable'>
					<Select
						icon={icons.emptyCircle}
						label='Pick an item'
						onChange={(v) => setV(v)}
						value={v}
						options={data}
						noBottomSpacing
						clearable
					/>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`const data = [{label: 'Item 1', value: 'item-1'}, ...];

<Select
	icon={icons.emptyCircle}
	label='Pick an item'
	onChange={(value) => setValue(value)}
	value={value}
	options={data}
	clearable
/>`}
				/>
			</div>

			<div className='devkit-component-config'>
				<ItemShowcase title='Close after selecting an option'>
					<Select
						icon={icons.emptyCircle}
						label='Pick an item'
						onChange={(v) => setV(v)}
						value={v}
						options={data}
						noBottomSpacing
						closeMenuAfterSelect
					/>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`const data = [{label: 'Item 1', value: 'item-1'}, ...];

<Select
	icon={icons.emptyCircle}
	label='Pick an item'
	onChange={(value) => setValue(value)}
	value={value}
	options={data}
	closeMenuAfterSelect
/>`}
				/>
			</div>

			<div className='devkit-component-config'>
				<ItemShowcase title='Return value instead of object' demoContainerClass='es-h-spaced es-gap-6!'>
					<div className='es-v-spaced es-w-full es-mb-auto'>
						<Select
							icon={icons.emptyCircle}
							label='Default'
							onChange={(v) => setV(v)}
							value={v}
							options={data}
							noBottomSpacing
						/>

						<div className='es-mt-3'>
							<p className='es-mt-0 es-mb-2 es-font-weight-500 es-text-3 es-color-cool-gray-500'>VALUE</p>
							<div
								// eslint-disable-next-line max-len
								className='es-shadow-inner es-rounded-1 es-p-2 es-border-cool-gray-50 es-text-2.75 es-color-cool-gray-600 es-bg-gray-50 es-line-h-1.5'
							>
								<code style={{ whiteSpace: 'pre-wrap' }}>{`{\n label: '${v?.label ?? ''}',\n value: '${v?.value ?? ''}\n}'`}</code>
							</div>
						</div>
					</div>

					<div className='es-v-spaced es-w-full es-mb-auto'>
						<Select
							icon={icons.emptyCircle}
							label={<code>simpleValue</code>}
							onChange={(v) => setV2(v)}
							value={v2}
							options={data}
							simpleValue
							noBottomSpacing
						/>

						<div className='es-mt-3'>
							<p className='es-mt-0 es-mb-2 es-font-weight-500 es-text-3 es-color-cool-gray-500'>VALUE</p>
							<div
								// eslint-disable-next-line max-len
								className='es-shadow-inner es-rounded-1 es-p-2 es-border-cool-gray-50 es-text-2.75 es-color-cool-gray-600 es-bg-gray-50 es-line-h-1.5'
							>
								<code>{`'${v2 ?? ''}'`}</code>
							</div>
						</div>
					</div>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`const data = [{label: 'Item 1', value: 'item-1'}, ...];

<Select
	icon={icons.emptyCircle}
	label='Pick an item'
	onChange={(value) => setValue(value)}
	value={value}
	options={data}
	simpleValue
/>`}
				/>
			</div>

			<div className='es-w-full es-h-px es-bg-cool-gray-100' />

			<div className='devkit-component-config'>
				<ItemShowcase
					title='Fetch options asynchronously'
					additionalPanels={[
						{
							title: 'Getting dynamic data',
							content: (
								<>
									<p className='es-mt-0 es-mb-2 es-p-0'>
										A <code>Promise</code> should be passed to the <code>loadOptions</code> property.
									</p>

									<p className='es-mt-0 es-mb-0 es-p-0'>
										The callback should return an array with objects containing <code>label</code> and <code>value</code> keys.
									</p>
								</>
							),
						},
						{
							title: 'Available options',
							content: <span>All options from <code>Select</code> are available, with the exception of <code>simpleValue</code></span>,
						}
					]}
				>
					<AsyncSelect
						icon={icons.emptyCircle}
						label='Pick an item'
						onChange={(v) => setV3(v)}
						value={v3}
						loadOptions={getData}
						noBottomSpacing
					/>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`const getData = (searchQuery) => {
	...

	return new Promise((resolve) => {
		resolve(yourData);
	});
};

<AsyncSelect
	icon={icons.emptyCircle}
	label='Pick an item'
	onChange={(value) => setValue(value)}
	value={value}
	loadOptions={getData}
/>`}
				/>
			</div>

			<div className='es-w-full es-h-px es-bg-cool-gray-100' />

			<div className='devkit-component-config'>
				<ItemShowcase
					title='Multiple item select'
					additionalPanels={[
						{
							title: 'Available options',
							content: <span>All options from <code>Select</code> are available</span>
						}
					]}
				>
					<MultiSelect
						icon={icons.emptyCircle}
						label='Select items'
						onChange={(v) => setV4(v)}
						value={v4}
						options={data}
						noBottomSpacing
					/>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`const data = [{label: 'Item 1', value: 'item-1'}, ...];

<MultiSelect
	icon={icons.emptyCircle}
	label='Select items'
	onChange={(value) => setValue(value)}
	value={value}
	options={data}
/>`}
				/>
			</div>

			<div className='es-w-full es-h-px es-bg-cool-gray-100' />

			<div className='devkit-component-config'>
				<ItemShowcase
					title='Multiple item select with asynchronous data loading'
					additionalPanels={[
						{
							title: 'Getting dynamic data',
							content: (
								<>
									<p className='es-mt-0 es-mb-2 es-p-0'>
										A <code>Promise</code> should be passed to the <code>loadOptions</code> property.
									</p>
									<p className='es-mt-0 es-mb-0 es-p-0'>
										The callback should return an array with objects containing <code>label</code> and <code>value</code> keys.
									</p>
								</>
							),
						},
						{
							title: 'Available options',
							content: <span>All options from <code>Select</code> are available, with the exception of <code>simpleValue</code></span>,
						}
					]}
				>
					<AsyncMultiSelect
						icon={icons.emptyCircle}
						label='Select items'
						onChange={(v) => setV5(v)}
						value={v5}
						loadOptions={getData}
						noBottomSpacing
					/>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`const getData = (searchQuery) => {
	...

	return new Promise((resolve) => {
		resolve(yourData);
	});
};

<AsyncMultiSelect
	icon={icons.emptyCircle}
	label='Select items'
	onChange={(value) => setValue(value)}
	value={value}
	options={data}
/>`}
				/>
			</div>

			<div className='es-w-full es-h-px es-bg-cool-gray-100' />

			<div className='devkit-component-config'>
				<ItemShowcase title='Custom dropdown icon'>
					<Select
						icon={icons.emptyCircle}
						label='Pick an item'
						onChange={(v) => setV(v)}
						value={v}
						options={data}
						noBottomSpacing
						customDropdownArrow={CustomDropdownIndicator}
					/>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`const data = [{label: 'Item 1', value: 'item-1'}, ...];

const CustomDropdownIndicator = (props) => {
	return (
		<RSDropdownIndicator {...props}>
			<span className='es-nested-size-6! es-color-admin-accent! es-line-h-0! -es-ml-1'>
				{props.selectProps.menuIsOpen ? icons.arrowUpSquareAlt : icons.arrowDownSquareAlt}
			</span>
		</RSDropdownIndicator>
	);
};

<Select
	icon={icons.emptyCircle}
	label='Pick an item'
	onChange={(value) => setValue(value)}
	value={value}
	options={data}
	customDropdownArrow={CustomDropdownIndicator}
/>`}
				/>
			</div>

			<div className='devkit-component-config'>
				<ItemShowcase title='Custom option display'>
					<Select
						icon={icons.emptyCircle}
						label='Pick an item'
						onChange={(v) => setV(v)}
						value={v}
						options={data}
						noBottomSpacing
						customMenuOption={CustomMenuOption}
					/>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`const data = [{label: 'Item 1', value: 'item-1'}, ...];

const CustomMenuOption = props => (
	<RSOption {...props}>
		<div className='es-h-spaced es-nested-size-4.5!'>
			<span role='img' className='es-line-h-0'>{icons.emptyCircle}</span>
			<span>{props.label}</span>
		</div>
	</RSOption>
);

<Select
	icon={icons.emptyCircle}
	label='Pick an item'
	onChange={(value) => setValue(value)}
	value={value}
	options={data}
	customMenuOption={CustomMenuOption}
/>`}
				/>
			</div>

			<div className='devkit-component-config'>
				<ItemShowcase title='Custom clear button'>
					<Select
						icon={icons.emptyCircle}
						label='Pick an item'
						onChange={(v) => setV(v)}
						value={v}
						options={data}
						noBottomSpacing
						clearable
						customClearIndicator={CustomClearIndicator}
					/>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`const data = [{label: 'Item 1', value: 'item-1'}, ...];

const CustomClearIndicator = (props) => {
	return (
		<RSClearIndicator {...props}>
			<span className='es-color-admin-accent es-hover-color-red-500 es-line-h-0 es-nested-size-6! -es-ml-1!'>{icons.errorCircleFill}</span>
		</RSClearIndicator>
	);
};

<Select
	icon={icons.emptyCircle}
	label='Pick an item'
	onChange={(value) => setValue(value)}
	value={value}
	options={data}
	clearable
	customClearIndicator={CustomClearIndicator}
/>`}
				/>
			</div>

			<div className='devkit-component-config'>
				<ItemShowcase title='Custom value display (single item select)'>
					<Select
						icon={icons.emptyCircle}
						label='Pick an item'
						onChange={(v) => setV(v)}
						value={v}
						options={data}
						noBottomSpacing
						customValueDisplay={CustomValueDisplay}
					/>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`const data = [{label: 'Item 1', value: 'item-1'}, ...];

const CustomValueDisplay = (props) => {
	return (
		<RSSingleValue {...props}>
			<span className='es-bg-admin-accent es-color-pure-white es-p-1 es-line-h-1 es-rounded-1.5 es-font-weight-500'>
				{props.children}
			</span>
		</RSSingleValue>
	);
};

<Select
	icon={icons.emptyCircle}
	label='Pick an item'
	onChange={(value) => setValue(value)}
	value={value}
	options={data}
	customValueDisplay={CustomValueDisplay}
/>`}
				/>
			</div>

			<div className='devkit-component-config'>
				<ItemShowcase title='Custom item remove icon (multiple item select)'>
					<MultiSelect
						icon={icons.emptyCircle}
						label='Pick an item'
						onChange={(v) => setV4(v)}
						value={v4}
						options={data}
						noBottomSpacing
						customValueRemove={CustomMultiValueRemoveButton}
					/>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`const data = [{label: 'Item 1', value: 'item-1'}, ...];

const CustomMultiValueRemoveButton = (props) => {
	return (
		<RSMultiValueRemove {...props}>
			<span className='es-color-admin-accent es-hover-color-red-500 es-line-h-0'>{icons.trashAlt}</span>
		</RSMultiValueRemove>
	);
};

<MultiSelect
	icon={icons.emptyCircle}
	label='Pick an item'
	onChange={(value) => setValue(value)}
	value={value}
	options={data}
	customValueRemove={CustomMultiValueRemoveButton}
/>`}
				/>
			</div>

			<div className='devkit-component-config'>
				<ItemShowcase title='Custom value display (multiple item select)'>
					<MultiSelect
						icon={icons.emptyCircle}
						label='Pick an item'
						onChange={(v) => setV4(v)}
						value={v4}
						options={data}
						noBottomSpacing
						customValueDisplay={CustomMultiValueDisplay}
					/>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`const data = [{label: 'Item 1', value: 'item-1'}, ...];

const CustomMultiValueDisplay = (props) => {
	const colors = ['es-bg-red-500', 'es-bg-blue-500', 'es-bg-green-500', 'es-bg-yellow-500', 'es-bg-cool-gray-900'];
	const colorIndex = props.options.findIndex((option) => option.value === props.data.value) % colors.length;

	return (
		<RSMultiValue {...props}>
			<span className={\`\${colors[colorIndex]} es-color-pure-white es-p-1 es-line-h-1 es-rounded-1 es-font-weight-500\`}>
				{props.children}
			</span>
		</RSMultiValue>
	);
};

<MultiSelect
	icon={icons.emptyCircle}
	label='Pick an item'
	onChange={(value) => setValue(value)}
	value={value}
	options={data}
	customValueDisplay={CustomMultiValueDisplay}
/>`}
				/>
			</div>

			<div className='devkit-component-config'>
				<ItemShowcase title='Custom item container (multiple item select)'>
					<MultiSelect
						icon={icons.emptyCircle}
						label='Pick an item'
						onChange={(v) => setV4(v)}
						value={v4}
						options={data}
						noBottomSpacing
						customValueContainer={CustomMultiValueContainer}
					/>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`const data = [{label: 'Item 1', value: 'item-1'}, ...];

const CustomMultiValueContainer = (props) => {
	const customProps = {
		...props,
		innerProps: {
			...props.innerProps,
			style: {
				backgroundColor: '#FCFAFF',
				borderColor: '#610BEF',
				flexDirection: 'row-reverse',
				padding: '0.125rem 0.25rem',
				borderRadius: '0.25rem',
			},
		}
	};
	return (
		<RSMultiValueContainer {...customProps} />
	);
};

<MultiSelect
	icon={icons.emptyCircle}
	label='Pick an item'
	onChange={(value) => setValue(value)}
	value={value}
	options={data}
	customValueContainer={CustomMultiValueContainer}
/>`}
				/>
			</div>
		</>
	);
};
