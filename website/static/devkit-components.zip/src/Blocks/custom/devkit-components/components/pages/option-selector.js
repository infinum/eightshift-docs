import React, { useState } from 'react';
import { MarkdownView } from '../markdown-view';
import { ItemShowcase } from '../item-showcase';
import { icons, OptionSelector } from '@eightshift/frontend-libs/scripts';
import { CodeBlock } from '../code-block';

export const OptionSelectorDocs = () => {
	const [value, setValue] = useState('option-1');

	const options = [
		{
			label: 'Option 1',
			value: 'option-1',
		},
		{
			label: 'Option 2',
			value: 'option-2',
		},
		{
			label: 'Option 3',
			value: 'option-3',
		},
	];

	const optionsWithIcons = [
		{
			label: 'Option 1',
			value: 'option-1',
			icon: icons.num1SquareAlt,
		},
		{
			label: 'Option 2',
			value: 'option-2',
			icon: icons.num2SquareAlt,
		},
		{
			label: 'Option 3',
			value: 'option-3',
			icon: icons.num3SquareAlt,
		},
	];

	return (
		<>
			<MarkdownView
				content={`# OptionSelector
				🚧 Work in progress

				A simple component for picking mutually exclusive options.`}
			/>

			<div className='es-display-flex es-flex-wrap es-gap-5!'>
				<ItemShowcase title='Basic component'>
					<OptionSelector
						label='Pick an option'
						icon={icons.emptyCircle}
						value={value}
						onChange={(value) => setValue(value)}
						options={options}
					/>

<OptionSelector
						label='Pick an option'
						icon={icons.emptyCircle}
						value={value}
						onChange={(value) => setValue(value)}
						options={optionsWithIcons}
					/>
				</ItemShowcase>

				<ItemShowcase title='Icon only'>
					<OptionSelector
						label='Pick an option'
						icon={icons.emptyCircle}
						value={value}
						onChange={(value) => setValue(value)}
						options={optionsWithIcons}
						iconOnly
					/>
				</ItemShowcase>

				<ItemShowcase title='No border'>
					<OptionSelector
						label='Pick an option'
						icon={icons.emptyCircle}
						value={value}
						onChange={(value) => setValue(value)}
						options={optionsWithIcons}
						border='none'
					/>
				</ItemShowcase>

				<ItemShowcase title='Label only on active'>
					<OptionSelector
						label='Pick an option'
						icon={icons.emptyCircle}
						value={value}
						onChange={(value) => setValue(value)}
						options={optionsWithIcons}
						labelOnlyOnActive
					/>
				</ItemShowcase>

				<ItemShowcase title='Alignment'>
					<OptionSelector
						label='Pick an option'
						icon={icons.emptyCircle}
						value={value}
						onChange={(value) => setValue(value)}
						options={optionsWithIcons}
						alignment='left'
						iconOnly
					/>

					<OptionSelector
						label='Pick an option'
						icon={icons.emptyCircle}
						value={value}
						onChange={(value) => setValue(value)}
						options={optionsWithIcons}
						alignment='right'
						iconOnly
					/>

					<OptionSelector
						label='Pick an option'
						icon={icons.emptyCircle}
						value={value}
						onChange={(value) => setValue(value)}
						options={optionsWithIcons}
						alignment='center'
						iconOnly
					/>

					<OptionSelector
						label='Pick an option'
						icon={icons.emptyCircle}
						value={value}
						onChange={(value) => setValue(value)}
						options={optionsWithIcons}
						alignment='stretch'
						iconOnly
					/>

					<OptionSelector
						label='Pick an option'
						icon={icons.emptyCircle}
						value={value}
						onChange={(value) => setValue(value)}
						options={optionsWithIcons}
						alignment='vertical'
					/>
				</ItemShowcase>
			</div>

			<CodeBlock
				language='jsx'
				code={`<OptionSelector
	label='Pick an option'
	icon={icons.emptyCircle}
	value={value}
	onChange={(value) => setValue(value)}
	options={options}

	// ----------------------------------------------------------------
	// Other examples, each example includes the props above this text.
	// ----------------------------------------------------------------

	// Icon only
	iconOnly

	// Label only on active
	labelOnlyOnActive

	// No border
	border='none'

	// Alignments
	alignment='left'
	alignment='right'
	alignment='center'
	alignment='vertical'
/>`}
			/>

		</>
	);
};
