import React from 'react';
import { MarkdownView } from '../markdown-view';
import { ItemShowcase } from '../item-showcase';
import { Control, icons } from '@eightshift/frontend-libs/scripts';
import { CodeBlock } from '../code-block';

export const BaseControlDocs = () => {
	return (
		<>
			<MarkdownView
				content={`# Control
				A standardized (not changing every WP version) replacement for Gutenberg's \`BaseControl\`.`}
			/>


			<div className='devkit-component-config'><ItemShowcase title='Label only'>
				<Control label='Label' noBottomSpacing>
					<div className='es-w-full es-h-24 es-bg-cool-gray-100 es-rounded-1' />
				</Control>
			</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<Control label='Label'>
	...
</Control>`}
				/>
			</div>

			<div className='devkit-component-config'>
				<ItemShowcase title='Help text'>
					<Control label='Label' help='Help text' noBottomSpacing>
						<div className='es-w-full es-h-24 es-bg-cool-gray-100 es-rounded-1' />
					</Control>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<Control label='Label' help='Help text'>
	...
</Control>`}
				/>
			</div>

			<div className='devkit-component-config'>
				<ItemShowcase title='Subtitle'>
					<Control label='Label' subtitle='Subtitle' noBottomSpacing>
						<div className='es-w-full es-h-24 es-bg-cool-gray-100 es-rounded-1' />
					</Control>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<Control label='Label' subtitle='Subtitle'>
	...
</Control>`}
				/>
			</div>

			<div className='devkit-component-config'>
				<ItemShowcase title='Icon'>
					<Control label='Label' icon={icons.emptyCircle} noBottomSpacing>
						<div className='es-w-full es-h-24 es-bg-cool-gray-100 es-rounded-1' />
					</Control>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<Control label='Label' icon={icons.emptyCircle}>
	...
</Control>`}
				/>
			</div>

			<div className='devkit-component-config'>
				<ItemShowcase title='Icon & subtitle'>
					<Control label='Label' icon={icons.emptyCircle} subtitle='Subtitle' noBottomSpacing>
						<div className='es-w-full es-h-24 es-bg-cool-gray-100 es-rounded-1' />
					</Control>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<Control label='Label' icon={icons.emptyCircle} subtitle='Subtitle'>
	...
</Control>`}
				/>
			</div>

			<div className='devkit-component-config'>
				<ItemShowcase title='Actions'>
					<Control label='Label' actions={<div className='es-h-spaced'>{icons.emptyRect}{icons.emptyRect}{icons.emptyRect}</div>} noBottomSpacing>
						<div className='es-w-full es-h-24 es-bg-cool-gray-100 es-rounded-1' />
					</Control>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<Control label='Label' actions={...}>
	...
</Control>`}
				/>
			</div>

			<div className='devkit-component-config'>
				<ItemShowcase title='Everything'>
					<Control
						label='Label'
						subtitle='Subtitle'
						icon={icons.emptyCircle}
						help='Help text'
						actions={<div className='es-h-spaced'>{icons.emptyRect}{icons.emptyRect}{icons.emptyRect}</div>}
						noBottomSpacing
					>
						<div className='es-w-full es-h-24 es-bg-cool-gray-100 es-rounded-1' />
					</Control>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<Control
		label='Label'
		subtitle='Subtitle'
		icon={icons.emptyCircle}
		help='Help text'
		actions={...}
	>
		...
</Control>`}
				/>
			</div>

			<div className='devkit-component-config'>
				<ItemShowcase title='Inline label'>
					<Control
						label='Label'
						subtitle='Subtitle'
						icon={icons.emptyCircle}
						noBottomSpacing
						inlineLabel
					>
						<div className='es-w-20 es-h-8 es-bg-cool-gray-100 es-rounded-1' />
					</Control>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<Control
		label='Label'
		subtitle='Subtitle'
		icon={icons.emptyCircle}
		inlineLabel
	>
		...
</Control>`}
				/>
			</div>
		</>
	);
};
