import React from 'react';
import { MarkdownView } from '../markdown-view';
import { ItemShowcase } from '../item-showcase';
import { Menu, MenuItem, MenuSeparator, icons } from '@eightshift/frontend-libs/scripts';
import { CodeBlock } from '../code-block';

export const MenuDocs = () => {
	return (
		<>
			<MarkdownView
				content={`# Menu
				A simple dropdown menu.`}
			/>

			<div className='devkit-component-config'>
				<ItemShowcase title='Simple menu bar'>
					<div className='es-h-spaced'>
						<Menu label='File'>
							<MenuItem label='New text file' onClick={() => console.log('"New text file" clicked')} />
							<MenuItem label='New file...' onClick={() => console.log('"New file..." clicked')} />
							<MenuItem label='New window' onClick={() => console.log('"New window" clicked')} />
							<MenuSeparator />
							<MenuItem label='Open...' onClick={() => console.log('"Open..." clicked')} />
							<MenuItem label='Open folder' onClick={() => console.log('"Open folder" clicked')} />
							<MenuItem label='Open workspace from file' onClick={() => console.log('"Open workspace from file" clicked')} />
							<MenuSeparator />
							<MenuItem label='Save' onClick={() => console.log('"Save" clicked')} />
							<MenuItem label='Save as...' onClick={() => console.log('"Save as..." clicked')} />
							<MenuItem label='Save all' onClick={() => console.log('"Save all" clicked')} />
						</Menu>

						<Menu label='Edit'>
							<MenuItem icon={icons.dummySpacer} label='Disabled item' disabled />
							<MenuItem icon={icons.componentGeneric} label='Disabled item with icon' disabled />
							<MenuSeparator />
							<MenuItem icon={icons.componentGeneric} label='Lorem' onClick={() => console.log('"Lorem" clicked')} />
							<MenuItem icon={icons.componentGeneric} label='Ipsum' onClick={() => console.log('"Ipsum" clicked')} />
							<MenuItem icon={icons.componentGeneric} label='Dolor' onClick={() => console.log('"Dolor" clicked')} />
							<MenuItem icon={icons.componentGeneric} label='Sit amet...' onClick={() => console.log('"Sit amet..." clicked')} />
						</Menu>
					</div>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<div className='es-h-spaced'>
	<Menu label='File'>
		<MenuItem label='New text file' onClick={...} />
		<MenuItem label='New file...' onClick={...} />
		<MenuItem label='New window' onClick={...}')} />
		<MenuSeparator />
		<MenuItem label='Open...' onClick={...} />
		<MenuItem label='Open folder' onClick={...} />
		<MenuItem label='Open workspace from file' onClick={...}" clicked')} />
		<MenuSeparator />
		<MenuItem label='Save' onClick={...} />
		<MenuItem label='Save as...' onClick={...} />
		<MenuItem label='Save all' onClick={...} />
	</Menu>

	<Menu label='Edit'>
		<MenuItem icon={icons.dummySpacer} label='Disabled item' disabled />
		<MenuItem icon={icons.componentGeneric} label='Disabled item with icon' disabled />
		<MenuSeparator />
		<MenuItem icon={icons.componentGeneric} label='Lorem' onClick={...} />
		<MenuItem icon={icons.componentGeneric} label='Ipsum' onClick={...} />
		<MenuItem icon={icons.componentGeneric} label='Dolor' onClick={...} />
		<MenuItem icon={icons.componentGeneric} label='Sit amet...' onClick={...} />
	</Menu>
</div>`}
				/>
			</div>

			<div className='devkit-component-config'>
				<ItemShowcase title='Nested menus'>
					<div className='es-h-spaced'>
						<Menu icon={icons.moreH}>
							<MenuItem icon={icons.dummySpacer} label='Disabled item' disabled />
							<MenuItem icon={icons.componentGeneric} label='Disabled item with icon' disabled />
							<MenuSeparator />
							<MenuItem icon={icons.componentGeneric} label='Lorem' onClick={() => console.log('"Lorem" clicked')} />
							<MenuItem icon={icons.componentGeneric} label='Ipsum' onClick={() => console.log('"Ipsum" clicked')} />
							<MenuItem icon={icons.componentGeneric} label='Dolor' onClick={() => console.log('"Dolor" clicked')} />
							<MenuItem icon={icons.componentGeneric} label='Sit amet...' onClick={() => console.log('"Sit amet..." clicked')} />
						</Menu>

						<Menu icon={icons.add}>
							<MenuItem icon={icons.dummySpacer} label='Disabled item' disabled />
							<MenuItem icon={icons.componentGeneric} label='Disabled item with icon' disabled />
							<MenuSeparator />
							<MenuItem icon={icons.componentGeneric} label='Lorem' onClick={() => console.log('"Lorem" clicked')} />
							<MenuItem icon={icons.componentGeneric} label='Ipsum' onClick={() => console.log('"Ipsum" clicked')} />
							<MenuItem icon={icons.componentGeneric} label='Dolor' onClick={() => console.log('"Dolor" clicked')} />
							<MenuItem icon={icons.componentGeneric} label='Sit amet...' onClick={() => console.log('"Sit amet..." clicked')} />
							<MenuSeparator />
							<Menu icon={icons.tree} label='Sub-menu' isSubmenu>
								<MenuItem icon={icons.dummySpacer} label='Disabled item' disabled />
								<MenuItem icon={icons.componentGeneric} label='Disabled item with icon' disabled />
								<MenuSeparator />
								<MenuItem icon={icons.componentGeneric} label='Lorem' onClick={() => console.log('"Lorem" clicked')} />
								<MenuItem icon={icons.componentGeneric} label='Ipsum' onClick={() => console.log('"Ipsum" clicked')} />
								<MenuItem icon={icons.componentGeneric} label='Dolor' onClick={() => console.log('"Dolor" clicked')} />
								<MenuItem icon={icons.componentGeneric} label='Sit amet...' onClick={() => console.log('"Sit amet..." clicked')} />
							</Menu>
						</Menu>
					</div>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<div className='es-h-spaced'>
					<Menu icon={icons.moreH}>
						<MenuItem icon={icons.dummySpacer} label='Disabled item' disabled />
						<MenuItem icon={icons.componentGeneric} label='Disabled item with icon' disabled />
						<MenuSeparator />
						<MenuItem icon={icons.componentGeneric} label='Lorem' onClick={...} />
						<MenuItem icon={icons.componentGeneric} label='Ipsum' onClick={...} />
						<MenuItem icon={icons.componentGeneric} label='Dolor' onClick={...} />
						<MenuItem icon={icons.componentGeneric} label='Sit amet...' onClick={...} />
					</Menu>

					<Menu icon={icons.add}>
						<MenuItem icon={icons.dummySpacer} label='Disabled item' disabled />
						<MenuItem icon={icons.componentGeneric} label='Disabled item with icon' disabled />
						<MenuSeparator />
						<MenuItem icon={icons.componentGeneric} label='Lorem' onClick={...} />
						<MenuItem icon={icons.componentGeneric} label='Ipsum' onClick={...} />
						<MenuItem icon={icons.componentGeneric} label='Dolor' onClick={...} />
						<MenuItem icon={icons.componentGeneric} label='Sit amet...' onClick={...} />
						<MenuSeparator />
						<Menu icon={icons.tree} label='Sub-menu' isSubmenu>
							<MenuItem icon={icons.dummySpacer} label='Disabled item' disabled />
							<MenuItem icon={icons.componentGeneric} label='Disabled item with icon' disabled />
							<MenuSeparator />
							<MenuItem icon={icons.componentGeneric} label='Lorem' onClick={...} />
							<MenuItem icon={icons.componentGeneric} label='Ipsum' onClick={...} />
							<MenuItem icon={icons.componentGeneric} label='Dolor' onClick={...} />
							<MenuItem icon={icons.componentGeneric} label='Sit amet...' onClick={...} />
						</Menu>
					</Menu>
</div>`}
				/>
			</div>

		</>
	);
};
