import React, { useState } from 'react';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { Menu, MenuItem, MenuSeparator, classnames, icons } from '@eightshift/frontend-libs/scripts';
import { coldarkCold as style } from 'react-syntax-highlighter/dist/esm/styles/prism';

export const CodeBlock = (props) => {
	const {
		code,
		language = 'javascript',
		lineNumbers = false,
		lineWrap = false,
		hideCopyButton = false,
		filename,
	} = props;

	const copyCode = () => {
		navigator.clipboard.writeText(code);
	};

	const [wrap, setWrap] = useState(lineWrap);
	const [lineNums, setLineNums] = useState(lineNumbers);

	return (

		<div className={classnames('devkit-code-block es-py-2 es-px-4 es-rounded-2 es-bg-cool-gray-50 es-border-cool-gray-100 es-display-flex es-flex-col', wrap && 'has-wrap')}>
			{filename &&
				<span className='es-text-3.25 es-user-select-none es-color-cool-gray-450 es-mt-1'>{filename}</span>
			}

			<SyntaxHighlighter
				language={language}
				style={style}
				showLineNumbers={lineNums}
				wrapLines={wrap}
				wrapLongLines={wrap}
			>
				{code}
			</SyntaxHighlighter>


			<Menu
				// eslint-disable-next-line max-len
				buttonClass='es-bg-cool-gray-50 es-border-cool-gray-100 es-hover-border-cool-gray-200 es-hover-bg-pure-white es-rounded-1.5 es-nested-size-4! es-w-9! es-h-7! es-p-0! es-transition es-min-size-auto! -es-mr-2 es-ml-auto'
				icon={icons.moreH}
				popoverProps={{ allowCloseFromChildren: true }}
			>
				{!hideCopyButton &&
					<>
						<MenuItem customProps={{ esClosesModalOnClick: true }} label='Copy' icon={icons.copy} onClick={copyCode} />
						<MenuSeparator />
					</>
				}

				<MenuItem
					label='Line numbers'
					icon={lineNums ? icons.check : icons.dummySpacer}
					onClick={() => setLineNums(!lineNums)}
					additionalClass='es-nested-p-0.5 es-has-enhanced-contrast-icon'
				/>

				<MenuItem
					label='Wrap long lines'
					icon={wrap ? icons.check : icons.dummySpacer}
					onClick={() => setWrap(!wrap)}
					additionalClass='es-nested-p-0.5 es-has-enhanced-contrast-icon'
				/>
			</Menu>
		</div>
	);
};
