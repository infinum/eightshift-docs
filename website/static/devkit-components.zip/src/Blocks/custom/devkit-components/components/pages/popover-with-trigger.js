import React from 'react';
import { MarkdownView } from '../markdown-view';
import { ItemShowcase } from '../item-showcase';
import { PopoverWithTrigger } from '@eightshift/frontend-libs/scripts';
import { Button } from '@wordpress/components';
import { CodeBlock } from '../code-block';

export const PopoverWithTriggerDocs = () => {
	const buttonClass = 'es-w-14 es-content-center es-rounded-1.5! es-border-cool-gray-300 es-hover-border-cool-gray-450 es-hover-color-cool-gray-800! es-transition';
	return (
		<>
			<MarkdownView
				content={`# PopoverWithTrigger
				🚧 Work in progress

				A building block component to make adding \`Popover\`s triggered with custom elements easy.`}
			/>

			<div className='devkit-component-config'>
				<ItemShowcase title='Default'>
					<PopoverWithTrigger
						trigger={
							({ ref, setIsOpen, isOpen }) => {
								return (
									<Button
										ref={ref}
										onClick={() => setIsOpen(!isOpen)}
										className={buttonClass}
									>
										Open
									</Button>
								);
							}
						}
					>
						<div className='es-h-40 es-w-full es-rounded-1 es-bg-cool-gray-100 es-display-flex es-items-center es-content-center' />
					</PopoverWithTrigger>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<PopoverWithTrigger
	trigger={
		({ ref, setIsOpen, isOpen }) => {
			return (
				<Button
					ref={ref}
					onClick={() => setIsOpen(!isOpen)}
				>
					Open
				</Button>
			);
		}
	}
>
	...
</PopoverWithTrigger>`}
				/>
			</div>

			<div className='devkit-component-config'>
				<ItemShowcase title='Close from inner items'>
					<PopoverWithTrigger
						allowCloseFromChildren
						trigger={
							({ ref, setIsOpen, isOpen }) => {
								return (
									<Button
										ref={ref}
										onClick={() => setIsOpen(!isOpen)}
										className={buttonClass}
									>
										Open
									</Button>
								);
							}
						}
					>
						<div className='es-h-40 es-w-full es-rounded-1 es-bg-cool-gray-100 es-display-flex es-items-center es-content-center'>
							<Button
								data-es-popover-close
								className='es-bg-cool-gray-450 es-hover-bg-cool-gray-650 es-color-pure-white es-hover-color-pure-white es-rounded-1.5 es-transition'
							>
								Close
							</Button>
						</div>
					</PopoverWithTrigger>

				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<PopoverWithTrigger
	trigger={
		({ ref, setIsOpen, isOpen }) => {
			return (
				<Button
					ref={ref}
					onClick={() => setIsOpen(!isOpen)}
				>
					Open
				</Button>
			);
		}
	}
	allowCloseFromChildren
>
	<div>
		<Button data-es-popover-close>Close</Button>
	</div>
</PopoverWithTrigger>`}
				/>
			</div>



		</>
	);
};
