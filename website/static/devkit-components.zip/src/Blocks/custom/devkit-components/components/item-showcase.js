
/**
 * Item for nicely showing a property in a Storybook story.
 *
 * @param {object} props - SingleItemShowcase props.
 * @param {string|React.Component} props.title - Title of the card
 * @param {object?} [props.propsUsed] - List of highlighted props for this showcase. Should be in format of `{ 'propName': 'description', 'propName2': 'description2 , ...}`.
 * @param {string?} [props.demoContainerClass] - Class passed to the main container.
 * @param {array?} [props.additionalPanels] - Class passed to the main container.
 * @param {<React.component>} [props.children] - Main container contents - demo area.
 */
export const ItemShowcase = ({ title, propsUsed, demoContainerClass, additionalPanels, children }) => {
	const titleClass = 'es-m-0 es-p-0 es-text-3.5 es-font-weight-500 es-line-h-1.2! devkit-wrap-balance';

	return (
		<div
			className='es-display-flex es-flex-col es-rounded-2 es-shadow-sm es-border-cool-gray-100 es-text-3.25 es-w-80'
			style={{ '--wp-admin-theme-color': 'var(--es-admin-accent-color-default)' }}
		>
			<div className='es-px-4 es-py-2 es-border-b-cool-gray-100 es-bg-cool-gray-50 es-rounded-tl-2 es-rounded-tr-2'>
				{typeof title === 'string' && <p className={titleClass} dangerouslySetInnerHTML={{ __html: title }} />}
				{typeof title !== 'string' && <p className={titleClass}>{title}</p>}
			</div>
			<div className={`es-p-4 ${demoContainerClass ?? ''}`}>
				{children}
			</div>

			{propsUsed &&
				<div className='es-p-4 es-border-t-cool-gray-100 es-mt-auto'>
					<p className='es-mt-0 es-mb-2 es-font-weight-500 es-text-3 es-color-cool-gray-500'>PROPS USED</p>

					<div className='es-v-spaced es-gap-1!'>
						{Object.entries(propsUsed).map(([propName, description], i, arr) => {
							return (
								<>
									<code className='es-m-0 es-color-eightshift-500'>{propName}</code>
									<p className={i < arr.length - 1 ? 'es-mt-0 es-mb-3' : 'es-m-0'} dangerouslySetInnerHTML={{ __html: description }} />
								</>
							);
						})}
					</div>
				</div>
			}

			{additionalPanels && additionalPanels.map(({ title, content }, i) => {
				return (
					<div key={i} className='es-p-4 es-border-t-cool-gray-100'>
						{title &&
							<p className='es-mt-0 es-mb-2 es-font-weight-500 es-text-3 es-color-cool-gray-500'>{title.toUpperCase()}</p>
						}

						{content}
					</div>
				);
			})}
		</div>
	);
};
