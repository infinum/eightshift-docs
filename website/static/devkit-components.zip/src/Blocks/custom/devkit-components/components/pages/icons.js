import React, { useState } from 'react';
import { AnimatedContentVisibility, BlockIcon, OptionSelector, blockIcons, classnames, icons, upperFirst } from '@eightshift/frontend-libs/scripts';
import { Button } from '@wordpress/components';
import { MarkdownView } from '../markdown-view';
import { ItemShowcase } from '../item-showcase';

/* eslint-disable max-len */
export const Icons = ({ page = 'intro' }) => {
	const [uiSearch, setUiSearch] = useState('');
	const [blockSearch, setBlockSearch] = useState('');
	const [iconTheme, setIconTheme] = useState('default');

	const [btn1, setBtn1] = useState(false);
	const [btn2, setBtn2] = useState(false);
	const [btn3, setBtn3] = useState(false);
	const [btn4, setBtn4] = useState(false);
	const [btn5, setBtn5] = useState(false);

	if (page === 'intro') {
		return <MarkdownView filename='icons-intro' />;
	}

	if (page === 'ui') {
		let filteredIcons = uiSearch.length > 0 ? Object.entries(icons).filter(([key]) => key.toLowerCase().includes(uiSearch.toLowerCase())) : Object.entries(icons);

		return (
			<div className='-es-mt-4'>
				<div className='es-h-between es-position-sticky es-top-0 es-py-4 es-bg-pure-white'>
					<h1>UI icons</h1>

					<input
						type='search'
						placeholder='Search icons'
						className='es-border-cool-gray-400 es-px-2 es-py-1.5 es-rounded-1 es-outline-none es-focus-hi-vis-outline es-text-3.5'
						value={uiSearch}
						onChange={(e) => setUiSearch(e?.target?.value ?? '')}
					/>
				</div>

				<div>
					<AnimatedContentVisibility showIf={filteredIcons?.length < 1}>
						<div className='es-mt-5 es-mx-auto es-font-size-5 es-v-center es-max-w-72 es-nested-w-10 es-nested-h-10 es-nested-color-admin-accent es-mt-6'>
							{icons.searchEmpty}
							<span>No results</span>
						</div>
					</AnimatedContentVisibility>

					<div className='es-h-spaced-wrap es-gap-2.5! es-mt-6'>
						{filteredIcons.map(([key, value], index) => {
							return (
								<Button
									key={index}
									icon={value}
									showTooltip
									label={key}
									className='es-size-16! es-nested-size-7.5! es-border-cool-gray-100 es-rounded-2 es-nested-color-cool-gray-650! es-hover-nested-color-admin-accent! es-transition'
									onClick={() => {
										navigator.clipboard.writeText(key).then(
											() => console.log('Copied to clipboard!'),
											() => console.log('Error copying to clipboard.')
										);
									}}
								/>
							);
						})}
					</div>
				</div>
			</div>
		);
	}

	if (page === 'block') {

		let filteredIcons = blockSearch.length > 0 ? Object.entries(blockIcons).filter(([key]) => key.toLowerCase().includes(blockSearch.toLowerCase())) : Object.entries(blockIcons);

		const themes = {
			default: 'es-bg-pure-white es-nested-color-cool-gray-900!',
			blue: 'es-bg-blue-500 es-nested-color-pure-white!',
			green: 'es-bg-green-500 es-nested-color-pure-white!',
			dark: 'es-bg-cool-gray-800 es-nested-color-pure-white!',
		};

		return (
			<div className='-es-mt-4'>
				<div className='es-h-between es-position-sticky es-top-0 es-py-4 es-bg-pure-white'>
					<h1>Block icons</h1>

					<div className='es-h-spaced'>
						<OptionSelector
							value={iconTheme}
							onChange={(value) => setIconTheme(value)}
							options={Object.keys(themes).map((theme) => ({ value: theme, label: upperFirst(theme) }))}
							additionalButtonClass='es-rounded-1.5'
							noBottomSpacing
							compactButtons
						/>

						<input
							type='search'
							placeholder='Search icons'
							className='es-border-cool-gray-400 es-px-2 es-py-1.5 es-rounded-1 es-outline-none es-focus-hi-vis-outline es-text-3.5'
							value={blockSearch}
							onChange={(e) => setBlockSearch(e?.target?.value ?? '')}
						/>
					</div>
				</div>

				<div>
					<AnimatedContentVisibility showIf={filteredIcons?.length < 1}>
						<div className='es-mt-5 es-mx-auto es-font-size-5 es-v-center es-max-w-72 es-nested-w-10 es-nested-h-10 es-nested-color-admin-accent es-mt-6'>
							{icons.searchEmpty}
							<span>No results</span>
						</div>
					</AnimatedContentVisibility>

					<div className='es-h-spaced-wrap es-gap-2.5! es-mt-6'>
						{filteredIcons.map(([key], index) => {
							return (
								<Button
									key={index}
									icon={<BlockIcon iconName={key} />}
									showTooltip
									label={key}
									className={classnames(themes[iconTheme], 'es-size-16! es-nested-size-7.5! es-border-cool-gray-100 es-rounded-2 es-hover-nested-color-admin-accent! es-transition')}
									onClick={() => {
										navigator.clipboard.writeText(key).then(
											() => console.log('Copied to clipboard!'),
											() => console.log('Error copying to clipboard.')
										);
									}}
								/>
							);
						})}
					</div>
				</div>
			</div>
		);

	}

	const buttonClass = 'es-nested-size-6 es-size-10 es-min-size-0! es-border-cool-gray-100 es-rounded-2';

	return (
		<>
			<MarkdownView
				content={`
				# Animated icons
				Micro-interactions help improve spatial awareness of users, while adding visual delight.
				`}
			/>

			<div className='es-display-flex es-flex-wrap es-gap-5! es-content-center es-mt-10'>
				<ItemShowcase
					title='Inherit arrow'
					additionalPanels={[
						{
							title: 'How to use',
							content: <span><code>es-animated-inherit-icon</code><br />(+ <code>is-inherited</code>)</span>,
						}
					]}
				>
					<Button
						className={classnames(buttonClass, 'es-animated-inherit-icon', btn1 && 'is-inherited')}
						icon={icons.inherit}
						onClick={() => setBtn1(!btn1)}
					/>
				</ItemShowcase>

				<ItemShowcase
					title='Y-flip animation'
					additionalPanels={[
						{
							title: 'How to use',
							content: <span><code>es-has-animated-y-flip-icon</code><br />(+ <code>is-active</code>)</span>,
						},
						{
							title: 'Note',
							content: 'The icon needs to be in SVG format, inlined.',
						}
					]}
				>
					<div className='es-h-spaced'>
						<Button
							className={classnames(buttonClass, 'es-has-animated-y-flip-icon', btn2 && 'is-active')}
							icon={icons.caretUp}
							onClick={() => setBtn2(!btn2)}
						/>

						<Button
							className={classnames(buttonClass, 'es-has-animated-y-flip-icon', btn3 && 'is-active')}
							icon={btn3 ? icons.caretDownFill : icons.caretDown}
							onClick={() => setBtn3(!btn3)}
						/>

						<Button
							className={classnames(buttonClass, 'es-has-animated-y-flip-icon', btn4 && 'is-active es-color-green-500!')}
							icon={btn4 ? icons.solidCircleGradient : icons.emptyCircle}
							onClick={() => setBtn4(!btn4)}
						/>
					</div>
				</ItemShowcase>

				<ItemShowcase
					title='Animated toggle'
					additionalPanels={[
						{
							title: 'How to use',
							content: <span><code>es-animated-toggle-icon</code><br />(+ <code>is-checked</code>)</span>,
						}
					]}
				>
					<Button
						className={classnames(buttonClass, 'es-animated-toggle-icon', btn5 && 'is-checked')}
						icon={icons.toggleOff}
						onClick={() => setBtn5(!btn5)}
					/>
				</ItemShowcase>
			</div>
		</>
	);
};
