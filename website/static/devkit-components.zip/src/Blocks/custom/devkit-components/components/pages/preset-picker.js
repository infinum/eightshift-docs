import React, { useState } from 'react';
import { MarkdownView } from '../markdown-view';
import { ItemShowcase } from '../item-showcase';
import { PresetPicker, icons } from '@eightshift/frontend-libs/scripts';
import { CodeBlock } from '../code-block';

export const PresetPickerDocs = () => {
	const [state, setState] = useState({});

	const fakeManifest = {
		attributes: {
			color: {
				type: 'string',
			},
			content: {
				type: 'string',
				default: '_',
			},
		},
		configPresets: [
			{
				name: 'Red',
				icon: 'num1CircleAlt',
				attributes: {
					color: '#A83232',
				}
			},
			{
				name: 'Blue',
				icon: 'num2CircleAlt',
				attributes: {
					color: '#3248A8',
				}
			}
		]
	};



	return (
		<>
			<MarkdownView
				content={`# PresetPicker
				🚧 Work in progress

				A simple preset picker that can pull data from manifest.`}
			/>

			<CodeBlock
				filename='manifest.json'
				language='json'
				code={`{
	...
	configPresets: [
		{
			name: 'Red',
			icon: 'num1CircleAlt',
			attributes: {
				// Any attributes you want to replace
			}
		},
		{
			name: 'Blue',
			icon: 'num2CircleAlt',
			attributes: {
				// Any attributes you want to replace
			}
		}
	]
}`}
			/>

			<div className='devkit-component-config'>
				<ItemShowcase
					title='Default'
					additionalPanels={[
						{
							title: 'Preview',
							content: (
								<div className='es-size-8 es-rounded-1.5 es-border-cool-gray-300 es-text-pure-white es-transition' style={{ backgroundColor: state?.color }} />
							)
						}
					]}
				>
					<PresetPicker
						manifest={fakeManifest}
						setAttributes={setState}
						noBottomSpacing
					/>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<PresetPicker
	manifest={manifest}
	setAttributes={setAttributes}
/>`}
				/>
			</div>

			<div className='devkit-component-config'>
				<ItemShowcase
					title='Collapsable'
					additionalPanels={[
						{
							title: 'Preview',
							content: (
								<div className='es-size-8 es-rounded-1.5 es-border-cool-gray-300 es-text-pure-white es-transition' style={{ backgroundColor: state?.color }} />
							)
						}
					]}
				>
					<PresetPicker
						manifest={fakeManifest}
						setAttributes={setState}
						noBottomSpacing
						showAsCollapsable
					/>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<PresetPicker
	manifest={manifest}
	setAttributes={setAttributes}
	showAsCollapsable
/>`}
				/>
			</div>

			<div className='devkit-component-config'>
				<ItemShowcase
					title='Preset buttons only'
					additionalPanels={[
						{
							title: 'Preview',
							content: (
								<div className='es-size-8 es-rounded-1.5 es-border-cool-gray-300 es-text-pure-white es-transition' style={{ backgroundColor: state?.color }} />
							)
						}
					]}
				>
					<PresetPicker
						manifest={fakeManifest}
						setAttributes={setState}
						noBottomSpacing
						controlOnly
					/>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<PresetPicker
	manifest={manifest}
	setAttributes={setAttributes}
	controlOnly
/>`}
				/>
			</div>

			<div className='devkit-component-config'>
				<ItemShowcase
					title='"Default" button'
					additionalPanels={[
						{
							title: 'Preview',
							content: (
								<div className='es-size-8 es-rounded-1.5 es-border-cool-gray-300 es-text-pure-white es-transition' style={{ backgroundColor: state?.color }} />
							)
						}
					]}
				>
					<PresetPicker
						manifest={fakeManifest}
						setAttributes={setState}
						defaultButton
					/>

					<PresetPicker
						manifest={fakeManifest}
						setAttributes={setState}
						noBottomSpacing
						defaultButton={{ label: 'DefaultLabel', icon: icons.emptyCircle, attributes: { color: '#36A832' } }}
					/>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<PresetPicker
	manifest={manifest}
	setAttributes={setAttributes}
	defaultButton
/>

<PresetPicker
	manifest={manifest}
	setAttributes={setAttributes}
	defaultButton={{
		label: 'DefaultLabel',
		icon: icons.emptyCircle,
		attributes: { ... } // Attributes to set
	}}
/>
`}
				/>
			</div>

			<div className='devkit-component-config'>
				<ItemShowcase
					title='"Off" button'
					additionalPanels={[
						{
							title: 'Preview',
							content: (
								<div className='es-size-8 es-rounded-1.5 es-border-cool-gray-300 es-text-pure-white es-transition' style={{ backgroundColor: state?.color }} />
							)
						}
					]}
				>
					<PresetPicker
						manifest={fakeManifest}
						setAttributes={setState}
						offButton={{ label: 'OffLabel', icon: icons.emptyCircle, attributes: { color: '#A88732' } }}
					/>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<PresetPicker
	manifest={manifest}
	setAttributes={setAttributes}
	defaultButton
/>

<PresetPicker
	manifest={manifest}
	setAttributes={setAttributes}
	offButton={{
		label: 'OffLabel',
		icon: icons.emptyCircle,
		attributes: { ... } // Attributes to set
	}}
/>
`}
				/>
			</div>
		</>
	);
};
