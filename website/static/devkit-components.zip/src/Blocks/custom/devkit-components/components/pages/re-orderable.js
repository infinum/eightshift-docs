import React, { useState } from 'react';
import { MarkdownView } from '../markdown-view';
import { ItemShowcase } from '../item-showcase';
import { ReOrderable, ReOrderableItem, Repeater, RepeaterItem, icons } from '@eightshift/frontend-libs/scripts';
import { TextControl } from '@wordpress/components';
import { CodeBlock } from '../code-block';

export const ReOrderableDocs = () => {
	const [attributes, setAttributes] = useState({
		items: [
			{
				id: 1,
				title: 'Item 1',
				icon: icons.num1Circle,
			},
			{
				id: 2,
				title: 'Item 2',
				icon: icons.num2Circle,
			},
			{
				id: 3,
				title: 'Item 3',
				icon: icons.num3Circle,
			}
		],
	});

	const [attributes2, setAttributes2] = useState({
		items: [
			{
				id: 1,
				title: 'Item 1',
				icon: icons.num1Circle,
			},
			{
				id: 2,
				title: 'Item 2',
				icon: icons.num2Circle,
			},
			{
				id: 3,
				title: 'Item 3',
				icon: icons.num3Circle,
			}
		],
	});

	return (
		<>
			<MarkdownView
				content={`# ReOrderable and Repeater
				🚧 Work in progress

				A component that allows reordering along horizontal, vertical, or both directions,
				and a simple repeater component, inspired by ACF.`}
			/>

			<div className='devkit-component-config'>
				<ItemShowcase title='Re-orderable'>
					<ReOrderable
						icon={icons.emptyCircle}
						label='Re-orderable'
						items={attributes.items}
						attributeName='items'
						setAttributes={setAttributes}
					>
						{attributes.items.map((item, i) => (
							<ReOrderableItem
								key={i}
								icon={item?.icon ?? icons.experiment}
								title={item.title}
							/>
						))}
					</ReOrderable>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`const items = [
	{
		id: 1,
		title: 'Item 1',
		icon: icons.num1Circle,
	},
	{
		id: 2,
		title: 'Item 2',
		icon: icons.num2Circle,
	},
	{
		id: 3,
		title: 'Item 3',
		icon: icons.num3Circle,
	}
];

<ReOrderable
	icon={icons.emptyCircle}
	label='Re-orderable'
	items={items}
	attributeName='items'
	setAttributes={setAttributes}
>
	{items.map((item, index) => (
		<ReOrderableItem
			key={index}
			icon={item.icon}
			title={item.title}
		/>
	))}
</ReOrderable>`}
				/>
			</div>

			<div className='devkit-component-config'>
				<ItemShowcase title='Repeater'>
					<Repeater
						icon={icons.emptyCircle}
						label='Repeater'
						items={attributes2.items}
						attributeName='items'
						setAttributes={setAttributes2}
					>
						{attributes2.items.map((item, i) => (
							<RepeaterItem
								key={i}
								icon={item?.icon ?? icons.emptyCircle}
								title={item.title}
							>
								<TextControl
									value={item.title}
									onChange={(value) => {
										const newArray = [...attributes.items];
										newArray[i].title = value;

										setAttributes2({ items: newArray }); // You would use getAttributeKey here.
									}}
								/>
							</RepeaterItem>
						))}
					</Repeater>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`const items = [
	{
		id: 1,
		title: 'Item 1',
		icon: icons.num1Circle,
	},
	{
		id: 2,
		title: 'Item 2',
		icon: icons.num2Circle,
	},
	{
		id: 3,
		title: 'Item 3',
		icon: icons.num3Circle,
	}
];

<Repeater
	icon={icons.emptyCircle}
	label='Re-orderable'
	items={items}
	attributeName='items'
	setAttributes={setAttributes}
>
	{items.map((item, index) => (
		<RepeaterItem
			key={i}
			icon={item?.icon ?? icons.emptyCircle}
			title={item.title}
		>
			<TextControl
				value={item.title}
				onChange={(value) => {
					const newArray = [...attributes.items];
					newArray[i].title = value;

					setAttributes2({ items: newArray }); // You would use getAttributeKey here.
				}}
			/>
		</RepeaterItem>
	))}
</Repeater>`}
				/>
			</div>
		</>
	);
};
