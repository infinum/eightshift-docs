import React, { useState, useEffect } from 'react';
import Markdown from 'react-markdown';
import { CodeBlock } from './code-block';
import { classnames } from '@eightshift/frontend-libs/scripts';

export const MarkdownView = (props) => {

	// Import file on load, from filename prop
	const [parsedContent, setParsedContent] = useState(null);

	useEffect(() => {
		if (!props.filename || props.content) {
			return;
		}

		import(`./pages/markdown/${props.filename}.md`)
			.then(({ default: markdownContent }) => {
				if (markdownContent) {
					setParsedContent(markdownContent);
				}
			});
	}, [props.content, props.filename]);


	return (
		<Markdown
			className={classnames('devkit-markdown', props.prose && 'prose', !props.fullWidth && 'prose-width')}
			components={{
				'pre': ({ node }) => {
					const code = node?.children?.[0]?.children?.[0]?.value?.trim();
					const lang = node.children?.[0]?.properties?.className?.[0]?.replace('language-', '');

					if (!code || !lang) {
						return null;
					}
					return (
						<CodeBlock code={code} lang={lang} />
					);
				},
			}}
		>
			{props?.content?.split("\n")?.map((l) => l.trim())?.join("\n") ?? parsedContent ?? ''}
		</Markdown>
	);
};
