import React from 'react';
import { MarkdownView } from '../markdown-view';
import { ItemShowcase } from '../item-showcase';
import { IconLabel, icons } from '@eightshift/frontend-libs/scripts';
import { CodeBlock } from '../code-block';

export const IconLabelDocs = () => {
	return (
		<>
			<MarkdownView
				content={`# IconLabel
				A flexible labelling component, with options for an icon, subtitle and style customization.`}
			/>

			<div className='devkit-component-config'>
				<ItemShowcase title='Icon and text'>
					<IconLabel label='Hi, label here!' icon={icons.genericShapesAlt} noBottomSpacing standalone />
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code="<IconLabel label='Hi, label here!' icon={icons.genericShapesAlt} />"
				/>
			</div>

			<div className='devkit-component-config'>
				<ItemShowcase title='Icon, text, subtitle'>
					<IconLabel label='Hi, label here!' icon={icons.genericShapesAlt} subtitle='Subtitle' noBottomSpacing standalone />
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code="<IconLabel label='Hi, label here!' subtitle='Subtitle' icon={icons.genericShapesAlt} />"
				/>
			</div>

			<div className='devkit-component-config'>
				<ItemShowcase title='Subtitle gap'>
				<div className='es-fifty-fifty-h'>
						<IconLabel
							icon={icons.genericShapesAlt}
							label='No gap'
							subtitle='Subtitle'
							standalone
						/>

						<IconLabel
							icon={icons.genericShapesAlt}
							label='With gap'
							subtitle='Subtitle'
							standalone
							addSubtitleGap
						/>
					</div>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code="<IconLabel label='Hi, label here!' subtitle='Subtitle' icon={icons.genericShapesAlt} addSubtitleGap />"
				/>
			</div>

			<div className='devkit-component-config'>
				<ItemShowcase title='Custom classes'>
					<IconLabel label='Hi, label here!' icon={icons.genericShapesAlt} additionalClasses='es-nested-color-admin-accent!' noBottomSpacing standalone />
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code="<IconLabel label='Hi, label here!' icon={icons.genericShapesAlt} additionalClasses='es-nested-color-admin-accent!' />"
				/>
			</div>
		</>
	);
};
