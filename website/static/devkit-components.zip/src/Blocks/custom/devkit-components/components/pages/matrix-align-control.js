import React, { useState } from 'react';
import { MarkdownView } from '../markdown-view';
import { ItemShowcase } from '../item-showcase';
import { MatrixAlignControl, icons } from '@eightshift/frontend-libs/scripts';
import { CodeBlock } from '../code-block';

export const MatrixAlignControlDocs = () => {
	const [align, setAlign] = useState('center center');
	const [align2, setAlign2] = useState('top left');
	const [align3, setAlign3] = useState('center center');
	const [align4, setAlign4] = useState('top left');
	const [align5, setAlign5] = useState('center center');
	const [align6, setAlign6] = useState('top left');

	return (
		<>
			<MarkdownView
				content={`# MatrixAlignControl
				A component that can provide a 3x3 or a 2x2 grid of positions to pick from.

				Replaces the default Gutenberg \`AlignmentMatrixControl\`/\`BlockAlignmentMatrixControl\`/\`BlockAlignmentMatrixToolbar\`.`}
			/>

			<div className='devkit-component-config'>
				<ItemShowcase title='Default 3x3'>
					<MatrixAlignControl
						label='Alignment'
						value={align}
						onChange={(value) => setAlign(value)}
						noBottomSpacing
					/>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<MatrixAlignControl
	label='Alignment'
	value={align}
	onChange={(value) => setAlign(value)}
/>`}
				/>
			</div>

			<div className='devkit-component-config'>
				<ItemShowcase title='Default 2x2'>
					<MatrixAlignControl
						label='Alignment'
						value={align2}
						onChange={(value) => setAlign2(value)}
						noBottomSpacing
						size='2x2'
					/>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<MatrixAlignControl
	label='Alignment'
	value={align}
	onChange={(value) => setAlign(value)}
	size='2x2'
/>`}
				/>
			</div>

			<div className='devkit-component-config'>
				<ItemShowcase title='3x3 tile button'>
					<MatrixAlignControl
						label='Alignment'
						value={align3}
						onChange={(value) => setAlign3(value)}
						noBottomSpacing
						type='tileButton'
					/>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<MatrixAlignControl
	label='Alignment'
	value={align}
	onChange={(value) => setAlign(value)}
	type='tileButton'
/>`}
				/>
			</div>

			<div className='devkit-component-config'>
				<ItemShowcase title='2x2 tile button'>
					<MatrixAlignControl
						label='Alignment'
						value={align4}
						onChange={(value) => setAlign4(value)}
						noBottomSpacing
						size='2x2'
						type='tileButton'
					/>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<MatrixAlignControl
	label='Alignment'
	value={align}
	onChange={(value) => setAlign(value)}
	size='2x2'
	type='tileButton'
/>`}
				/>
			</div>

			<div className='devkit-component-config'>
				<ItemShowcase title='3x3 inline'>
					<MatrixAlignControl
						icon={icons.emptyCircle}
						label='Alignment'
						value={align5}
						onChange={(value) => setAlign5(value)}
						noBottomSpacing
						type='inline'
					/>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<MatrixAlignControl
	icon={icons.emptyCircle}
	label='Alignment'
	value={align}
	onChange={(value) => setAlign(value)}
	type='inline'
/>`}
				/>
			</div>

			<div className='devkit-component-config'>
				<ItemShowcase title='2x2 inline'>
					<MatrixAlignControl
						icon={icons.emptyCircle}
						label='Alignment'
						value={align6}
						onChange={(value) => setAlign6(value)}
						noBottomSpacing
						size='2x2'
						type='inline'
					/>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<MatrixAlignControl
	icon={icons.emptyCircle}
	label='Alignment'
	value={align}
	onChange={(value) => setAlign(value)}
	size='2x2'
	type='inline'
/>`}
				/>
			</div>

		</>
	);
};
