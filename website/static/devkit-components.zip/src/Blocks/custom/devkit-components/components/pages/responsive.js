import React, { useState } from 'react';
import { MarkdownView } from '../markdown-view';
import { ItemShowcase } from '../item-showcase';
import {
	NumberPicker,
	Responsive,
	ResponsiveNumberPicker,
	ResponsiveSlider,
	ResponsiveToggleButton,
	WidthOffsetRangeSlider,
	icons,
	upperFirst,
} from '@eightshift/frontend-libs/scripts';
import { CodeBlock } from '../code-block';

export const ResponsiveDocs = () => {
	const options = {
		breakpoints: [
			'large',
			'desktop',
			'tablet',
			'mobile',
		],
	};

	const [attributes, setAttributes] = useState({
		demoComponentToggleLarge: 1,
		demoComponentToggleDesktop: '',
		demoComponentToggleTablet: '',
		demoComponentToggleMobile: 0,
	});

	const [attributes2, setAttributes2] = useState({
		demoComponentToggleLarge: 1,
		demoComponentToggleDesktop: '',
		demoComponentToggleTablet: '',
		demoComponentToggleMobile: 0,
	});

	const [attributes3, setAttributes3] = useState({
		demoComponentToggleLarge: 1,
		demoComponentToggleDesktop: '',
		demoComponentToggleTablet: '',
		demoComponentToggleMobile: 0,
	});

	//

	const defaultValueNum = {
		large: 8,
		desktop: undefined,
		tablet: undefined,
		mobile: 12,
	};

	const [value, setValue] = useState(defaultValueNum);
	const [value2, setValue2] = useState(defaultValueNum);
	const [value3, setValue3] = useState(defaultValueNum);

	const [value4, setValue4] = useState({
		large: 8,
		desktop: -1,
		tablet: -1,
		mobile: 12,
	});

	const [value5, setValue5] = useState({
		large: '8',
		desktop: '',
		tablet: '',
		mobile: 12,
	});

	const commonNumProps = {
		min: 0,
		max: 50,
		step: 1,
		noBottomSpacing: true,
		icon: icons.emptyCircle,
		label: 'Picker',
	};

	//

	const defaultSlideValue = {
		large: 8,
		desktop: undefined,
		tablet: undefined,
		mobile: 12,
	};

	const [slideValue, setSlideValue] = useState(defaultSlideValue);
	const [slideValue2, setSlideValue2] = useState(defaultSlideValue);
	const [slideValue3, setSlideValue3] = useState(defaultSlideValue);

	const [slideValue4, setSlideValue4] = useState({
		large: 8,
		desktop: -1,
		tablet: -1,
		mobile: 12,
	});

	const [slideValue5, setSlideValue5] = useState({
		large: '8',
		desktop: '',
		tablet: '',
		mobile: 12,
	});

	const commonSlideProps = {
		min: 0,
		max: 50,
		step: 1,
		noBottomSpacing: true,
		icon: icons.emptyCircle,
		label: 'Slider',
	};

	//

	const defaultToggleValue = {
		large: true,
		desktop: undefined,
		tablet: undefined,
		mobile: false,
	};

	const [toggleValue, setToggleValue] = useState(defaultToggleValue);

	const [toggleValue2, setToggleValue2] = useState({
		large: true,
		desktop: -1,
		tablet: -1,
		mobile: false,
	});

	const [toggleValue3, setToggleValue3] = useState({
		large: 'true',
		desktop: '',
		tablet: '',
		mobile: 'false',
	});

	const commonToggleProps = {
		noBottomSpacing: true,
		icon: icons.emptyCircle,
		label: 'Toggle',
	};

	//

	const defaultWoRsValue = {
		large: {
			width: '8',
			offset: '1',
		},
		desktop: {
			width: '',
			offset: '',
		},
		tablet: {
			width: '',
			offset: '',
		},
		mobile: {
			width: '12',
			offset: '2',
		},
	};

	const [woRsValue, setWoRsValue] = useState(defaultWoRsValue);
	const [woRsValue2, setWoRsValue2] = useState(defaultWoRsValue);
	const [woRsValue3, setWoRsValue3] = useState(defaultWoRsValue);

	const [woRsValue4, setWoRsValue4] = useState({
		large: {
			width: '8',
			offset: '1',
		},
		desktop: {},
		tablet: {},
		mobile: {
			width: '12',
			offset: '2',
		},
	});

	const [woRsValue5, setWoRsValue5] = useState({
		large: {
			width: 8,
			offset: 1,
		},
		desktop: {},
		tablet: {},
		mobile: {
			width: 12,
			offset: 2,
		},
	});

	return (
		<>
			<MarkdownView
				content={`# Responsive components
				🚧 Work in progress

				A component that allows setting a value that can change based on breakpoints, or inherit the value from the breakpoint above.

				A collection of pre-configured components with common patterns is also included.`}
			/>

			<CodeBlock
				language='jsx'
				filename='manifest.json'
				code={`{
	...
	"attributes": {
		...
		"demoAttributeLarge": {
			"type": "string"
		},
		"demoAttributeDesktop": {
			"type": "string"
		},
		"demoAttributeTablet": {
			"type": "string"
		},
		"demoAttributeMobile": {
			"type": "string"
		}
	},
	"responsiveAttributes": {
		...
		"demoAttribute": {
			"large": "demoAttributeLarge",
			"desktop": "demoAttributeDesktop",
			"tablet": "demoAttributeTablet",
			"mobile": "demoAttributeMobile"
		}
	}
}`}
			/>

			<div className='devkit-component-config'>
				<ItemShowcase title='Default'>
					<Responsive
						label='Responsive'
						icon={icons.emptyRect}
						noBottomSpacing
					>
						{options.breakpoints.map((breakpoint, index) => {
							const point = upperFirst(breakpoint);
							const attr = `demoComponentToggle${point}`;

							return (
								<NumberPicker
									key={index}
									icon={icons.wrench}
									label='Demo option'
									value={attributes[attr]}
									onChange={(value) => setAttributes({ ...attributes, [attr]: value })}
									noBottomSpacing
									min={0}
									max={1000}
									step={10}
									fixedWidth='4'
									inlineLabel
								/>
							);
						})}
					</Responsive>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<Responsive
	label='Responsive'
	icon={icons.emptyCircle}
	inheritButton={options.breakpoints.map((breakpoint) => {
		const point = upperFirst(breakpoint);
		const attr = \`demoComponentToggle\${point}\`;

		return {
			callback: () => setAttributes({ ... }),
			isActive: attributes[attr] === '',
		};
	})}
>
	{options.breakpoints.map((breakpoint, index) => {
		const point = upperFirst(breakpoint);
		const attr = \`demoAttributeName\${point}\`;

		return (...);
	})}
</Responsive>`}
				/>
			</div>

			<div className='devkit-component-config'>
				<ItemShowcase title='Inherit button'>
					<Responsive
						label='Responsive'
						icon={icons.emptyRect}
						noBottomSpacing
						inheritButton={options.breakpoints.map((breakpoint) => {
							const point = upperFirst(breakpoint);
							const attr = `demoComponentToggle${point}`;

							return {
								callback: () => setAttributes2({
									...attributes2,
									[attr]: attributes2[attr] === '' ? '0' : '',
								}),
								isActive: attributes2[attr] === '',
							};
						})}
					>
						{options.breakpoints.map((breakpoint, index) => {
							const point = upperFirst(breakpoint);
							const attr = `demoComponentToggle${point}`;

							return (
								<NumberPicker
									key={index}
									icon={icons.wrench}
									label='Demo option'
									value={attributes2[attr]}
									onChange={(value) => setAttributes2({ ...attributes2, [attr]: value })}
									noBottomSpacing
									min={0}
									max={1000}
									step={10}
									fixedWidth='4'
									inlineLabel
								/>
							);
						})}
					</Responsive>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<Responsive
	label='Responsive'
	icon={icons.emptyCircle}
	inheritButton={options.breakpoints.map((breakpoint) => {
		const point = upperFirst(breakpoint);
		const attr = \`demoComponentToggle\${point}\`;

		return {
			callback: () => setAttributes({ ... }),
			isActive: attributes[attr] === '',
		};
	})}
>
	{options.breakpoints.map((breakpoint, index) => {
		const point = upperFirst(breakpoint);
		const attr = \`demoAttributeName\${point}\`;

		return (...);
	})}
</Responsive>`}
				/>
			</div>

			<div className='devkit-component-config'>
				<ItemShowcase title='Compact'>
					<Responsive
						label='Responsive'
						icon={icons.emptyRect}
						noBottomSpacing
						inline
					>
						{options.breakpoints.map((breakpoint, index) => {
							const point = upperFirst(breakpoint);
							const attr = `demoComponentToggle${point}`;

							return (
								<NumberPicker
									key={index}
									value={attributes3[attr]}
									onChange={(value) => setAttributes3({ ...attributes3, [attr]: value })}
									noBottomSpacing
									min={0}
									max={1000}
									step={10}
									fixedWidth='4'
									inlineLabel
								/>
							);
						})}
					</Responsive>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<Responsive
	label='Responsive'
	icon={icons.emptyCircle}
	inline
>
	{options.breakpoints.map((breakpoint, index) => {
		const point = upperFirst(breakpoint);
		const attr = \`demoAttributeName\${point}\`;

		return (...);
	})}
</Responsive>`}
				/>
			</div>

			<div className='es-w-full es-h-px es-bg-cool-gray-100' />

			<h2>Number picker</h2>

			<div className='es-display-flex es-flex-wrap es-gap-5!'>
				<ItemShowcase
					title='Basic control'
					propsUsed={{
						'inheritValue': 'Value that gets set when inherited.',
					}}
					additionalPanels={[{ title: 'Current value', content: <pre>{JSON.stringify(value, null, 2)}</pre> }]}
				>
					<ResponsiveNumberPicker
						value={value}
						onChange={(value) => setValue(value)}
						{...commonNumProps}
					/>
				</ItemShowcase>

				<ItemShowcase
					title='Reset buttons'
					propsUsed={{
						'resetButton': 'Adds a "Reset" button.',
					}}
					additionalPanels={[
						{ title: 'Current value (top)', content: <pre>{JSON.stringify(value2, null, 2)}</pre> },
						{ title: 'Current value (bottom)', content: <pre>{JSON.stringify(value3, null, 2)}</pre> },
					]}
				>
					<ResponsiveNumberPicker
						value={value2}
						onChange={(value) => setValue2(value)}
						{...commonNumProps}
						resetButton={0}
						noBottomSpacing={false}
					/>

					<ResponsiveNumberPicker
						value={value3}
						onChange={(value) => setValue3(value)}
						{...commonNumProps}
						resetButton={20}
					/>
				</ItemShowcase>

				<ItemShowcase
					title='Custom "inherit" value'
					propsUsed={{
						'inheritCheck': 'Callback (<code>(value) => bool</code>) which defines when a value is inherited.',
						'inheritValue': 'Value that gets set when inherited.',
					}}
					additionalPanels={[{ title: 'Current value', content: <pre>{JSON.stringify(value4, null, 2)}</pre> }]}
				>
					<ResponsiveNumberPicker
						value={value4}
						onChange={(value) => setValue4(value)}
						inheritCheck={(value) => value === -1}
						inheritValue={-1}
						{...commonNumProps}
					/>
				</ItemShowcase>

				<ItemShowcase
					title='String values'
					propsUsed={{
						'stringValues': 'Returns values as strings',
					}}
					additionalPanels={[{ title: 'Current value', content: <pre>{JSON.stringify(value5, null, 2)}</pre> }]}
				>
					<ResponsiveNumberPicker
						value={value5}
						onChange={(value) => setValue5(value)}
						noBottomSpacing
						stringValues
						inheritValue=''
						{...commonNumProps}
					/>
				</ItemShowcase>
			</div>

			<CodeBlock
				language='jsx'
				code={`<ResponsiveNumberPicker
	icon={icons.emptyCircle}
	label='Picker'
	value={value}
	onChange={(value) => setValue(value)}
	min={0}
	max={50}

	// ----------------------------------------------------------------
	// Other examples, each example includes the props above this text.
	// ----------------------------------------------------------------

	// Reset buttons
	resetButton={0}
	resetButton={20}

	// Custom inherit value
	inheritValue={-1}

	// String values
	stringValues
	inheritValue=''
/>`}
			/>

			<div className='es-w-full es-h-px es-bg-cool-gray-100' />

			<h2>Slider</h2>

			<div className='es-display-flex es-flex-wrap es-gap-5!'>
				<ItemShowcase
					title='Basic control'
					propsUsed={{
						'inheritValue': 'Value that gets set when inherited.',
					}}
					additionalPanels={[{ title: 'Current value', content: <pre>{JSON.stringify(slideValue, null, 2)}</pre> }]}
				>
					<ResponsiveSlider
						value={slideValue}
						onChange={(value) => setSlideValue(value)}
						{...commonSlideProps}
					/>
				</ItemShowcase>

				<ItemShowcase
					title='Reset buttons'
					propsUsed={{
						'resetButton': 'Adds a "Reset" button.',
					}}
					additionalPanels={[
						{ title: 'Current value (top)', content: <pre>{JSON.stringify(slideValue2, null, 2)}</pre> },
						{ title: 'Current value (bottom)', content: <pre>{JSON.stringify(slideValue3, null, 2)}</pre> },
					]}
				>
					<ResponsiveSlider
						value={slideValue2}
						onChange={(value) => setSlideValue2(value)}
						{...commonSlideProps}
						resetButton={0}
						noBottomSpacing={false}
					/>

					<ResponsiveSlider
						value={slideValue3}
						onChange={(value) => setSlideValue3(value)}
						{...commonSlideProps}
						resetButton={20}
					/>
				</ItemShowcase>

				<ItemShowcase
					title='Custom "inherit" value'
					propsUsed={{
						'inheritCheck': 'Callback (<code>(value) => bool</code>) which defines when a value is inherited.',
						'inheritValue': 'Value that gets set when inherited.',
					}}
					additionalPanels={[{ title: 'Current value', content: <pre>{JSON.stringify(slideValue4, null, 2)}</pre> }]}
				>
					<ResponsiveSlider
						value={slideValue4}
						onChange={(value) => setSlideValue4(value)}
						inheritCheck={(value) => value === -1}
						inheritValue={-1}
						{...commonSlideProps}
					/>
				</ItemShowcase>

				<ItemShowcase
					title='String values'
					propsUsed={{
						'stringValues': 'Returns values as strings',
					}}
					additionalPanels={[{ title: 'Current value', content: <pre>{JSON.stringify(slideValue5, null, 2)}</pre> }]}
				>
					<ResponsiveSlider
						value={slideValue5}
						onChange={(value) => setSlideValue5(value)}
						noBottomSpacing
						stringValues
						inheritValue=''
						{...commonSlideProps}
					/>
				</ItemShowcase>
			</div>

			<CodeBlock
				language='jsx'
				code={`<ResponsiveSlider
	icon={icons.emptyCircle}
	label='Slider'
	value={value}
	onChange={(value) => setValue(value)}
	min={0}
	max={50}

	// ----------------------------------------------------------------
	// Other examples, each example includes the props above this text.
	// ----------------------------------------------------------------

	// Reset buttons
	resetButton={0}
	resetButton={20}

	// Custom inherit value
	inheritValue={-1}

	// String values
	stringValues
	inheritValue=''
/>`}
			/>

			<div className='es-w-full es-h-px es-bg-cool-gray-100' />

			<h2>Toggle button</h2>

			<div className='es-display-flex es-flex-wrap es-gap-5!'>
				<ItemShowcase
					title='Basic control'
					propsUsed={{
						'inheritValue': 'Value that gets set when inherited.',
					}}
					additionalPanels={[{ title: 'Current value', content: <pre>{JSON.stringify(toggleValue, null, 2)}</pre> }]}
				>
					<ResponsiveToggleButton
						value={toggleValue}
						onChange={(value) => setToggleValue(value)}
						{...commonToggleProps}
					/>
				</ItemShowcase>

				<ItemShowcase
					title='Custom inherit value'
					propsUsed={{
						'inheritCheck': 'Callback (<code>(value) => bool</code>) which defines when a value is inherited.',
						'inheritValue': 'Value that gets set when inherited.',
					}}
					additionalPanels={[{ title: 'Current value', content: <pre>{JSON.stringify(toggleValue2, null, 2)}</pre> }]}
				>
					<ResponsiveToggleButton
						value={toggleValue2}
						onChange={(value) => setToggleValue2(value)}
						inheritCheck={(value) => value === -1}
						inheritValue={-1}
						{...commonToggleProps}
					/>
				</ItemShowcase>

				<ItemShowcase
					title='String values'
					propsUsed={{
						'stringValues': 'Returns values as strings',
					}}
					additionalPanels={[{ title: 'Current value', content: <pre>{JSON.stringify(toggleValue3, null, 2)}</pre> }]}
				>
					<ResponsiveToggleButton
						value={toggleValue3}
						onChange={(value) => setToggleValue3(value)}
						noBottomSpacing
						stringValues
						inheritValue=''
						{...commonToggleProps}
					/>
				</ItemShowcase>
			</div>

			<CodeBlock
				language='jsx'
				code={`<ResponsiveToggleButton
	icon={icons.emptyCircle}
	label='Toggle'
	value={value}
	onChange={(value) => setValue(value)}

	// ----------------------------------------------------------------
	// Other examples, each example includes the props above this text.
	// ----------------------------------------------------------------

	// Custom inherit value
	inheritCheck={(value) => value === -1}
	inheritValue={-1}

	// String values
	stringValues
	inheritValue=''
/>`}
			/>

			<div className='es-w-full es-h-px es-bg-cool-gray-100' />

			<h2>Width & offset responsive slider</h2>

			<CodeBlock
				language='jsx'
				filename='manifest.json'
				code={`{
	...
	"attributes": {
		...
		"demoAttributeWidthLarge": {
			"type": "string"
		},
		"demoAttributeWidthDesktop": {
			"type": "string"
		},
		"demoAttributeWidthTablet": {
			"type": "string"
		},
		"demoAttributeWidthMobile": {
			"type": "string"
		},

		"demoAttributeOffsetLarge": {
			"type": "string"
		},
		"demoAttributeOffsetDesktop": {
			"type": "string"
		},
		"demoAttributeOffsetTablet": {
			"type": "string"
		},
		"demoAttributeOffsetMobile": {
			"type": "string"
		}
	},
	"responsiveAttributes": {
		...
		"demoAttributeWidth": {
			"large": "demoAttributeWidthLarge",
			"desktop": "demoAttributeWidthDesktop",
			"tablet": "demoAttributeWidthTablet",
			"mobile": "demoAttributeWidthMobile"
		},
		"demoAttributeOffset": {
			"large": "demoAttributeOffsetLarge",
			"desktop": "demoAttributeOffsetDesktop",
			"tablet": "demoAttributeOffsetTablet",
			"mobile": "demoAttributeOffsetMobile"
		}
	}
}`}
			/>

			<div className='es-display-flex es-flex-wrap es-gap-5!'>
				<ItemShowcase
					title='Basic control'
					propsUsed={{
						'inheritValue': 'Value that gets set when inherited.',
					}}
					additionalPanels={[{ title: 'Current value', content: <pre>{JSON.stringify(woRsValue, null, 2)}</pre> }]}
				>
					<WidthOffsetRangeSlider
						value={woRsValue}
						onChange={(value) => setWoRsValue(value)}
						inheritValue=''
						noBottomSpacing
					/>
				</ItemShowcase>

				<ItemShowcase
					title='Fullwidth toggle'
					propsUsed={{
						'inheritValue': 'Value that gets set when inherited.',
						'fullWidthToggle': 'Shows the "Fullwidth" toggle, which adds 2 extra columns to allow placing inside the gutter',
					}}
					additionalPanels={[{ title: 'Current value', content: <pre>{JSON.stringify(woRsValue2, null, 2)}</pre> }]}
				>
					<WidthOffsetRangeSlider
						value={woRsValue2}
						onChange={(value) => setWoRsValue2(value)}
						inheritValue=''
						fullWidthToggle
						noBottomSpacing
					/>
				</ItemShowcase>

				<ItemShowcase
					title='Auto offset toggle'
					propsUsed={{
						'inheritValue': 'Value that gets set when inherited.',
						'autoOffsetToggle': 'Shows the "Automatic offset" toggle on the first breakpoint, which sets the offset to <code>auto</code>',
					}}
					additionalPanels={[{ title: 'Current value', content: <pre>{JSON.stringify(woRsValue3, null, 2)}</pre> }]}
				>
					<WidthOffsetRangeSlider
						value={woRsValue3}
						onChange={(value) => setWoRsValue3(value)}
						inheritValue=''
						autoOffsetToggle
						noBottomSpacing
					/>
				</ItemShowcase>

				<ItemShowcase
					title='Custom "inherit" value'
					propsUsed={{
						'inheritCheck': 'Callback (<code>(value) => bool</code>) which defines when a value is inherited.',
						'inheritValue': 'Value that gets set when inherited.',
					}}
					additionalPanels={[{ title: 'Current value', content: <pre>{JSON.stringify(woRsValue4, null, 2)}</pre> }]}
				>
					<WidthOffsetRangeSlider
						value={woRsValue4}
						onChange={(value) => setWoRsValue4(value)}
						inheritCheck={(value) => typeof value === 'undefined'}
						inheritValue={undefined}
						noBottomSpacing
					/>
				</ItemShowcase>

				<ItemShowcase
					title='Numeric values'
					propsUsed={{
						'numericValues': 'Value that gets set when inherited.',
					}}
					additionalPanels={[{ title: 'Current value', content: <pre>{JSON.stringify(woRsValue5, null, 2)}</pre> }]}
				>
					<WidthOffsetRangeSlider
						value={woRsValue5}
						onChange={(value) => setWoRsValue5(value)}
						noBottomSpacing
						numericValues
					/>
				</ItemShowcase>
			</div>

			<CodeBlock
				language='jsx'
				code={`<WidthOffsetRangeSlider
	value={value}
	onChange={(value) => setValue(value)}
	inheritValue=''

	// ----------------------------------------------------------------
	// Other examples, each example includes the props above this text.
	// ----------------------------------------------------------------

	// Fullwidth toggle
	fullWidthToggle

	// Auto offset toggle
	autoOffsetToggle

	// Custom inherit value
	inheritCheck={(value) => typeof value === 'undefined'}
	inheritValue={undefined}

	// Numeric values
	numericValues
/>`}
			/>
		</>
	);
};
