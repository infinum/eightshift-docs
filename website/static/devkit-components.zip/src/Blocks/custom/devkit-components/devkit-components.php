<?php

/**
 * Template for the DevKit Components Block view.
 *
 * @package DevkitComponents
 */

?>

<div>This is only rendered in the editor.</div>
