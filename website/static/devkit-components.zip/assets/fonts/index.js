/**
 * This is the main entry point for project fonts.
 *
 * Usage: `WordPress admin screen`, `WordPress frontend screen`, `WordPress admin editor`.
 */
import './InterVariable.woff2';
import './InterVariable-Italic.woff2';
import './FantasqueSansM-Regular.woff2';
