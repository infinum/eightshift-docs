# Changelog for the DevKit components
All notable changes to this project will be documented in this file.

This projects adheres to [Semantic Versioning](https://semver.org/) and [Keep a CHANGELOG](https://keepachangelog.com/).

## [Unreleased] - TBD

### Added

### Changed

### Deprecated

### Removed

### Fixed

## [1.0.0] - <setup-date>

Initial tagged release.

[Unreleased]: https://github.com/infinum/eightshift-boilerplate/compare/master...HEAD


[1.0.0]: https://github.com/infinum/eightshift-boilerplate/compare/INIT_COMMIT...1.0.0`