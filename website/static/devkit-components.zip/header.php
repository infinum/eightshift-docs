<?php

/**
 * Main header file
 *
 * @package DevkitComponents
 */

use DevkitComponents\AdminMenus\ReusableBlocksHeaderFooter;

?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<?php
	wp_head();
	?>
</head>
<body <?php body_class(); ?>>

<main class="main-content" id="main-content">
