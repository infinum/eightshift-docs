<?php

/**
 * Template for the Jumbotron Block view.
 *
 * @package Devkittest
 */

use DevkittestVendor\EightshiftLibs\Helpers\Components;

$manifest = Components::getManifest(__DIR__);

echo Components::render('jumbotron', Components::props('jumbotron', $attributes));
