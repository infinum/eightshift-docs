import React from 'react';

export default {
	title: 'Components/Header',
};

export const editor = () => (
	<div />
	// <LayoutThreeColumnsEditor
	// 	selectorClass={'header'}
	// 	layoutThreeColumnsLeft={[
	// 		<LogoEditor key={'logo'} />,
	// 	]}
	// 	layoutThreeColumnsCenter={[
	// 	]}
	// 	layoutThreeColumnsRight={[
	// 		<HamburgerEditor key={'hamburger'} />,
	// 	]}
	// />
);
