/**
 * This is the main entry point for project scripts used for the `WordPress admin screen`.
 *
 * Usage: `WordPress admin screen`.
 */
