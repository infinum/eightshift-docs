/**
 * This is the main entry point for project fonts.
 *
 * Usage: `WordPress admin screen`, `WordPress frontend screen`, `WordPress admin editor`.
 */
import './DMSans-Bold.woff2';
import './DMSans-BoldItalic.woff2';
import './DMSans-Italic.woff2';
import './DMSans-Medium.woff2';
import './DMSans-MediumItalic.woff2';
import './DMSans-Regular.woff2';
