/**
 * This is the main entry point for project images.
 *
 * Usage: `WordPress admin screen`, `WordPress frontend screen`, `WordPress admin editor`.
 */

import './logo.svg';
