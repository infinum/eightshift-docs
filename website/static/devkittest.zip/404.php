<?php

/**
 * 404 error page
 *
 * @package Devkittest
 */

get_header();

esc_html_e('404 - not found', 'devkittest');

get_footer();
