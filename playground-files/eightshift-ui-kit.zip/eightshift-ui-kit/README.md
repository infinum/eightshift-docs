# Update guide

## dev -> v1

### Update dependencies

#### PHP
`"infinum/eightshift-libs"` -> `10.0.0`
`"php-stubs/wordpress-stubs"` -> `6.8.0`
`"szepeviktor/phpstan-wordpress"` -> `2.0.1`

#### JS
Check `package.json`

### Update Libs if needed
Follow [Libs guide]([https://](https://eightshift.com/docs/migrations/13-14)).

### Add style/script dependency overrides.
Since Libs v10, if you don't have `application-blocks.js` in your project, add this to `EnqueueBlocks.php`:

```php
/**
 * Get front end style dependencies
 *
 * @link https://developer.wordpress.org/reference/functions/wp_enqueue_style/
 *
 * @return array<int, string> List of all the style dependencies.
 */
protected function getBlockFrontendStyleDependencies(): array
{
	return [];
}

/**
 * Get style dependencies
 *
 * @link https://developer.wordpress.org/reference/functions/wp_enqueue_style/
 *
 * @return string[] List of all the style dependencies.
 */
protected function getBlockEditorStyleDependencies(): array
{
	return [];
}
```

### Fix `wrapperUse`in options
`wrapper-options.js`
```diff
...
export const WrapperOptions = ({ attributes, setAttributes }) => {
+	const wrapperUse = checkAttr('wrapperUse', attributes, manifest);
	const wrapperNoControls = checkAttr('wrapperNoControls', attributes, manifest);
	...

+	if (!wrapperUse || wrapperNoControls || wrapperDisabledOptions === 'all' || hiddenOptions?.backgroundType) {
		return null;
	}
...
```

### Fix button in nav
`site-navigation-options.js`
Line 169
```diff
- {...props('primary', attributes, {
+ {...props('button', attributes, {
```

### Fix new tab on nested desktop items
`site-navigation.php`
Line 112:
```diff
<a
	class="<?php echo esc_attr(Helpers::tailwindClasses('topLevelItem', $attributes, $manifest, 'hover:bg-primary-5 transition')); ?>"
	role="menuitem"
	href="<?php echo str_starts_with($url, '#') ? esc_attr($url) : esc_url($url); ?>"
+	<?php if ($subItem['newTab'] ?? false) { ?>
+		target="_blank"
+		rel="noopener noreferrer"
+	<?php } ?>
```

Line 152:
```diff
<a
	class="<?php echo esc_attr(Helpers::tailwindClasses('topLevelItem', $attributes, $manifest, '*:first:ml-24')); ?>"
	role="menuitem"
	href="<?php echo str_starts_with($url, '#') ? esc_attr($url) : esc_url($url); ?>"
+	<?php if ($nestedSubItem['newTab'] ?? false) { ?>
+		target="_blank"
+		rel="noopener noreferrer"
+	<?php } ?>
>
```

### Fix markers visible in <details> in Safari
To the end of `tailwind.css` add:
```css
/* Resets */
summary::-webkit-details-marker {
	@apply hidden;
}
```
### Fix list indents
`src/Blocks/custom/list/manifest.json`, line 95:
```diff
- "twClasses": "[&_ul]:ml-[1em] [&_ol]:ml-[1em]",
+ "twClasses": "[&_:where(ul,ol)]:ml-[1.5em] list-inside",
```

`src/Blocks/custom/list-item/list-item.php`, line 16:
```diff
- <li class="pl-4 sm:pl-8">
+ <li>
```

### Update video captions styling
`src/Blocks/components/video/video.php`, line 169:
```diff
- <media-captions class="..."></media-captions>
+ <?php // phpcs:ignore Generic.Files.LineLength.TooLong ?>
+ <media-captions	class="absolute left-0 empty:hidden right-0 bottom-16 px-8 py-4 sm:px-24 sm:py-12 mx-auto w-fit z-10 text-xs sm:text-h5 md:text-h4 font-medium bg-black/80 backdrop-blur-2xl select-none break-words opacity-0 transition-[opacity,bottom] group-data-[captions]/video:opacity-100 group-data-[controls]/video:bottom-120 group-data-[preview]/video:opacity-0"></media-captions>
```

### Remove editor overrides if empty
1. Remove `editor-overrides.css`
2. In `application-blocks-editor.js`:
	```diff
	- import './styles/editor/editor-overrides.css';
	```

### Fix video aspect ratio
Check `fix video aspect ratio` and `update video-related blocks` commits.

### Fix font definitions.
`tailwind.css`

```diff
- --font-primary: 'Inter Variable', system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, 'Noto Sans', sans-serif, 'Apple Color Emoji', 'Segoe UI Emoji', 'Segoe UI Symbol', 'Noto Color Emoji';
- --font-secondary: 'Inter Variable', system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, 'Noto Sans', sans-serif, 'Apple Color Emoji', 'Segoe UI Emoji', 'Segoe UI Symbol', 'Noto Color Emoji';
+ --default-font-family: 'Inter Variable', system-ui, sans-serif;
+ --font-display: 'Inter Variable', system-ui, sans-serif;
```

### Fix Tabs focus style
`src/Blocks/custom/tabs/manifest.json`
```diff
"tabListItem": {
-	"twClasses": "px-8 py-11 cursor-pointer relative rounded-2xs after:content-[''] after:absolute after:bottom-0 after:left-0 after:right-0 after:h-2 aria-selected:after:bg-primary-60 not-aria-selected:hover:after:bg-primary-20 transition after:transition focus:outline-hidden focus-visible:outline-3 outline-primary-50 outline-offset-3 focus-visible:after:bg-primary-20",
+	"twClasses": "px-8 py-11 cursor-pointer relative rounded-2xs after:content-[''] after:absolute after:bottom-0 after:left-0 after:right-0 after:h-2 aria-selected:after:bg-primary-60 not-aria-selected:hover:after:bg-primary-20 transition after:transition focus:outline-hidden focus-visible:outline-3 focus-visible:outline-solid outline-primary-50 outline-offset-3 focus-visible:after:bg-primary-20!",
```

### Add gradient support to Wrapper
Follow the `add gradient support to wrapper` commit.

### Tweak Call to action and Hero content sizes and button layouts
Follow the `tweak hero and call-to-action content sizes` and `tweak buttons in call-to-action and hero` commits.

### Tweak Image aspect ratios.
Follow the `tweak image aspect ratio options` commit.

### Tweak Logopond offset logic
Follow the `tweak logopond offset logic` commit.

### Tweak Carousel inserter
Follow the `tweak carousel inserter` commit.

### Fix video captions.
Follow the `fix video caption position` commit.

### Fix Advanced accordion bugs and improve its UX.
Follow the `fix advanced accordion` commit.

### Update nomenclature for simple and advanced accordion blocks
Files, strings and variables for `simple-accordion` and `advanced-accordion` blocks have been updated to `accordion-simple` and `accordion-advanced` naming convention.

Follow the `Rename simple & advanced accordion files` and `Rename strings and variables in accordion blocks` commits.

### Add default font size to List.
`src/Blocks/custom/list/manifest.json`, line 30

```diff
"listFontSize": {
	"type": "string",
+	"default": "base"
},
```

### Fix List item `parent` prop in manifest
`src/Blocks/custom/list-item/manifest.json`

```diff
...
"parent": [
-	"eightshift/list"
+	"eightshift-boilerplate/list"
],
```

### Fix list item rendering with custom markers in editor
`src/Blocks/custom/list-item/components/list-item-editor.js`

```diff
<RichText
	...
	onMerge={onMerge}
+	className='inline-block'
/>
```

### Fix typo in Rive manifest causing wrong default option
`src/Blocks/components/rive/manifest.json`
```diff
"riveFit": {
	"type": "string",
-	"default": "contain "
+	"default": "contain"
}
```

### Tweak Hero layout on tablet
Follow the `tweak hero content on tablet` commit.

### Tweak Footer options and minor layout issue
Follow the `tweak footer options` commit.

### Tweak Paragraph options
Follow the `tweak paragraph` commit.

### Fix image sizing
`src/Blocks/components/image/manifest.json`

```diff
"tailwind": {
	"parts": {
		"base": {
-			"twClasses": ""
+			"twClasses": "size-full"
		},
```

### Fix Carousel item sizing
Follow the `fix carousel item sizing` commit.

### Fix breadcrumbs
Follow the `fix breadcrumbs` commit

### Tweak block option tab spacings
Do a search-replace:
```diff
- <TabList className='es:px-4'>
+ <TabList className='es:px-4 es:mt-3'>
```

### Add Eightshift Utils caps
Follow the `add es utils caps` commit.

### Add Table block
Follow `add table block` and `add standalone option to table` commits.

### Rework icon picker
Follow the `rework icon picker` commit.

### Update PHPStan config
`phpstan.neon.dist`

```diff
includes:
    - vendor/szepeviktor/phpstan-wordpress/extension.neon
parameters:
    level: 6
    inferPrivatePropertyTypeFromConstructor: true
    treatPhpDocTypesAsCertain: false
    bootstrapFiles:
        - vendor-prefixed/autoload.php
    paths:
        - src/
    ignoreErrors:
        # Block templates
        - '#^Variable \$attributes might not be defined\.#'
        - '#^Variable \$renderContent might not be defined\.#'
+        - '#^Variable \$manifest might not be defined\.#'
        - identifier: missingType.generics
```

### Add new features to Site navigation
Follow the `update site navigation` commit.

### Tweak left/right content margins
`tailwind.css`

```diff
@utility block-inset-x {
-	@apply px-18 sm:px-56 md:px-80;
+	@apply px-18 sm:px-56 md:px-80 min-[120rem]:px-120 min-[160rem]:px-160;
}
```

```diff
@utility block-inset-x-half {
-	@apply px-9 sm:px-28 md:px-40;
+	@apply px-9 sm:px-28 md:px-40 min-[120rem]:px-60 min-[160rem]:px-80;
}
```

### Fix Layout content overflows
Follow the `fix layout content overflows` commit.

### Remove all manifest vars from PHP

```diff
- $manifest = Helpers::getManifestByDir(__DIR__);
```

### Rename 'Feature content' to 'Content listing'
Follow the `rename featured content` commit.

### Improve Card: Basic layout and behavior
Follow `tweak card basic alignment and layout` and `fix card basic editor view` commits.

### Add Featured content block
Follow the `add featured content block` commit.

### Update dependencies
Follow the `update dependencies` commit.

### Implement husky + lint-staged
Follow commit with the name `Implement husky + lint-staged`
Update theme name in `./.husky/pre-commit` file for `theme_path` variable

### Fix blocks keywords in manifests
Follow commit with the name `Fix blocks keywords in manifests`

### Fix Carousel spacing in Editor where Loop is enabled
Follow commit with the name `Fix Carousel spacing in Editor where Loop is enabled`

### Fix Button not-enabled / cursor
Follow commit with the name `Fix Button not-enabled / cursor`

### Update Accordion Advanced `tabListItem` grid row class
Follow commit with the name `Update Accordion Advanced tabListItem grid row class`

### Fix Accordion Advanced - pointer, outline, hover, grid align
Follow commit with the name `Fix Accordion Advanced - pointer, outline, hover, grid align`

### Fix Site Navigation pointer style
Follow commit with the name `Fix Site Navigation pointer style`

### Fix Site Navigation edge-case for level 2 item having only an icon
Follow commit with the name `Fix Site Navigation edge-case for level 2 item having only an icon`

### Fix Sub Section options formatting
Follow commit with the name `Fix Sub Section options formatting`

### Fix List block pasting not adding content to items
Follow commit with the name `Fix List block pasting not adding content to items`

### Add max number of sections to Site Footer
Follow commit with the name `Add max number of sections to Site Footer`

### Add styling for fourth column in Site Footer
Follow commit with the name `Add styling for fourth column in Site Footer`

### Fix Tabs animation flickering on Firefox and Safari
Follow commit with the name `Fix Tabs animation flickering on Firefox and Safari`

### Ensure Button label is not rendered if it is turned off
Follow commit with the name `Ensure Button label is not rendered if it is turned off`

### Enforce Label or Icon for Button component
Follow commit with the name `Enforce Label or Icon for Button component`

### Implement "Skip to main content" for ally
Follow commit with the name `Implement "Skip to main content" for ally`

### Add "target" property to .swcrc
Follow commit with the name `Add "target" property to .swcrc`

### Fix Image `imageId` attribute type
Follow commit with the name `Fix Image imageId attribute type`
[!NOTE]
Be aware that `imageId` was not being set as attribute before this fix and this update might cause critical errors because existing images will not have the `imageId` attribute set.

### Add support for `webp` image format if file exists
Follow commit with the name `Add support for webp image format if file exists`

### Add styling for links within `<p>` or `<li>` tags
Follow commit with the name `Add styling for links within <p> or <li> tags`

### Update `list-check` utility to have a transparent cutout
Follow commit with the name `Update list-check utility to have a transparent cutout`

### Replace `npm` commands with `bun` where applicable
Follow commit with the name `Replace npm commands with bun where applicable`

### Update wrapper overflow to avoid collapsing margins
Follow commit with the name `Update wrapper overflow to avoid collapsing margins`

## v1 -> v1.1

### Update dependencies
Follow the `update dependencies` commit.

### Make button options less error-prone
Follow the `improve button options` commit.

### Fix warning in `breadcrumbs`
`src/Blocks/components/breadcrumbs`, line 63

```diff
- <?php if (!$isHome && ($interimPages[count($interimPages) - 1] ?? false)) { ?>
+ <?php if (!$isHome && ($interimPages[count($interimPages) - 1] ?? false)) { ?>
```

### Fix font loading
Follow the `fix font loading` commit.

### Update aspect ratio nomenclature
Follow the `Update aspect ratio nomenclature for Video component` commit. Also search-replace these values in database.

### Update .gitignore in the theme
```diff
+ /eightshift
```

### Fix font loading in editor
Add the following to `src/Blocks/assets/styles/application-blocks-editor.css`
```css
:is(.editor-styles-wrapper) {
	font-family: var(--default-font-family);
}
```

## v1.1 -> v1.2

### Fix link override style
Follow the `fix link override styling` commit.

### Update dependencies
Follow the `update dependencies` commit.

### Fix video controls focus styles
Follow the `fix video controls focus styles` commit.

### Replace legacy AsyncSelect with AsyncSelectNext in Featured content
Follow the `switch featured content to use asyncselectnext` commit.

### Fix Carousel item alignment and make it configurable
Follow the `add alignment options to carousel` commit.

### UX improvements
Follow the `add aspect ratio previews for image aspect ratio option` commit.

### Rework Content listing
(adds updated pagination and filter design, search; new options UI; and various other improvements)
Follow the `add search to content listing and update design` commit.

### Remove post type label from Featured content cards
`src/Blocks/custom/featured-content/featured-content.php`, line 23
```diff
- 'cardBasicCaptionText' => get_the_date('F j, Y', $postId) . ' · ' . get_post_type_object(get_post_type($postId))->labels->singular_name,
+ 'cardBasicCaptionText' => get_the_date('F j, Y', $postId),
```
