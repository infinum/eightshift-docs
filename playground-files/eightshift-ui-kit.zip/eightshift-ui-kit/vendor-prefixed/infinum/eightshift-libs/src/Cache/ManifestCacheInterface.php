<?php

/**
 * File containing an interface for holding Manifest Cache functionality.
 *
 * It is used to provide manifest.json file location stored in the transient cache.
 *
 * @package EightshiftLibs\Cache
 *
 * @license MIT
 * Modified by eightshift-ui-kit on 15-July-2025 using {@see https://github.com/BrianHenryIE/strauss}.
 */

declare(strict_types=1);

namespace EightshiftUIKitVendor\EightshiftLibs\Cache;

/**
 * Interface ManifestCacheInterface
 */
interface ManifestCacheInterface
{
	/**
	 * Set all cache.
	 *
	 * @return void
	 */
	public function setAllCache(): void;
}
