<?php

/**
 * Class that registers WP-CLI commands used as parent placeholders.
 *
 * @package EightshiftUIKitVendor\EightshiftLibs\Cli\ParentGroups
 *
 * @license MIT
 * Modified by eightshift-ui-kit on 15-July-2025 using {@see https://github.com/BrianHenryIE/strauss}.
 */

declare(strict_types=1);

namespace EightshiftUIKitVendor\EightshiftLibs\Cli\ParentGroups;

use WP_CLI_Command;

/**
 * Initially setup your project like theme, plugin, project, etc. These commands should be used only once.
 */
class CliInit extends WP_CLI_Command
{
	/**
	 * Cli command name parent constant.
	 */
	public const COMMAND_NAME = 'init';
}
