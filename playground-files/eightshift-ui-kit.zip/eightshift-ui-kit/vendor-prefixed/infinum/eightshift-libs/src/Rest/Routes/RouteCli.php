<?php

/**
 * Class that registers WP-CLI command for Rest Routes.
 *
 * @package EightshiftUIKitVendor\EightshiftLibs\Rest\Routes
 *
 * @license MIT
 * Modified by eightshift-ui-kit on 15-July-2025 using {@see https://github.com/BrianHenryIE/strauss}.
 */

declare(strict_types=1);

namespace EightshiftUIKitVendor\EightshiftLibs\Rest\Routes;

use EightshiftUIKitVendor\EightshiftLibs\Cli\AbstractCli;
use EightshiftUIKitVendor\EightshiftLibs\Cli\ParentGroups\CliCreate;
use EightshiftUIKitVendor\EightshiftLibs\Helpers\Helpers;
use WP_CLI;

/**
 * Class RouteCli
 */
class RouteCli extends AbstractCli
{
	/**
	 * Route method enum.
	 *
	 * @var array<string, string>
	 */
	public const VERB_ENUM = [
		'GET' => 'static::READABLE',
		'POST' => 'static::CREATABLE',
		'PATCH' => 'static::EDITABLE',
		'PUT' => 'static::UPDATEABLE',
		'DELETE' => 'static::DELETABLE',
	];

	/**
	 * Get WP-CLI command parent name
	 *
	 * @return string
	 */
	public function getCommandParentName(): string
	{
		return CliCreate::COMMAND_NAME;
	}

	/**
	 * Get WP-CLI command name
	 *
	 * @return string
	 */
	public function getCommandName(): string
	{
		return 'rest-route';
	}

	/**
	 * Define default arguments.
	 *
	 * @return array<string, int|string|boolean>
	 */
	public function getDefaultArgs(): array
	{
		return [
			'endpoint_slug' => 'test',
			'method' => 'get',
		];
	}

	/**
	 * Get WP-CLI command doc
	 *
	 * @return array<string, mixed>
	 */
	public function getDoc(): array
	{
		return [
			'shortdesc' => 'Create REST-API route service class.',
			'synopsis' => [
				[
					'type' => 'assoc',
					'name' => 'endpoint_slug',
					'description' => 'The name of the endpoint slug. Example: test-route.',
					'optional' => false,
				],
				[
					'type' => 'assoc',
					'name' => 'method',
					'description' => 'HTTP verb must be one of: GET, POST, PATCH, PUT, or DELETE.',
					'optional' => true,
					'default' => $this->getDefaultArg('method'),
					'options' => [
						'GET',
						'POST',
						'PATCH',
						'PUT',
						'DELETE',
					],
				],
			],
			'longdesc' => $this->prepareLongDesc("
				## USAGE

				Used to create REST-API service class to register custom route.

				## EXAMPLES

				# Create service class:
				$ wp {$this->commandParentName} {$this->getCommandParentName()} {$this->getCommandName()} --endpoint_slug='test-route'

				## RESOURCES

				Service class will be created from this example:
				https://github.com/infinum/eightshift-libs/blob/develop/src/Rest/Routes/RouteExample.php
			"),
		];
	}

	/* @phpstan-ignore-next-line */
	public function __invoke(array $args, array $assocArgs)
	{
		$assocArgs = $this->prepareArgs($assocArgs);

		$this->getIntroText($assocArgs);

		// Get Props.
		$endpointSlug = $this->prepareSlug($this->getArg($assocArgs, 'endpoint_slug'));
		$method = \strtoupper($this->getArg($assocArgs, 'method'));

		// Get full class name.
		$className = $this->getFileName($endpointSlug);
		$className = $className . $this->getClassShortName();


		// If method is invalid throw error.
		if (!isset(self::VERB_ENUM[$method])) {
			WP_CLI::error("Invalid method: $method, please use one of GET, POST, PATCH, PUT, or DELETE");
		}


		// Read the template contents, and replace the placeholders with provided variables.
		$this->getExampleTemplate(__DIR__, $this->getClassShortName())
			->renameClassNameWithPrefix($this->getClassShortName(), $className)
			->renameGlobals($assocArgs)
			->searchReplaceString($this->getArgTemplate('endpoint_slug'), $endpointSlug)
			->searchReplaceString("'{$this->getArgTemplate('method')}'", static::VERB_ENUM[$method])
			->outputWrite(Helpers::getProjectPaths('src', ['Rest', 'Routes']), "{$className}.php", $assocArgs);
	}
}
