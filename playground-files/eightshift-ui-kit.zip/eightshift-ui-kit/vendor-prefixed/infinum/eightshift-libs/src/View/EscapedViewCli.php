<?php

/**
 * Class that registers WP-CLI command for Escape View.
 *
 * @package EightshiftLibs\View
 *
 * @license MIT
 * Modified by eightshift-ui-kit on 15-July-2025 using {@see https://github.com/BrianHenryIE/strauss}.
 */

declare(strict_types=1);

namespace EightshiftUIKitVendor\EightshiftLibs\View;

use EightshiftUIKitVendor\EightshiftLibs\Cli\AbstractCli;
use EightshiftUIKitVendor\EightshiftLibs\Cli\ParentGroups\CliCreate;
use EightshiftUIKitVendor\EightshiftLibs\Helpers\Helpers;

/**
 * Class EscapedViewCli
 */
class EscapedViewCli extends AbstractCli
{
	/**
	 * Get WP-CLI command parent name
	 *
	 * @return string
	 */
	public function getCommandParentName(): string
	{
		return CliCreate::COMMAND_NAME;
	}

	/**
	 * Get WP-CLI command name
	 *
	 * @return string
	 */
	public function getCommandName(): string
	{
		return 'escaped-view';
	}

	/**
	 * Get WP-CLI command doc
	 *
	 * @return array<string, array<int, array<string, bool|string>>|string>
	 */
	public function getDoc(): array
	{
		return [
			'shortdesc' => 'Create escaped view service class.',
			'longdesc' => $this->prepareLongDesc("
				## USAGE

				Used to create escaped view service class to list all tags you want to escape or enable.

				## EXAMPLES

				# Create service class:
				$ wp {$this->commandParentName} {$this->getCommandParentName()} {$this->getCommandName()}

				## RESOURCES

				Service class will be created from this example:
				https://github.com/infinum/eightshift-libs/blob/develop/src/View/EscapedViewExample.php
			"),
		];
	}

	/* @phpstan-ignore-next-line */
	public function __invoke(array $args, array $assocArgs)
	{
		$assocArgs = $this->prepareArgs($assocArgs);

		$this->getIntroText($assocArgs);

		$className = $this->getClassShortName();

		// Read the template contents, and replace the placeholders with provided variables.
		$this->getExampleTemplate(__DIR__, $className)
			->renameClassName($className)
			->renameGlobals($assocArgs)
			->outputWrite(Helpers::getProjectPaths('src', 'View'), "{$className}.php", $assocArgs);
	}
}
