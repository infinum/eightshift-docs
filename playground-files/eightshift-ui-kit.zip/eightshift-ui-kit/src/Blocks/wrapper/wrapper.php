<?php

/**
 * Wrapper.
 *
 * @package EightshiftUIKit
 */

use EightshiftUIKitVendor\EightshiftLibs\Helpers\Helpers;

$wrapperUse = Helpers::checkAttr('wrapperUse', $attributes, $manifest);
$wrapperBackground = Helpers::checkAttr('wrapperBackground', $attributes, $manifest);

if (!$wrapperUse) {
	// phpcs:ignore Eightshift.Security.HelpersEscape.OutputNotEscaped
	echo $renderContent;
	return;
}

$wrapperId = Helpers::checkAttr('wrapperId', $attributes, $manifest);

$clonedAttributes = [...$attributes];

if (str_starts_with($wrapperBackground, '#')) {
	$clonedAttributes['wrapperBackground'] = '_custom';
}
?>

<div
	class="<?php echo esc_attr(Helpers::tailwindClasses('base', $clonedAttributes, $manifest)); ?>"
	<?php if (!empty($wrapperId)) { ?>
		id="<?php echo esc_attr($wrapperId); ?>"
	<?php } ?>
	<?php if (str_starts_with($wrapperBackground, '#')) { ?>
		style="--bg-color: <?php echo esc_attr($wrapperBackground); ?>;"
	<?php } ?>
>
	<?php
	// phpcs:ignore Eightshift.Security.HelpersEscape.OutputNotEscaped
	echo $renderContent;
	?>
</div>
