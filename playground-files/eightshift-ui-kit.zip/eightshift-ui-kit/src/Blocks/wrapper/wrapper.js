import { InspectorControls, InspectorAdvancedControls } from '@wordpress/block-editor';
import { WrapperEditor } from './components/wrapper-editor';
import { WrapperOptions } from './components/wrapper-options';
import { WrapperAdvancedOptions } from './components/wrapper-advanced-options';

export const Wrapper = (props) => {
	const {
		props: { setAttributes, attributes },
		children,
	} = props;

	return (
		<>
			<InspectorControls>
				<WrapperOptions
					attributes={attributes}
					setAttributes={setAttributes}
				/>
			</InspectorControls>

			<InspectorAdvancedControls>
				<WrapperAdvancedOptions
					attributes={attributes}
					setAttributes={setAttributes}
				/>
			</InspectorAdvancedControls>

			<WrapperEditor
				attributes={attributes}
				children={children}
				setAttributes={setAttributes}
			/>
		</>
	);
};
