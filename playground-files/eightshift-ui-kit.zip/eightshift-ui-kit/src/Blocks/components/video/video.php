<?php

/**
 * Video component.
 *
 * @package EightshiftUIKit
 */

use EightshiftUIKitVendor\EightshiftLibs\Helpers\Helpers;

$componentName = $attributes['componentName'] ?? $manifest['componentName'];

$videoUse = Helpers::checkAttr('videoUse', $attributes, $manifest);

if (!$videoUse) {
	return;
}

$additionalClass = $attributes['additionalClass'] ?? '';

$videoUrl = Helpers::checkAttr('videoUrl', $attributes, $manifest, true);

if (empty($videoUrl)) {
	return;
}

$videoMimeType = Helpers::checkAttr('videoMimeType', $attributes, $manifest);
$videoPosterUrl = Helpers::checkAttr('videoPosterUrl', $attributes, $manifest);
$videoLoop = Helpers::checkAttr('videoLoop', $attributes, $manifest);
$videoAutoplay = Helpers::checkAttr('videoAutoplay', $attributes, $manifest);
$videoPreload = Helpers::checkAttr('videoPreload', $attributes, $manifest);
$videoSubtitleTracks = Helpers::checkAttr('videoSubtitleTracks', $attributes, $manifest) ?? [];
$videoType = Helpers::checkAttr('videoType', $attributes, $manifest) ?? [];
$videoCaptionUse = Helpers::checkAttr('videoCaptionUse', $attributes, $manifest);
$videoCaptionText = Helpers::checkAttr('videoCaptionText', $attributes, $manifest);

$iconWithClass = function ($icon, $class) {
	// phpcs:ignore Eightshift.Security.HelpersEscape.OutputNotEscaped
	echo str_replace('<svg', "<svg class='{$class}'", $icon);
};

$hasCaptions = $videoType === 'local' && !empty($videoSubtitleTracks);
?>

<?php if ($videoCaptionUse) { ?>
	<figure class="<?php echo esc_attr($additionalClass['base'] ?? ''); ?>">
<?php } else { ?>
	<div class="<?php echo esc_attr($additionalClass['base'] ?? ''); ?>">
<?php } ?>


<media-player
	class="<?php echo esc_attr(Helpers::tailwindClasses('base', $attributes, $manifest, 'group/video ring-media-focus overflow-hidden text-white data-[focus]:outline-3 data-[focus]:outline-primary-60 data-[focus]:outline-solid outline-offset-3', $additionalClass['video'] ?? '')); ?>"
	src="<?php echo esc_attr($videoUrl); ?>"
	crossorigin

	<?php if ($videoAutoplay) { ?>
		autoplay
		muted
	<?php } ?>

	<?php if ($videoLoop) { ?>
		loop
	<?php } ?>

	playsinline
	load="visible"

	<?php if ($videoType === 'local' && !empty($videoPosterUrl)) { ?>
		poster-load="visible"
	<?php } ?>
>
	<media-provider>
		<?php
		if ($hasCaptions) {
			foreach ($videoSubtitleTracks as $track) {
				if (!($track['trackFileName'] ?? '') || !($track['kind'] ?? '') || !($track['label'])) {
					continue;
				}
				?>

			<track
				src="<?php echo esc_url($track['trackFileName'] ?? ''); ?>"
				kind="<?php echo esc_attr($track['kind'] ?? ''); ?>"
				label="<?php echo esc_attr($track['label'] ?? ''); ?>"
				<?php if ($track['srclang']) { ?>
					srclang="<?php echo esc_attr($track['srclang']); ?>"
				<?php } ?>
			>
				<?php
			}
		}
		?>
	</media-provider>

	<media-controls
		class="pointer-events-none absolute inset-0 z-10 size-full grid grid-rows-3 bg-gradient-to-t from-black/10 to-transparent opacity-0 transition-opacity data-[visible]:opacity-100"
	>
		<media-controls-group class="pointer-events-auto flex w-full items-center justify-center px-2 row-start-2">
			<?php // Large play button. ?>
			<media-play-button class="group relative inline-flex size-48 sm:size-64 md:size-96 cursor-pointer items-center justify-center rounded-full outline-hidden data-[focus]:outline-solid data-[focus]:outline-3 outline-primary-30 outline-offset-3 transition bg-black/50 backdrop-blur-lg">
				<?php
				$iconWithClass($manifest['resources']['icons']['play'], 'size-24 sm:size-32 md:size-48 not-group-data-[paused]:hidden');
				$iconWithClass($manifest['resources']['icons']['pause'], 'size-24 sm:size-32 md:size-48 group-data-[paused]:hidden');
				?>
			</media-play-button>
		</media-controls-group>

		<media-controls-group class="pointer-events-auto hidden w-full row-start-3 self-end h-fit group-data-[started]/video:block pb-16 bg-linear-to-t from-black/50 to-transparent bg-blend-multiply">
			<?php // Time slider. ?>
			<media-time-slider class="group relative inline-flex h-10 w-full cursor-pointer touch-none select-none items-center outline-none aria-hidden:hidden">
				<?php // Track. ?>
				<div class="relative z-0 h-8 w-full bg-white/50">
					<?php // Buffering progress. ?>
					<div class="absolute h-full w-[var(--slider-progress)] bg-white/10 will-change-[width]"></div>
					<?php // Current progress. ?>
					<div class="absolute z-10 h-full w-[var(--slider-fill)] bg-primary-50 will-change-[width]"></div>
				</div>

				<?php // Time display. ?>
				<media-slider-preview class="pointer-events-none flex flex-col items-center opacity-0 transition-opacity duration-200 data-[visible]:opacity-100" noClamp>
					<media-slider-value class="mb-16 text-sm text-white bg-black/80 backdrop-blur-sm px-5 py-1"></media-slider-value>
				</media-slider-preview>

				<?php // Thumb. ?>
				<div class="absolute left-[var(--slider-fill)] top-1/2 z-20 size-32 -translate-x-1/2 -translate-y-1/2 rounded-full bg-primary-60 outline-primary-30 outline-offset-3 transition-opacity will-change-[left] group-data-[dragging]:bg-primary-70 group-data-[focus]:outline-solid data-[focus]:outline-3"></div> <?php // phpcs:ignore Generic.Files.LineLength.TooLong ?>
			</media-time-slider>

			<div class="flex items-center px-16">
				<?php // Small play button. ?>
				<media-play-button class="group relative inline-flex size-48 cursor-pointer items-center justify-center rounded-sm outline-hidden data-[focus]:outline-solid data-[focus]:outline-3 outline-primary-30 transition">
					<?php
					$iconWithClass($manifest['resources']['icons']['play'], 'size-32 not-group-data-[paused]:hidden');
					$iconWithClass($manifest['resources']['icons']['pause'], 'size-32 group-data-[paused]:hidden');
					?>
				</media-play-button>

				<?php // Mute button. ?>
				<media-mute-button class="group relative inline-flex size-48 cursor-pointer items-center justify-center rounded-sm outline-hidden data-[focus]:outline-solid data-[focus]:outline-3 outline-primary-30 transition">
					<?php
					$iconWithClass($manifest['resources']['icons']['volumeOn'], 'hidden size-32 not-group-data-[state="muted"]:block');
					$iconWithClass($manifest['resources']['icons']['volumeOff'], 'hidden size-32 group-data-[state="muted"]:block');
					?>
				</media-mute-button>

				<?php if ($hasCaptions) { ?>
					<?php // Captions button. ?>
					<media-caption-button
						class="group relative inline-flex size-48 cursor-pointer items-center justify-center rounded-sm outline-hidden data-[focus]:outline-solid data-[focus]:outline-3 outline-primary-30 transition ml-auto"
					>
						<?php
						$iconWithClass($manifest['resources']['icons']['captionsOn'], 'hidden size-32 group-data-[active]:block');
						$iconWithClass($manifest['resources']['icons']['captionsOff'], 'size-32 group-data-[active]:hidden');
						?>
					</media-caption-button>
				<?php } ?>

				<?php // Timecode. ?>
				<div class="<?php echo esc_attr(Helpers::clsx(['ml-4 flex items-center text-base', $hasCaptions ? '' : 'ml-auto'])); ?>">
					<media-time class="time tabular-nums" type="current"></media-time>
					<div class="mx-1 text-white/80">&nbsp;/&nbsp;</div>
					<media-time class="time tabular-nums" type="duration"></media-time>
				</div>
			</div>
		</media-controls-group>
	</media-controls>

	<?php // phpcs:ignore Generic.Files.LineLength.TooLong ?>
	<media-captions	class="absolute left-0 empty:hidden right-0 bottom-16 px-8 py-4 sm:px-24 sm:py-12 mx-auto w-fit z-10 text-xs sm:text-h5 md:text-h4 font-medium bg-black/80 backdrop-blur-2xl select-none break-words opacity-0 transition-[opacity,bottom] group-data-[captions]/video:opacity-100 group-data-[controls]/video:bottom-120 group-data-[preview]/video:opacity-0"></media-captions>
</media-player>

<?php if ($videoCaptionUse && !empty($videoCaptionText)) { ?>
	<figcaption class="<?php echo esc_attr(Helpers::tailwindClasses('caption', $attributes, $manifest, $additionalClass['caption'] ?? '')); ?>">
		<?php echo wp_kses_post($videoCaptionText); ?>
	</figcaption>
</figure>
<?php } else { ?>
</div>
<?php } ?>
