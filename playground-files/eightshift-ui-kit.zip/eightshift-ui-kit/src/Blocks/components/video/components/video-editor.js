import { __ } from '@wordpress/i18n';
import { ManageFileButton, checkAttr, getAttrKey, tailwindClasses } from '@eightshift/frontend-libs-tailwind/scripts';
import { Button, HStack, MediaPlaceholder, Spacer, VStack } from '@eightshift/ui-components';
import { RichText } from '@wordpress/block-editor';
import { icons } from '@eightshift/ui-components/icons';
import { MediaPlayer, MediaProvider } from '@vidstack/react';
import { PlyrLayout, plyrLayoutIcons } from '@vidstack/react/player/layouts/plyr';
import manifest from '../manifest.json';
import { clsx } from '@eightshift/ui-components/utilities';

export const VideoEditor = (attributes) => {
	const { setAttributes, additionalClass } = attributes;

	const videoUse = checkAttr('videoUse', attributes, manifest);
	const videoUrl = checkAttr('videoUrl', attributes, manifest);
	const videoType = checkAttr('videoType', attributes, manifest, true);
	const videoCaptionUse = checkAttr('videoCaptionUse', attributes, manifest);
	const videoCaptionText = checkAttr('videoCaptionText', attributes, manifest);

	if (!videoUse) {
		return null;
	}

	const hasVideo = videoType && videoUrl?.length > 0;

	if (!hasVideo) {
		return (
			<div className={additionalClass?.base}>
				<MediaPlaceholder
					size='full'
					icon={icons.video}
					className={additionalClass?.video}
				>
					<VStack className='items-center text-center'>
						<span>{__('Add a video', 'eightshift-ui-kit')}</span>

						<HStack>
							<ManageFileButton
								type='browse'
								onChange={({ id, url, mime, mime_type }) =>
									setAttributes({
										[getAttrKey('videoType', attributes, manifest)]: 'local',
										[getAttrKey('videoId', attributes, manifest)]: id,
										[getAttrKey('videoUrl', attributes, manifest)]: url,
										[getAttrKey('videoMimeType', attributes, manifest)]: typeof mime === 'undefined' ? mime_type : mime,
									})
								}
								allowedTypes={manifest.allowedTypes}
								kind='video'
							/>

							<ManageFileButton
								type='upload'
								onChange={({ id, url, mime, mime_type }) =>
									setAttributes({
										[getAttrKey('videoType', attributes, manifest)]: 'local',
										[getAttrKey('videoId', attributes, manifest)]: id,
										[getAttrKey('videoUrl', attributes, manifest)]: url,
										[getAttrKey('videoMimeType', attributes, manifest)]: typeof mime === 'undefined' ? mime_type : mime,
									})
								}
								allowedTypes={['video/mp4', 'video/webm']}
								kind='video'
							/>
						</HStack>

						<Spacer size='s' />

						<span>{__('or add from external sources', 'eightshift-ui-kit')}</span>

						<HStack>
							<Button
								onPress={() =>
									setAttributes({
										[getAttrKey('videoType', attributes, manifest)]: 'youtube',
									})
								}
							>
								{__('YouTube', 'eightshift-ui-kit')}
							</Button>

							<Button
								onPress={() =>
									setAttributes({
										[getAttrKey('videoType', attributes, manifest)]: 'vimeo',
									})
								}
							>
								{__('Vimeo', 'eightshift-ui-kit')}
							</Button>
						</HStack>
					</VStack>
				</MediaPlaceholder>
			</div>
		);
	}

	const video = (
		<MediaPlayer
			className={tailwindClasses('base', attributes, manifest, additionalClass?.video)}
			title={__('Video preview', 'eightshift-ui-kit')}
			src={videoUrl}
			playsInline
			muted
		>
			<MediaProvider />
			<PlyrLayout
				controls={['play', 'play-large', 'mute', 'duration']}
				icons={plyrLayoutIcons}
			/>
		</MediaPlayer>
	);

	if (!videoCaptionUse) {
		return <div className={additionalClass?.base}>{video}</div>;
	}

	return (
		<figure className={additionalClass?.base}>
			{video}

			<RichText
				identifier={getAttrKey('videoCaptionText', attributes, manifest)}
				className={tailwindClasses('caption', attributes, manifest, additionalClass?.caption)}
				placeholder={__('Add caption', 'eightshift-ui-kit')}
				value={videoCaptionText}
				onChange={(value) => setAttributes({ [getAttrKey('videoCaptionText', attributes, manifest)]: value })}
				allowedFormats={['core/bold', 'core/link', 'core/italic']}
				tagName='figcaption'
				deleteEnter
			/>
		</figure>
	);
};
