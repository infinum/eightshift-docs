import { __ } from '@wordpress/i18n';
import { checkAttr, getAttrKey, getHiddenOptions, getOption } from '@eightshift/frontend-libs-tailwind/scripts';
import { ComponentToggle, HStack, OptionSelect, ToggleButton } from '@eightshift/ui-components';
import { icons } from '@eightshift/ui-components/icons';
import manifest from './../manifest.json';

export const ParagraphOptions = (attributes) => {
	const { setAttributes, hideOptions, additionalControls, ...rest } = attributes;

	const hiddenOptions = getHiddenOptions(hideOptions);

	const paragraphUse = checkAttr('paragraphUse', attributes, manifest);
	const paragraphSize = checkAttr('paragraphSize', attributes, manifest);
	const paragraphFontWeight = checkAttr('paragraphFontWeight', attributes, manifest);

	const fontSizes = getOption('paragraphSize', attributes, manifest);

	return (
		<ComponentToggle
			label={manifest.title}
			icon={icons.paragraph}
			onChange={(value) => setAttributes({ [getAttrKey('paragraphUse', attributes, manifest)]: value })}
			useComponent={paragraphUse}
			{...rest}
		>
			<HStack>
				<OptionSelect
					aria-label={__('Font size', 'eightshift-ui-kit')}
					options={fontSizes}
					onChange={(value) => setAttributes({ [getAttrKey('paragraphSize', attributes, manifest)]: value })}
					value={paragraphSize}
					type='menu'
					hidden={hiddenOptions.size}
				/>

				<ToggleButton
					icon={icons.bold}
					aria-label={__('Bold', 'eightshift-ui-kit')}
					tooltip={__('Bold', 'eightshift-ui-kit')}
					selected={paragraphFontWeight === '700'}
					onChange={(value) =>
						setAttributes({ [getAttrKey('paragraphFontWeight', attributes, manifest)]: value ? '700' : '400' })
					}
					hidden={hiddenOptions.weight}
				/>

				{additionalControls}
			</HStack>
		</ComponentToggle>
	);
};
