<?php

/**
 * Template for the Skip Link component view.
 *
 * @package EightshiftUIKit
 */

?>

<a
	href="#main-content"
	class="absolute -top-full bg-white text-black px-6 py-5 z-50 focus:top-5 focus:left-5"
>
	<?php echo esc_html__('Skip to main content', 'eightshift-ui-kit'); ?>
</a>
