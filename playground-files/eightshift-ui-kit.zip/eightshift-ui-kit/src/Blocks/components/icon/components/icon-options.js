import { __ } from '@wordpress/i18n';
import { checkAttr, getAttrKey, getHiddenOptions, getOption } from '@eightshift/frontend-libs-tailwind/scripts';
import {
	ComponentToggle,
	OptionSelect,
	TriggeredPopover,
	Button,
	InputField,
	HStack,
	VStack,
} from '@eightshift/ui-components';
import { icons, JsxSvg } from '@eightshift/ui-components/icons';
import { useState } from 'react';
import manifest from './../manifest.json';

const { icons: manifestIcons } = manifest;

export const IconOptions = (attributes) => {
	const { setAttributes, hideOptions, ...rest } = attributes;

	const hiddenOptions = getHiddenOptions(hideOptions);

	const iconName = checkAttr('iconName', attributes, manifest);
	const iconSize = checkAttr('iconSize', attributes, manifest);
	const iconUse = checkAttr('iconUse', attributes, manifest);

	const [searchText, setSearchText] = useState('');

	const filteredIcons = getOption('iconName', attributes, manifest).filter((item) => {
		if (searchText.length > 1) {
			return item.label.toLowerCase().includes(searchText.toLowerCase());
		}

		return true;
	});

	return (
		<ComponentToggle
			label={manifest.title}
			icon={icons.iconGeneric}
			onChange={(value) => setAttributes({ [getAttrKey('iconUse', attributes, manifest)]: value })}
			useComponent={iconUse}
			{...rest}
		>
			<TriggeredPopover
				triggerButtonIcon={manifestIcons?.[iconName] && <JsxSvg svg={manifestIcons[iconName]} />}
				triggerButtonLabel={
					manifest.options.iconName?.find((item) => item.value === iconName)?.label ??
					__('Select an icon', 'eightshift-ui-components')
				}
				triggerButtonProps={{ className: 'w-full' }}
				hidden={hiddenOptions?.iconName}
			>
				<VStack>
					<InputField
						type='search'
						placeholder={__('Search', 'eightshift-ui-components')}
						value={searchText}
						onChange={setSearchText}
						aria-label={__('Search', 'eightshift-ui-components')}
					/>

					<HStack className='max-h-200 w-280 overflow-y-auto'>
						{filteredIcons.map((item) => {
							return (
								<Button
									key={item.value}
									icon={<JsxSvg svg={manifestIcons[item.value]} />}
									aria-label={item.label}
									onClick={() => setAttributes({ [getAttrKey('iconName', attributes, manifest)]: item.value })}
									tooltip
									type={iconName === item.value ? 'selected' : 'ghost'}
								/>
							);
						})}

						{filteredIcons.length === 0 && <p className='text-center'>{__('Nothing found', 'eightshift-ui-kit')}</p>}
					</HStack>
				</VStack>
			</TriggeredPopover>

			<OptionSelect
				value={iconSize}
				options={getOption('iconSize', attributes, manifest)}
				onChange={(value) => setAttributes({ [getAttrKey('iconSize', attributes, manifest)]: value })}
				hidden={hiddenOptions?.size}
				type='menu'
				inline
			/>
		</ComponentToggle>
	);
};
