import { __ } from '@wordpress/i18n';
import { icons } from '@eightshift/ui-components/icons';
import { checkAttr, ManageFileButton, getAttrKey } from '@eightshift/frontend-libs-tailwind/scripts';
import { HStack, MediaPlaceholder } from '@eightshift/ui-components';
import Lottie from 'react-lottie';
import manifest from '../manifest.json';

export const LottieEditor = (attributes) => {
	const { setAttributes, additionalClass } = attributes;

	const lottieUrl = checkAttr('lottieUrl', attributes, manifest);
	const lottieLoop = checkAttr('lottieLoop', attributes, manifest);
	const lottieAutoplay = checkAttr('lottieAutoplay', attributes, manifest);

	if (lottieUrl) {
		return (
			<div className={additionalClass}>
				<Lottie
					options={{
						loop: lottieLoop,
						autoplay: lottieAutoplay,
						path: lottieUrl,
						rendererSettings: {
							className: additionalClass,
						},
					}}
				/>
			</div>
		);
	}

	return (
		<MediaPlaceholder
			icon={icons.animation}
			helpText={__('Lottie animation', 'eightshift-ui-kit')}
			size='full'
		>
			<HStack>
				<ManageFileButton
					type='browse'
					onChange={({ id, url }) =>
						setAttributes({
							[getAttrKey('lottieId', attributes, manifest)]: id,
							[getAttrKey('lottieUrl', attributes, manifest)]: url,
						})
					}
					allowedTypes={['application/json']}
					kind='lottie'
				/>

				<ManageFileButton
					type='upload'
					onChange={({ id, url }) =>
						setAttributes({
							[getAttrKey('lottieId', attributes, manifest)]: id,
							[getAttrKey('lottieUrl', attributes, manifest)]: url,
						})
					}
					allowedTypes={['application/json']}
					kind='lottie'
				/>
			</HStack>
		</MediaPlaceholder>
	);
};
