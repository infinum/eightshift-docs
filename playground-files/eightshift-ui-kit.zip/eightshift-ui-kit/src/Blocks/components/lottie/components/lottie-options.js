import { __ } from '@wordpress/i18n';
import { icons, JsxSvg } from '@eightshift/ui-components/icons';
import { clsx } from '@eightshift/ui-components/utilities';
import { checkAttr, getAttrKey, FileSelector } from '@eightshift/frontend-libs-tailwind/scripts';
import { ContainerPanel, Spacer, Toggle } from '@eightshift/ui-components';
import manifest from '../manifest.json';

export const LottieOptions = (attributes) => {
	const { setAttributes } = attributes;

	const lottieId = checkAttr('lottieId', attributes, manifest);
	const lottieUrl = checkAttr('lottieUrl', attributes, manifest);
	const lottieLoop = checkAttr('lottieLoop', attributes, manifest);
	const lottieAutoplay = checkAttr('lottieAutoplay', attributes, manifest);

	return (
		<>
			<ContainerPanel
				icon={icons.animation}
				title={__('Lottie animation', 'eightshift-ui-kit')}
			>
				<FileSelector
					onChange={({ id, url }) =>
						setAttributes({
							[getAttrKey('lottieId', attributes, manifest)]: id,
							[getAttrKey('lottieUrl', attributes, manifest)]: url,
						})
					}
					fileId={lottieId}
					fileName={lottieUrl?.slice(lottieUrl?.lastIndexOf('/') + 1)}
					allowedTypes={['application/json']}
					kind='lottie'
				/>
			</ContainerPanel>
			<ContainerPanel
				hidden={!lottieUrl}
				icon={icons.playbackOptions}
				title={__('Playback', 'eightshift-ui-kit')}
			>
				<Toggle
					icon={icons.loopMode}
					label={__('Loop', 'eightshift-ui-kit')}
					checked={lottieLoop}
					onChange={(value) => setAttributes({ [getAttrKey('lottieLoop', attributes, manifest)]: value })}
				/>

				<Toggle
					icon={icons.autoplay}
					label={__('Autoplay', 'eightshift-ui-kit')}
					checked={lottieAutoplay}
					onChange={(value) => setAttributes({ [getAttrKey('lottieAutoplay', attributes, manifest)]: value })}
				/>
			</ContainerPanel>
		</>
	);
};
