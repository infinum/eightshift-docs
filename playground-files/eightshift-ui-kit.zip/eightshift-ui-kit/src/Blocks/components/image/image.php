<?php

/**
 * Image component.
 *
 * @package EightshiftUIKit
 */

use EightshiftUIKitVendor\EightshiftLibs\Helpers\Helpers;

$globalManifest = Helpers::getSettings();

$additionalClass = $attributes['additionalClass'] ?? '';

$imageId = Helpers::checkAttr('imageId', $attributes, $manifest) ?? false;
$imageUrl = Helpers::checkAttr('imageUrl', $attributes, $manifest);
$imageUse = Helpers::checkAttr('imageUse', $attributes, $manifest);
$imageCaptionUse = Helpers::checkAttr('imageCaptionUse', $attributes, $manifest);
$imageCaptionText = Helpers::checkAttr('imageCaptionText', $attributes, $manifest);

if (!$imageUse || empty($imageUrl)) {
	return;
}

$imageAlt = get_post_meta($imageId, '_wp_attachment_image_alt', true) ?? '';

if ($imageId) {
	$imageUrl = Helpers::existsWebPMedia($imageId) ? Helpers::getWebPMedia($imageUrl)['src'] : $imageUrl;
}

?>

<?php if ($imageCaptionUse && !empty($imageCaptionText)) { ?>
	<figure>
		<picture
			<?php if (!empty($additionalClass['picture'])) { ?>
				class="<?php echo esc_attr($additionalClass['picture']); ?>"
			<?php } ?>
		>
			<img
				src="<?php echo esc_url($imageUrl); ?>"
				alt="<?php echo esc_attr($imageAlt); ?>"
				class="<?php echo esc_attr(Helpers::tailwindClasses('base', $attributes, $manifest, $additionalClass['image'] ?? '')); ?>"
			/>
		</picture>

		<figcaption class="<?php echo esc_attr(Helpers::tailwindClasses('caption', $attributes, $manifest, $additionalClass['caption'] ?? '')); ?>">
			<?php echo wp_kses_post($imageCaptionText); ?>
		</figcaption>
	</figure>
<?php } else { ?>
	<picture
		<?php if (!empty($additionalClass['picture'])) { ?>
			class="<?php echo esc_attr($additionalClass['picture']); ?>"
		<?php } ?>
	>
		<img
			src="<?php echo esc_url($imageUrl); ?>"
			alt="<?php echo esc_attr($imageAlt); ?>"
			class="<?php echo esc_attr(Helpers::tailwindClasses('base', $attributes, $manifest, $additionalClass['image'] ?? '')); ?>"
		/>
	</picture>
<?php } ?>
