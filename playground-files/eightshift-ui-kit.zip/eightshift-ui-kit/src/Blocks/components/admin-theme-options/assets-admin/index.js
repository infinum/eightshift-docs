import domReady from '@wordpress/dom-ready';
import { __ } from '@wordpress/i18n';
import { createRoot } from '@wordpress/element';
import { ThemeOptionsPage } from './theme-options-page';
import { BrowserRouter, Router } from 'react-router';

domReady(() => {
	const rootElement = document.getElementById('es-theme-options');

	if (!rootElement) {
		return;
	}

	const root = createRoot(rootElement);
	const patterns = JSON.parse(document.getElementById('es-pattern-data')?.value ?? '[]');
	const initialSettings = JSON.parse(document.getElementById('es-initial-settings')?.value ?? '{}');

	root.render(
		<BrowserRouter>
			<ThemeOptionsPage
				initial={initialSettings}
				patterns={patterns}
			/>
		</BrowserRouter>,
	);
});

// https://developer.wordpress.org/news/2024/03/26/how-to-use-wordpress-react-components-for-plugin-pages/
