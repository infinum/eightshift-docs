import { checkAttr, classnames, getAttrKey, tailwindClasses } from '@eightshift/frontend-libs-tailwind/scripts';
import { JsxSvg } from '@eightshift/ui-components/icons';
import { ButtonEditor } from '../../button/components/button-editor';
import manifest from '../manifest.json';

export const ShareEditor = (attributes) => {
	const { additionalClass } = attributes;

	const shareUse = checkAttr('shareUse', attributes, manifest);

	if (!shareUse) {
		return null;
	}

	const shareTargets = checkAttr('shareTargets', attributes, manifest);

	return (
		<div className={tailwindClasses('base', attributes, manifest, additionalClass)}>
			{shareTargets.map((network) => {
				return (
					<ButtonEditor
						buttonLabelUse={false}
						buttonIconUse
						buttonCustomIcon={manifest?.networks?.[network]?.icon}
						buttonVariant='tertiary'
					/>
				);
			})}
		</div>
	);
};
