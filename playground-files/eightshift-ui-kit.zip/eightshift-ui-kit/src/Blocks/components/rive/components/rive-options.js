import { __ } from '@wordpress/i18n';
import { icons, JsxSvg } from '@eightshift/ui-components/icons';
import { clsx } from '@eightshift/ui-components/utilities';
import { checkAttr, getAttrKey, FileSelector } from '@eightshift/frontend-libs-tailwind/scripts';
import { ContainerPanel, OptionSelect, Spacer, Toggle } from '@eightshift/ui-components';
import manifest from '../manifest.json';

export const RiveOptions = (attributes) => {
	const { setAttributes } = attributes;

	const riveId = checkAttr('riveId', attributes, manifest);
	const riveUrl = checkAttr('riveUrl', attributes, manifest);
	const riveLoop = checkAttr('riveLoop', attributes, manifest);
	const riveAutoplay = checkAttr('riveAutoplay', attributes, manifest);
	const riveFit = checkAttr('riveFit', attributes, manifest);

	return (
		<>
			<ContainerPanel
				icon={icons.animation}
				title={__('Rive animation', 'eightshift-ui-kit')}
			>
				<FileSelector
					onChange={({ id, url }) =>
						setAttributes({
							[getAttrKey('riveId', attributes, manifest)]: id,
							[getAttrKey('riveUrl', attributes, manifest)]: url,
						})
					}
					fileId={riveId}
					fileName={riveUrl?.slice(riveUrl?.lastIndexOf('/') + 1)}
					allowedTypes={['application/octet-stream']}
					kind='rive'
				/>

				<Spacer hidden={!riveUrl} />

				<OptionSelect
					icon={icons.expandXl}
					label={__('Fit', 'eightshift-ui-kit')}
					value={riveFit}
					onChange={(value) => setAttributes({ [getAttrKey('riveFit', attributes, manifest)]: value })}
					options={[
						{ value: 'contain', label: __('Contain', 'eightshift-ui-kit') },
						{ value: 'cover', label: __('Cover', 'eightshift-ui-kit') },
					]}
					hidden={!riveUrl}
					inline
				/>
			</ContainerPanel>
			<ContainerPanel
				hidden={!riveUrl}
				icon={icons.playbackOptions}
				title={__('Playback', 'eightshift-ui-kit')}
			>
				<Toggle
					icon={icons.loopMode}
					label={__('Loop', 'eightshift-ui-kit')}
					checked={riveLoop}
					onChange={(value) => setAttributes({ [getAttrKey('riveLoop', attributes, manifest)]: value })}
				/>

				<Toggle
					icon={icons.autoplay}
					label={__('Autoplay', 'eightshift-ui-kit')}
					checked={riveAutoplay}
					onChange={(value) => setAttributes({ [getAttrKey('riveAutoplay', attributes, manifest)]: value })}
				/>
			</ContainerPanel>
		</>
	);
};
