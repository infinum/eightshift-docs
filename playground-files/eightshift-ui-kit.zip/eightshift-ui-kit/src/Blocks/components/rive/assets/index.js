import domReady from '@wordpress/dom-ready';
import manifest from '../manifest.json';
import { Alignment, Fit, Layout, Rive } from '@rive-app/canvas';

domReady(() => {
	const elements = document.querySelectorAll(`.js-${manifest.componentName}`);

	if (!elements.length) {
		return;
	}

	elements.forEach((element) => {
		if ((element?.dataset?.animation ?? '').length < 1) {
			return;
		}

		const fit = element?.dataset?.fit ?? 'cover';

		const player = new Rive({
			src: element.dataset.animation,
			canvas: element,
			autoplay: element.hasAttribute('data-autoplay'),
			stateMachines: 'bumpy',
			loop: element.hasAttribute('data-loop'),
			layout: new Layout({
				fit: fit === 'cover' ? Fit.Cover : Fit.Contain,
				alignment: Alignment.Center,
			}),
			onLoad: () => {
				player.resizeDrawingSurfaceToCanvas();
			},
		});
	});
});
