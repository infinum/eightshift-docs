import React, { useState } from 'react';

import { TabsEditor } from './components/tabs-editor';
import { TabsOptions } from './components/tabs-options';
import { TabContext } from './tab-context';
import { GutenbergBlock } from '@eightshift/frontend-libs-tailwind/scripts';

export const Tabs = (props) => {
	const [activeTab, setActiveTab] = useState();

	return (
		<TabContext.Provider value={{ activeTab, setActiveTab, parentClientId: props.clientId }}>
			<GutenbergBlock
				{...props}
				editor={TabsEditor}
				options={TabsOptions}
				noOptionsContainer
			/>
		</TabContext.Provider>
	);
};
