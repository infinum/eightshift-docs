// Based on the W3 WAI-ARIA "Tabs with automatic activation" example: https://www.w3.org/WAI/ARIA/apg/patterns/tabs/examples/tabs-automatic/

import { animate } from 'motion';

export class Tabs {
	constructor({ element, tabSelector, tabListSelector, tabButtonSelector }) {
		this.element = element;

		this.tabPanels = element.querySelectorAll(`:scope > ${tabSelector}`);
		this.tabList = element.querySelector(`:scope > ${tabListSelector}`);
		this.tabTriggers = this.tabList.querySelectorAll(tabButtonSelector);

		this.firstTab = this.tabTriggers[0];
		this.lastTab = this.tabTriggers[this.tabTriggers.length - 1];

		this.selectedIndex = 0;

		// Listen for 'prefers-reduced-motion' changes.
		const mediaQuery = window.matchMedia('(prefers-reduced-motion: reduce)');

		this.reducedMotion = mediaQuery.matches;

		mediaQuery.addEventListener('change', (event) => (this.reducedMotion = event.matches));
	}

	init() {
		this.tabPanels.forEach((panel, index) => {
			if (index === 0) {
				panel.setAttribute('aria-hidden', 'false');

				animate(panel, { opacity: 1 }, { duration: 0 });
			} else {
				animate(panel, { opacity: 0 }, { duration: 0 });
			}

			panel.removeAttribute('hidden');
		});

		this.tabTriggers.forEach((tab) => {
			tab.tabIndex = -1;
			tab.setAttribute('aria-selected', 'false');

			tab.addEventListener('keydown', (event) => this.onKeyDown(tab, event));
			tab.addEventListener('click', () => this.setSelectedTab(tab));
		});

		this.setSelectedTab(this.firstTab, false);
	}

	setSelectedTab(currentTab, setFocus) {
		if (typeof setFocus !== 'boolean') {
			setFocus = true;
		}

		this.tabTriggers.forEach((tabTrigger, index) => {
			if (currentTab === tabTrigger && this.selectedIndex !== index) {
				const elementToAnimate = this.tabPanels[this.selectedIndex];

				animate(elementToAnimate, { opacity: 0 });
			}

			this.tabPanels[index].setAttribute('aria-hidden', currentTab === tabTrigger ? 'false' : 'true');
			tabTrigger.setAttribute('aria-selected', currentTab === tabTrigger ? 'true' : 'false');

			if (currentTab === tabTrigger) {
				const elementToAnimate = this.tabPanels[index];

				animate(elementToAnimate, { opacity: 1 });
			}

			if (currentTab === tabTrigger) {
				tabTrigger.removeAttribute('tabindex');

				this.selectedIndex = index;

				if (setFocus) {
					tabTrigger.focus();
				}
			} else {
				tabTrigger.tabIndex = -1;
			}
		});
	}

	previousTab(currentTab) {
		if (currentTab === this.firstTab) {
			this.setSelectedTab(this.lastTab);
		} else {
			this.setSelectedTab(currentTab.previousElementSibling);
		}
	}

	nextTab(currentTab) {
		if (currentTab === this.lastTab) {
			this.setSelectedTab(this.firstTab);
		} else {
			this.setSelectedTab(currentTab.nextElementSibling);
		}
	}

	// Event handlers
	onKeyDown(target, event) {
		if (!target || !event) {
			return;
		}

		const shouldStopPropagation = ['Home', 'End', 'ArrowLeft', 'ArrowRight'].includes(event.key);

		if (event.key === 'Home') {
			this.setSelectedTab(this.firstTab);
		}

		if (event.key === 'End') {
			this.setSelectedTab(this.lastTab);
		}

		if (event.key === 'ArrowLeft') {
			this.previousTab(target);
		}

		if (event.key === 'ArrowRight') {
			this.nextTab(target);
		}

		if (shouldStopPropagation) {
			event.stopPropagation();
			event.preventDefault();
		}
	}
}
