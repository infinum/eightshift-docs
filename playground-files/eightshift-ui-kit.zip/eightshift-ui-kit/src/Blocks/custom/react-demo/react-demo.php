<?php

/**
 * Hero block.
 *
 * @package EightshiftUIKit
 */

use EightshiftUIKitVendor\EightshiftLibs\Helpers\Helpers;

$blockJsClass = $attributes['blockJsClass'] ?? '';

$reactDemoLabel = Helpers::checkAttr('reactDemoLabel', $attributes, $manifest);
?>

<div
	class="<?php echo esc_attr(Helpers::tailwindClasses('base', $attributes, $manifest, $blockJsClass)); ?>"
	data-label="<?php echo esc_attr($reactDemoLabel); ?>"
>
	<?php echo esc_html__('Loading...', 'eightshift-ui-kit'); ?>
</div>
