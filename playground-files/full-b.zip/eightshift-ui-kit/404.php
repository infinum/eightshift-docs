<?php

/**
 * 404 error page
 *
 * @package EightshiftUIKit
 */

use EightshiftUIKit\ThemeOptions\ThemeOptions;

get_header();

// Header reusable block.
ThemeOptions::renderPartial(ThemeOptions::get(ThemeOptions::FOUR_OH_FOUR));

get_footer();
