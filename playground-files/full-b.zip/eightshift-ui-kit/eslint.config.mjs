import config from '@eightshift/frontend-libs-tailwind/linters/eslint.config.mjs';

export default config;
