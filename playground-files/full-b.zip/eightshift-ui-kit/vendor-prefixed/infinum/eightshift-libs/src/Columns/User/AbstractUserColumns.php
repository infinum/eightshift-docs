<?php

/**
 * User columns abstract class file
 *
 * @package EightshiftLibs\Columns\User
 *
 * @license MIT
 * Modified by eightshift-ui-kit on 15-July-2025 using {@see https://github.com/BrianHenryIE/strauss}.
 */

declare(strict_types=1);

namespace EightshiftUIKitVendor\EightshiftLibs\Columns\User;

use EightshiftUIKitVendor\EightshiftLibs\Services\ServiceInterface;

/**
 * Abstract class AbstractUserColumns.
 *
 * This abstract class can be extended to add (custom) user columns in the user screen.
 */
abstract class AbstractUserColumns implements ServiceInterface
{
	/**
	 * Register the user columns and content in them.
	 *
	 * @return void
	 */
	public function register(): void
	{
		\add_filter('manage_users_columns', [$this, 'addColumnName']);
		\add_filter('manage_users_custom_column', [$this, 'renderColumnContent'], 10, 3);
		\add_filter('manage_users_sortable_columns', [$this, 'sortAddedColumns'], 10);
	}

	/**
	 * Add additional user columns to the columns array.
	 *
	 * @param string[] $columns The existing column names array with default user columns (title, author, date etc.).
	 *
	 * @return string[] Modified column names array.
	 */
	abstract public function addColumnName(array $columns): array;

	/**
	 * Render the user column content in the custom user column
	 *
	 * @param string $output Custom column output. Default empty.
	 * @param string $columnName Column name.
	 * @param int    $userId ID of the currently-listed user.
	 *
	 * @return string             Output based on the column name.
	 */
	abstract public function renderColumnContent(string $output, string $columnName, int $userId): string;

	/**
	 * Make user columns sortable
	 *
	 * @param string[] $columns Array of columns.
	 *
	 * @return string[] Modified array of columns.
	 */
	abstract public function sortAddedColumns(array $columns): array;
}
