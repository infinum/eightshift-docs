<?php

/**
 * Class that registers WP-CLI command for Config Theme.
 *
 * @package EightshiftLibs\Config
 *
 * @license MIT
 * Modified by eightshift-ui-kit on 15-July-2025 using {@see https://github.com/BrianHenryIE/strauss}.
 */

declare(strict_types=1);

namespace EightshiftUIKitVendor\EightshiftLibs\Config;

use EightshiftUIKitVendor\EightshiftLibs\Cli\AbstractCli;
use EightshiftUIKitVendor\EightshiftLibs\Cli\ParentGroups\CliCreate;
use EightshiftUIKitVendor\EightshiftLibs\Helpers\Helpers;

/**
 * Class ConfigThemeCli
 */
class ConfigThemeCli extends AbstractCli
{
	/**
	 * Get WP-CLI command parent name
	 *
	 * @return string
	 */
	public function getCommandParentName(): string
	{
		return CliCreate::COMMAND_NAME;
	}

	/**
	 * Get WP-CLI command name
	 *
	 * @return string
	 */
	public function getCommandName(): string
	{
		return 'config-theme';
	}

	/**
	 * Define default arguments.
	 *
	 * @return array<string, int|string|boolean>
	 */
	public function getDefaultArgs(): array
	{
		return [];
	}

	/**
	 * Get WP-CLI command doc
	 *
	 * @return array<string, array<int, array<string, bool|string>>|string>
	 */
	public function getDoc(): array
	{
		return [
			'shortdesc' => 'Create theme config service class.',
			'longdesc' => $this->prepareLongDesc("
				## USAGE

				Used to create theme config class with settings like project name, version, REST-API name/version, etc.

				## EXAMPLES

				# Create service class:
				$ wp {$this->commandParentName} {$this->getCommandParentName()} {$this->getCommandName()}

				## RESOURCES

				Service class will be created from this example:
				https://github.com/infinum/eightshift-libs/blob/develop/src/Config/ConfigThemeExample.php
			"),
		];
	}

	/* @phpstan-ignore-next-line */
	public function __invoke(array $args, array $assocArgs)
	{
		$assocArgs = $this->prepareArgs($assocArgs);

		$this->getIntroText($assocArgs);

		$className = $this->getClassShortName();
		$newName = 'Config';

		// Read the template contents, and replace the placeholders with provided variables.
		$class = $this->getExampleTemplate(__DIR__, $className)
			->renameClassNameWithPrefix($className, $newName)
			->renameGlobals($assocArgs);

		// Output final class to new file/folder and finish.
		$class->outputWrite(Helpers::getProjectPaths('src', 'Config'), "{$newName}.php", $assocArgs);
	}
}
