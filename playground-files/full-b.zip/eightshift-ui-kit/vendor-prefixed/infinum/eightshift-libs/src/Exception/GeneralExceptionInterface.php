<?php

/**
 * Interface containing general exception interface
 *
 * @package EightshiftLibs\Exception
 *
 * @license MIT
 * Modified by eightshift-ui-kit on 15-July-2025 using {@see https://github.com/BrianHenryIE/strauss}.
 */

declare(strict_types=1);

namespace EightshiftUIKitVendor\EightshiftLibs\Exception;

/**
 * GeneralExceptionInterface interface
 *
 * This interface is implemented by all exceptions, so that we can catch "internal" exceptions only.
 */
interface GeneralExceptionInterface
{
}
