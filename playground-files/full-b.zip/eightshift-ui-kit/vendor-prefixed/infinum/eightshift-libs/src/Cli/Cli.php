<?php

/**
 * The class file that holds abstract class for WP-CLI
 *
 * @package EightshiftLibs\Cli
 *
 * @license MIT
 * Modified by eightshift-ui-kit on 15-July-2025 using {@see https://github.com/BrianHenryIE/strauss}.
 */

declare(strict_types=1);

namespace EightshiftUIKitVendor\EightshiftLibs\Cli;

use EightshiftUIKitVendor\EightshiftLibs\AdminMenus\AdminMenuCli;
use EightshiftUIKitVendor\EightshiftLibs\AdminMenus\AdminPatternsHeaderFooterMenu\AdminPatternsHeaderFooterMenuCli;
use EightshiftUIKitVendor\EightshiftLibs\AdminMenus\AdminPatternsMenu\AdminPatternsMenuCli;
use EightshiftUIKitVendor\EightshiftLibs\AdminMenus\AdminSubMenuCli;
use EightshiftUIKitVendor\EightshiftLibs\AdminMenus\AdminThemeOptionsMenu\AdminThemeOptionsMenuCli;
use EightshiftUIKitVendor\EightshiftLibs\BlockPatterns\BlockPatternCli;
use EightshiftUIKitVendor\EightshiftLibs\Blocks\BlocksCli;
use EightshiftUIKitVendor\EightshiftLibs\Cache\ManifestCacheCli;
use EightshiftUIKitVendor\EightshiftLibs\Cli\ParentGroups\CliBoilerplate;
use EightshiftUIKitVendor\EightshiftLibs\Cli\ParentGroups\CliCreate;
use EightshiftUIKitVendor\EightshiftLibs\Cli\ParentGroups\CliRun;
use EightshiftUIKitVendor\EightshiftLibs\Cli\ParentGroups\CliBlocks;
use EightshiftUIKitVendor\EightshiftLibs\Cli\ParentGroups\CliInit;
use EightshiftUIKitVendor\EightshiftLibs\Columns\Media\WebPMediaColumnCli;
use EightshiftUIKitVendor\EightshiftLibs\Config\ConfigThemeCli;
use EightshiftUIKitVendor\EightshiftLibs\Config\ConfigPluginCli;
use EightshiftUIKitVendor\EightshiftLibs\View\EscapedViewCli;
use EightshiftUIKitVendor\EightshiftLibs\Setup\SetupCli;
use EightshiftUIKitVendor\EightshiftLibs\CustomPostType\PostTypeCli;
use EightshiftUIKitVendor\EightshiftLibs\CustomTaxonomy\TaxonomyCli;
use EightshiftUIKitVendor\EightshiftLibs\Enqueue\Admin\EnqueueAdminCli;
use EightshiftUIKitVendor\EightshiftLibs\Enqueue\Blocks\EnqueueBlocksCli;
use EightshiftUIKitVendor\EightshiftLibs\Enqueue\Theme\EnqueueThemeCli;
use EightshiftUIKitVendor\EightshiftLibs\Services\ServiceExampleCli;
use EightshiftUIKitVendor\EightshiftLibs\I18n\I18nCli;
use EightshiftUIKitVendor\EightshiftLibs\Login\LoginCli;
use EightshiftUIKitVendor\EightshiftLibs\Main\MainCli;
use EightshiftUIKitVendor\EightshiftLibs\Media\MediaCli;
use EightshiftUIKitVendor\EightshiftLibs\Menu\MenuCli;
use EightshiftUIKitVendor\EightshiftLibs\ModifyAdminAppearance\ModifyAdminAppearanceCli;
use EightshiftUIKitVendor\EightshiftLibs\Rest\Fields\FieldCli;
use EightshiftUIKitVendor\EightshiftLibs\Rest\Routes\RouteCli;
use EightshiftUIKitVendor\EightshiftLibs\Geolocation\GeolocationCli;
use EightshiftUIKitVendor\EightshiftLibs\Init\InitAllCli;
use EightshiftUIKitVendor\EightshiftLibs\Media\RegenerateWebPMediaCli;
use EightshiftUIKitVendor\EightshiftLibs\Media\UseWebPMediaCli;
use EightshiftUIKitVendor\EightshiftLibs\Optimization\OptimizationCli;
use EightshiftUIKitVendor\EightshiftLibs\Plugin\PluginCli;
use EightshiftUIKitVendor\EightshiftLibs\ThemeOptions\ThemeOptionsCli;
use EightshiftUIKitVendor\EightshiftLibs\WpCli\WpCli;
use ReflectionClass;
// phpcs:ignore SlevomatCodingStandard.Namespaces.UnusedUses.UnusedUse
use Exception;
use WP_CLI;

/**
 * Class Cli
 */
class Cli
{
	/**
	 * All commands defined as parent list commands.
	 *
	 * @var array<string>
	 */
	public const PARENT_COMMANDS = [
		CliCreate::class,
		CliRun::class,
		CliBlocks::class,
		CliInit::class,
	];

	/**
	 * All commands that are service classes type. Command prefix - create.
	 *
	 * @var array<string>
	 */
	public const CREATE_COMMANDS = [
		AdminMenuCli::class,
		AdminPatternsMenuCli::class,
		AdminThemeOptionsMenuCli::class,
		AdminSubMenuCli::class,
		AdminPatternsHeaderFooterMenuCli::class,
		WebPMediaColumnCli::class,
		ConfigPluginCli::class,
		ConfigThemeCli::class,
		PostTypeCli::class,
		TaxonomyCli::class,
		EnqueueAdminCli::class,
		EnqueueBlocksCli::class,
		EnqueueThemeCli::class,
		GeolocationCli::class,
		I18nCli::class,
		LoginCli::class,
		MainCli::class,
		MediaCli::class,
		MenuCli::class,
		ModifyAdminAppearanceCli::class,
		OptimizationCli::class,
		FieldCli::class,
		RouteCli::class,
		ServiceExampleCli::class,
		SetupCli::class,
		ThemeOptionsCli::class,
		EscapedViewCli::class,
		WpCli::class,
		ManifestCacheCli::class,
		PluginCli::class,
	];

	/**
	 * All commands that can be used on a WP project directly from the libs. Command prefix - run.
	 *
	 * @var array<string>
	 */
	public const RUN_COMMANDS = [
		RegenerateWebPMediaCli::class,
		UseWebPMediaCli::class,
	];

	/**
	 * All commands used for block editor. Command prefix - blocks.
	 *
	 * @var array<string>
	 */
	public const BLOCKS_COMMANDS = [
		BlockPatternCli::class,
		BlocksCli::class,
	];

	/**
	 * All commands used for setting up. Command prefix - init.
	 *
	 * @var array<string>
	 */
	public const INIT_COMMANDS = [
		InitAllCli::class,
	];

	/**
	 * Define all classes to register for normal WP.
	 *
	 * @return class-string[]
	 */
	public function getCommandsClasses(): array
	{
		return [
			...static::CREATE_COMMANDS,
			...static::BLOCKS_COMMANDS,
			...static::INIT_COMMANDS,
			...static::RUN_COMMANDS,
		];
	}

	/**
	 * Run all CLI commands for normal WP-CLI.
	 *
	 * @param string $commandParentName Define top level commands name.
	 *
	 * @throws Exception Exception if the class doesn't exist.
	 *
	 * @return void
	 */
	public function load(string $commandParentName): void
	{
		// Duplicate condition because WP_CLI will throw error on the project.
		if (\defined('WP_CLI')) {
			// Top Level command name.
			WP_CLI::add_command($commandParentName, new CliBoilerplate());

			// Register all top level commands.
			foreach (self::PARENT_COMMANDS as $item) {
				$reflectionClass = new ReflectionClass($item);
				$class = $reflectionClass->newInstanceArgs();
				$name = $reflectionClass->getConstant('COMMAND_NAME');

				WP_CLI::add_command("{$commandParentName} {$name}", $class);
			}
		}

		foreach ($this->getCommandsClasses() as $item) {
			$reflectionClass = new ReflectionClass($item);
			$class = $reflectionClass->newInstanceArgs([$commandParentName]);

			if ($class instanceof CliInterface) {
				$class->register();
			}
		}
	}
}
