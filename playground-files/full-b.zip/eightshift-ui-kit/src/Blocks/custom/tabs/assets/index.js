import domReady from '@wordpress/dom-ready';
import manifest from './../manifest.json';
import tabManifest from '../../tab/manifest.json';

domReady(async () => {
	const selector = `.${manifest.blockJsClass}`;
	const elements = document.querySelectorAll(selector);

	if (elements?.length < 1) {
		return;
	}

	const { Tabs } = await import('./tabs');

	elements.forEach((element) => {
		new Tabs({
			element: element,
			tabSelector: `.${tabManifest.blockJsClass}`,
			tabListSelector: `${selector}-tablist`,
			tabButtonSelector: `${selector}-tab-button`,
		}).init();
	});
});
