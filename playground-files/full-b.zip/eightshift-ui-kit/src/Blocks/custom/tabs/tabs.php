<?php

/**
 * Tabs block.
 *
 * @package EightshiftUIKit
 */

use EightshiftUIKitVendor\EightshiftLibs\Helpers\Helpers;

$blockJsClass = $manifest['blockJsClass'] ?? '';

$tablistContainerClass = Helpers::tailwindClasses('tabListContainer', $attributes, $manifest, "{$blockJsClass}-tablist");

$tablistItemClass = Helpers::tailwindClasses('tabListItem', $attributes, $manifest, "{$blockJsClass}-tab-button");

$tabsTabData = Helpers::checkAttr('tabsTabData', $attributes, $manifest);
$tabsLayout = Helpers::checkAttr('tabsLayout', $attributes, $manifest);
?>

<div class="<?php echo esc_attr(Helpers::tailwindClasses('base', $attributes, $manifest, $blockJsClass)); ?>">
	<div role="tablist" class="<?php echo esc_attr($tablistContainerClass); ?>">
		<?php foreach ($tabsTabData as $tabItem) {
			if (empty($tabItem['title'])) {
				continue;
			}

			?>
			<button
				role="tab"
				class="<?php echo esc_attr($tablistItemClass); ?>"
				type="button"
				aria-selected="false"
				aria-controls="ib-tab-<?php echo esc_attr($tabItem['id'] ?? ''); ?>"
			>
				<?php echo wp_kses_post($tabItem['title']); ?>
			</button>
		<?php } ?>
	</div>

	<?php
	// phpcs:ignore Eightshift.Security.HelpersEscape.OutputNotEscaped
	echo $renderContent;
	?>
</div>
