import { __ } from '@wordpress/i18n';
import { DemoComponent } from '../assets/demo-component';
import { checkAttr } from '@eightshift/frontend-libs-tailwind/scripts';
import manifest from '../manifest.json';

export const ReactDemoEditor = ({ attributes }) => {
	const reactDemoLabel = checkAttr('reactDemoLabel', attributes, manifest);

	return <DemoComponent label={reactDemoLabel} />;
};
