import { useState } from '@wordpress/element';
import { Button, HStack, VStack } from '@eightshift/ui-components';

export const DemoComponent = ({ label }) => {
	const [num, setNum] = useState(0);

	return (
		<VStack className='bg-primary-20 p-10'>
			<span>{label}</span>

			<HStack>
				<Button onPress={() => setNum(num - 1)}>-1</Button>
				<span>Num: {num}</span>
				<Button onPress={() => setNum(num + 1)}>+1</Button>
			</HStack>
		</VStack>
	);
};
