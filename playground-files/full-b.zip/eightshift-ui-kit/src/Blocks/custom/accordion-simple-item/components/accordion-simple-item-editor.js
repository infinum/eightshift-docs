import { __ } from '@wordpress/i18n';
import { BlockInserter, checkAttr, getAttrKey, tailwindClasses } from '@eightshift/frontend-libs-tailwind/scripts';
import { RichText, useBlockProps, useInnerBlocksProps } from '@wordpress/block-editor';
import manifest from '../manifest.json';
import { JsxSvg } from '@eightshift/ui-components/icons';

export const AccordionSimpleItemEditor = ({ attributes, setAttributes, clientId }) => {
	const accordionSimpleItemLabel = checkAttr('accordionSimpleItemLabel', attributes, manifest);

	const blockProps = useBlockProps();
	const innerBlocksProps = useInnerBlocksProps(blockProps, {
		allowedBlocks: [
			'eightshift-boilerplate/paragraph',
			'eightshift-boilerplate/heading',
			'eightshift-boilerplate/image',
			'eightshift-boilerplate/list',
		],
		renderAppender: () => (
			<BlockInserter
				clientId={clientId}
				small
			/>
		),
	});

	return (
		<details className={tailwindClasses('base', attributes, manifest)}>
			<summary className={tailwindClasses('trigger', attributes, manifest)}>
				<RichText
					placeholder={__('Section title', 'eightshift-ui-kit')}
					value={accordionSimpleItemLabel}
					onChange={(value) => setAttributes({ [getAttrKey('accordionSimpleItemLabel', attributes, manifest)]: value })}
					allowedFormats={['core/bold']}
					className='mr-auto w-fit'
					onClick={(e) => e.preventDefault()}
				/>

				<div className={tailwindClasses('icon', attributes, manifest)}>
					<JsxSvg svg={manifest.resources.icon} />
				</div>
			</summary>

			<div
				{...innerBlocksProps}
				className={tailwindClasses('content-container', attributes, manifest)}
			/>
		</details>
	);
};
