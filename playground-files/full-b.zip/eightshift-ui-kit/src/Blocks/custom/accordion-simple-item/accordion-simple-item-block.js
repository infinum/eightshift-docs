import { useSelect } from '@wordpress/data';
import { GutenbergBlock, overrideInnerBlockAttributes } from '@eightshift/frontend-libs-tailwind/scripts/editor';
import { AccordionSimpleItemEditor } from './components/accordion-simple-item-editor';

export const AccordionSimpleItem = (props) => {
	useSelect((select) => {
		overrideInnerBlockAttributes(select, props.clientId, {
			wrapperFullWidth: true,
		});
	});

	return (
		<GutenbergBlock
			{...props}
			editor={AccordionSimpleItemEditor}
		/>
	);
};
