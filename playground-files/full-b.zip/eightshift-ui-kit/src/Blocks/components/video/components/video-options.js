import { __, sprintf } from '@wordpress/i18n';
import {
	getOption,
	checkAttr,
	getAttrKey,
	FileSelector,
	getHiddenOptions,
	MediaPicker,
	ManageFileButton,
} from '@eightshift/frontend-libs-tailwind/scripts';
import {
	BaseControl,
	Button,
	ContainerPanel,
	HStack,
	InputField,
	OptionSelect,
	Repeater,
	RepeaterItem,
	Spacer,
	Toggle,
	Menu,
	MenuItem,
	SubMenuItem,
	MenuSeparator,
} from '@eightshift/ui-components';
import { icons } from '@eightshift/ui-components/icons';
import manifest from '../manifest.json';

export const VideoOptions = (attributes) => {
	const { setAttributes, hideOptions, additionalControls } = attributes;

	const hiddenOptions = getHiddenOptions(hideOptions);

	const videoUrl = checkAttr('videoUrl', attributes, manifest, true);
	const videoId = checkAttr('videoId', attributes, manifest, true);
	const videoPosterId = checkAttr('videoPosterId', attributes, manifest);
	const videoPosterUrl = checkAttr('videoPosterUrl', attributes, manifest);
	const videoLoop = checkAttr('videoLoop', attributes, manifest);
	const videoAutoplay = checkAttr('videoAutoplay', attributes, manifest);
	const videoPreload = checkAttr('videoPreload', attributes, manifest);
	const videoSubtitleTracks = checkAttr('videoSubtitleTracks', attributes, manifest);
	const videoType = checkAttr('videoType', attributes, manifest);
	const videoCaptionUse = checkAttr('videoCaptionUse', attributes, manifest);
	const videoAspectRatio = checkAttr('videoAspectRatio', attributes, manifest);
	const videoFill = checkAttr('videoFill', attributes, manifest);

	const getTrackIcon = (kind) => {
		switch (kind) {
			case 'subtitles':
				return icons.videoSubtitle;
			case 'captions':
				return icons.closedCaptions;
			case 'descriptions':
				return icons.hide;
			case 'chapters':
				return icons.videoChapters;
		}

		return icons.emptyRect;
	};

	if (!videoType) {
		return (
			<ContainerPanel
				icon={icons.video}
				title={__('Video', 'eightshift-ui-kit')}
			>
				<span className='inline-block'>{__('Add a video', 'eightshift-ui-kit')}</span>

				<HStack>
					<ManageFileButton
						type='browse'
						onChange={({ id, url, mime, mime_type }) =>
							setAttributes({
								[getAttrKey('videoType', attributes, manifest)]: 'local',
								[getAttrKey('videoId', attributes, manifest)]: id,
								[getAttrKey('videoUrl', attributes, manifest)]: url,
								[getAttrKey('videoMimeType', attributes, manifest)]: typeof mime === 'undefined' ? mime_type : mime,
							})
						}
						allowedTypes={manifest.allowedTypes}
						kind='video'
					/>

					<ManageFileButton
						type='upload'
						onChange={({ id, url, mime, mime_type }) =>
							setAttributes({
								[getAttrKey('videoType', attributes, manifest)]: 'local',
								[getAttrKey('videoId', attributes, manifest)]: id,
								[getAttrKey('videoUrl', attributes, manifest)]: url,
								[getAttrKey('videoMimeType', attributes, manifest)]: typeof mime === 'undefined' ? mime_type : mime,
							})
						}
						allowedTypes={['video/mp4', 'video/webm']}
						kind='video'
					/>
				</HStack>

				<Spacer />

				<span className='inline-block'>{__('or add from external sources', 'eightshift-ui-kit')}</span>

				<HStack>
					<Button
						onPress={() =>
							setAttributes({
								[getAttrKey('videoType', attributes, manifest)]: 'youtube',
							})
						}
					>
						{__('YouTube', 'eightshift-ui-kit')}
					</Button>

					<Button
						onPress={() =>
							setAttributes({
								[getAttrKey('videoType', attributes, manifest)]: 'vimeo',
							})
						}
					>
						{__('Vimeo', 'eightshift-ui-kit')}
					</Button>
				</HStack>
			</ContainerPanel>
		);
	}

	let panelTitle = __('Local video', 'eightshift-ui-kit');

	switch (videoType) {
		case 'youtube':
			panelTitle = __('YouTube video', 'eightshift-ui-kit');
			break;
		case 'vimeo':
			panelTitle = __('Vimeo video', 'eightshift-ui-kit');
			break;
	}

	return (
		<>
			<ContainerPanel
				icon={icons.video}
				title={panelTitle}
				actions={
					<Menu
						triggerIcon={icons.moreV}
						triggerProps={{ type: 'ghost', size: 'small' }}
					>
						<SubMenuItem trigger={<MenuItem icon={icons.swap}>{__('Change source', 'eightshift-ui-kit')}</MenuItem>}>
							{getOption('videoType', attributes, manifest).map(({ label, value, separator }) => (
								<>
									<MenuItem
										onClick={() => {
											if (videoType === value) {
												return;
											}

											setAttributes({
												[getAttrKey('videoType', attributes, manifest)]: value,
												[getAttrKey('videoUrl', attributes, manifest)]: null,
												[getAttrKey('videoId', attributes, manifest)]: null,
											});
										}}
										selected={videoType === value}
									>
										{label}
									</MenuItem>

									{separator && <MenuSeparator />}
								</>
							))}
						</SubMenuItem>
					</Menu>
				}
			>
				{videoType === 'local' && (
					<FileSelector
						onChange={({ id, url, mime, mime_type }) =>
							setAttributes({
								[getAttrKey('videoId', attributes, manifest)]: id,
								[getAttrKey('videoUrl', attributes, manifest)]: url,
								[getAttrKey('videoMimeType', attributes, manifest)]: typeof mime === 'undefined' ? mime_type : mime,
							})
						}
						fileId={videoId}
						fileName={videoUrl?.slice(videoUrl?.lastIndexOf('/') + 1)}
						allowedTypes={manifest.allowedTypes}
						kind='video'
					/>
				)}

				{['vimeo', 'youtube'].includes(videoType) && (
					<InputField
						icon={icons.videoUrl}
						label={__('Video ID', 'eightshift-ui-kit')}
						value={videoUrl}
						onChange={(url) =>
							setAttributes({
								[getAttrKey('videoId', attributes, manifest)]: null,
								[getAttrKey('videoUrl', attributes, manifest)]: url,
								[getAttrKey('videoMimeType', attributes, manifest)]: null,
							})
						}
						className='es:font-mono es:text-xs'
						type='multiline'
					/>
				)}
			</ContainerPanel>

			<ContainerPanel
				icon={icons.componentOptions}
				title={__('Parts', 'eightshift-ui-kit')}
				hidden={hiddenOptions?.caption}
			>
				<Toggle
					icon={icons.captionGeneric}
					label={__('Caption', 'eightshift-ui-kit')}
					checked={videoCaptionUse}
					onChange={(value) => setAttributes({ [getAttrKey('videoCaptionUse', attributes, manifest)]: value })}
					hidden={hiddenOptions?.caption}
				/>
			</ContainerPanel>

			<ContainerPanel
				icon={icons.design}
				title={__('Design', 'eightshift-ui-kit')}
				hidden={hiddenOptions?.aspectRatio && hiddenOptions?.fill && !additionalControls}
			>
				<OptionSelect
					icon={icons.aspectRatio}
					label={__('Aspect ratio', 'eightshift-ui-kit')}
					value={videoAspectRatio}
					options={getOption('videoAspectRatio', attributes, manifest)}
					onChange={(value) => setAttributes({ [getAttrKey('videoAspectRatio', attributes, manifest)]: value })}
					hidden={hiddenOptions?.aspectRatio}
					type='menu'
					inline
				/>

				<OptionSelect
					icon={icons.dummySpacer}
					label={__('Video display', 'eightshift-ui-kit')}
					value={videoFill}
					options={getOption('videoFill', attributes, manifest)}
					onChange={(value) => setAttributes({ [getAttrKey('videoFill', attributes, manifest)]: value })}
					hidden={hiddenOptions?.fill}
					type='menu'
					inline
				/>

				{additionalControls}
			</ContainerPanel>

			<ContainerPanel
				icon={icons.playbackOptions}
				title={__('Playback', 'eightshift-ui-kit')}
				closable
			>
				<Toggle
					icon={icons.loopMode}
					label={__('Loop', 'eightshift-ui-kit')}
					checked={videoLoop}
					onChange={(value) => setAttributes({ [getAttrKey('videoLoop', attributes, manifest)]: value })}
					hidden={hiddenOptions?.loop}
				/>

				<Toggle
					icon={icons.autoplayAlt}
					label={__('Autoplay', 'eightshift-ui-kit')}
					checked={videoAutoplay}
					onChange={(value) => setAttributes({ [getAttrKey('videoAutoplay', attributes, manifest)]: value })}
					hidden={hiddenOptions?.autoplay}
					subtitle={videoAutoplay && __('Audio muted', 'eightshift-ui-kit')}
				/>
			</ContainerPanel>

			<ContainerPanel
				hidden={videoType !== 'local'}
				icon={icons.a11y}
				title={__('Accessibility', 'eightshift-ui-kit')}
				closable
			>
				<Repeater
					icon={icons.videoSubtitleAlt}
					label={__('Captions', 'eightshift-ui-kit')}
					items={videoSubtitleTracks}
					onChange={(value) => setAttributes({ [getAttrKey('videoSubtitleTracks', attributes, manifest)]: value })}
				>
					{(item) => {
						const { trackId, trackFileName, kind, srclang, label, updateData, itemIndex: index } = item;

						return (
							<RepeaterItem
								icon={getTrackIcon(kind)}
								label={
									label ? sprintf(__('Track %d', 'eightshift-ui-kit'), index + 1) : __('New track', 'eightshift-ui-kit')
								}
								subtitle={label}
							>
								<FileSelector
									onChange={({ id, url }) =>
										updateData({
											trackId: id,
											trackFileName: url,
										})
									}
									fileId={trackId}
									fileName={trackFileName?.slice(trackFileName?.lastIndexOf('/') + 1)}
									allowedTypes={['text/vtt']}
									kind='subtitle'
								>
									{__(
										'Upload a VTT file containing captions, subtitles, descriptions or chapters',
										'eightshift-ui-kit',
									)}
								</FileSelector>

								<Spacer />

								<OptionSelect
									icon={icons.optionListAlt}
									label={__('Type', 'eightshift-ui-kit')}
									value={kind}
									options={getOption('videoSubtitleTrackKind', attributes, manifest)}
									onChange={(value) => updateData({ kind: value })}
									type='menu'
									inline
								/>

								<Spacer />

								<InputField
									icon={icons.titleGeneric}
									label={__('Label', 'eightshift-ui-kit')}
									help={__('Shows in the list of available tracks', 'eightshift-ui-kit')}
									value={label}
									onChange={(value) => updateData({ label: value })}
								/>

								<InputField
									icon={icons.flag}
									label={__('Language code', 'eightshift-ui-kit')}
									help={
										<>
											{__('Should follow IETF (BCP47).', 'eightshift-ui-kit')}
											{kind === 'subtitles' && ' ' + __('Required.', 'eightshift-ui-kit')}
										</>
									}
									value={srclang}
									onChange={(value) => updateData({ srclang: value })}
								/>

								<Spacer />

								<BaseControl label={__('List of language tags', 'eightshift-ui-kit')}>
									<a
										href='https://en.wikipedia.org/wiki/IETF_language_tag#List_of_major_primary_language_subtags'
										target='_blank'
										rel='external'
										className='icon:size-14 flex items-center gap-4'
									>
										{__('Common languages', 'eightshift-ui-kit')}
										{icons.externalLink}
									</a>

									<a
										href='https://r12a.github.io/app-subtags/'
										target='_blank'
										rel='external'
										className='icon:size-14 flex items-center gap-4'
									>
										{__('All languages', 'eightshift-ui-kit')}
										{icons.externalLink}
									</a>
								</BaseControl>
							</RepeaterItem>
						);
					}}
				</Repeater>
			</ContainerPanel>

			<ContainerPanel
				hidden={videoType !== 'local'}
				icon={icons.wrench}
				title={__('Advanced', 'eightshift-ui-kit')}
				closable
			>
				<BaseControl
					icon={icons.videoPosterImage}
					label={__('Poster image', 'eightshift-ui-kit')}
					subtitle={__('Visible before the video is played', 'eightshift-ui-kit')}
					hidden={hiddenOptions?.posterImage}
				>
					<MediaPicker
						onChange={({ id, url }) =>
							setAttributes({
								[getAttrKey('videoPosterId', attributes, manifest)]: id,
								[getAttrKey('videoPosterUrl', attributes, manifest)]: url,
							})
						}
						imageId={videoPosterId}
						imageUrl={videoPosterUrl}
					/>
				</BaseControl>

				<Spacer />

				<OptionSelect
					icon={icons.preload}
					label={__('Preload', 'eightshift-ui-kit')}
					value={videoPreload}
					options={getOption('videoPreload', attributes, manifest)}
					alignment='vertical'
					onChange={(value) => setAttributes({ [getAttrKey('videoPreload', attributes, manifest)]: value })}
					hidden={hiddenOptions?.preload}
				/>
			</ContainerPanel>
		</>
	);
};
