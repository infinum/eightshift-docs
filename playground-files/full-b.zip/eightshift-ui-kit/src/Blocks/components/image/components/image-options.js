import { __ } from '@wordpress/i18n';
import {
	checkAttr,
	getAttrKey,
	MediaPicker,
	getHiddenOptions,
	getOption,
} from '@eightshift/frontend-libs-tailwind/scripts';
import { ContainerPanel, OptionSelect, Toggle } from '@eightshift/ui-components';
import { icons } from '@eightshift/ui-components/icons';
import { clsx } from '@eightshift/ui-components/utilities';
import manifest from './../manifest.json';

export const ImageOptions = (attributes) => {
	const { setAttributes, hideOptions, additionalControls, hidden, label } = attributes;

	if (hidden) {
		return null;
	}

	const hiddenOptions = getHiddenOptions(hideOptions);

	const imageId = checkAttr('imageId', attributes, manifest);
	const imageUrl = checkAttr('imageUrl', attributes, manifest);
	const imageCaptionUse = checkAttr('imageCaptionUse', attributes, manifest);
	const imageAspectRatio = checkAttr('imageAspectRatio', attributes, manifest);

	return (
		<>
			<ContainerPanel
				icon={icons.image}
				title={label ?? __('Image', 'eightshift-ui-kit')}
			>
				<MediaPicker
					onChange={({ id, url }) =>
						setAttributes({
							[getAttrKey('imageId', attributes, manifest)]: id,
							[getAttrKey('imageUrl', attributes, manifest)]: url,
						})
					}
					imageId={imageId}
					imageUrl={imageUrl}
					imageMode='cover'
				/>
			</ContainerPanel>

			<ContainerPanel
				icon={icons.componentOptions}
				title={__('Parts', 'eightshift-ui-kit')}
				hidden={hiddenOptions?.caption}
			>
				<Toggle
					icon={icons.imageCaption}
					label={__('Caption', 'eightshift-ui-kit')}
					checked={imageCaptionUse}
					onChange={(value) => setAttributes({ [getAttrKey('imageCaptionUse', attributes, manifest)]: value })}
					hidden={hiddenOptions?.caption}
				/>
			</ContainerPanel>

			<ContainerPanel
				icon={icons.design}
				title={__('Design', 'eightshift-ui-kit')}
				hidden={!additionalControls && hiddenOptions?.aspectRatio}
			>
				<OptionSelect
					icon={icons.aspectRatio}
					label={__('Aspect ratio', 'eightshift-ui-kit')}
					value={imageAspectRatio}
					options={getOption('imageAspectRatio', attributes, manifest).map((option) => {
						const [w, h] = option.value.split('-');

						return {
							...option,
							endIcon: option.value !== 'auto' && (
								<div className='flex size-24 items-center justify-center'>
									<div
										className={clsx(
											'bg-neutral-40 rounded-[0.25rem]',
											parseInt(w) > parseInt(h) ? 'max-h-full w-full' : 'h-full max-w-full',
											manifest.tailwind.options.imageAspectRatio.twClasses[option.value],
										)}
									></div>
								</div>
							),
						};
					})}
					onChange={(value) => setAttributes({ [getAttrKey('imageAspectRatio', attributes, manifest)]: value })}
					hidden={hiddenOptions?.aspectRatio}
					type='menu'
					inline
				/>

				{additionalControls}
			</ContainerPanel>
		</>
	);
};
