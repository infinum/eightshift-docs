<?php

/**
 * Post header component template.
 *
 * @package EightshiftUIKit
 */

use EightshiftUIKitVendor\EightshiftLibs\Helpers\Helpers;

$mainSection = Helpers::render('main-section', [
	'mainSectionTitleText' => esc_html(get_the_title()),
	'mainSectionTitleTag' => 'h1',
	'mainSectionTitleSize' => 'h1',
	'mainSectionCaptionText' => __('Posted on', 'eightshift-ui-kit') . ' ' . esc_html(get_the_date()),
	'mainSectionMarginBottom' => 80,
	'mainSectionBreadcrumbsUse' => false,
], 'blocks');

echo Helpers::render('wrapper', [], 'wrapper', true, '', $mainSection),
Helpers::render('image', [
	'imageId' => get_post_thumbnail_id(),
	'imageUrl' => get_the_post_thumbnail_url(),
	'imageCaptionUse' => true,
	'imageCaptionText' => get_the_post_thumbnail_caption(),
	'additionalClass' => [
		'caption' => 'block-inset-x',
	],
]);
