import { useEffect } from 'react';
import { __ } from '@wordpress/i18n';
import { icons } from '@eightshift/ui-components/icons';
import { checkAttr, ManageFileButton, tailwindClasses, getAttrKey } from '@eightshift/frontend-libs-tailwind/scripts';
import { HStack, MediaPlaceholder } from '@eightshift/ui-components';
import Rive, { Alignment, Fit, Layout } from '@rive-app/react-canvas';
import manifest from '../manifest.json';

export const RiveEditor = (attributes) => {
	const { setAttributes, additionalClass } = attributes;

	const riveUrl = checkAttr('riveUrl', attributes, manifest);
	const riveLoop = checkAttr('riveLoop', attributes, manifest);
	const riveAutoplay = checkAttr('riveAutoplay', attributes, manifest);
	const riveFit = checkAttr('riveFit', attributes, manifest);

	if (riveUrl) {
		return (
			<Rive
				src={riveUrl}
				stateMachines='bumpy'
				autoplay={riveAutoplay}
				loop={riveLoop}
				layout={
					new Layout({
						fit: riveFit === 'cover' ? Fit.Cover : Fit.Contain,
						alignment: Alignment.Center,
					})
				}
				className={additionalClass}
			/>
		);
	}

	return (
		<MediaPlaceholder
			icon={icons.animation}
			helpText={__('Rive animation', 'eightshift-ui-kit')}
			size='full'
		>
			<HStack>
				<ManageFileButton
					type='browse'
					onChange={({ id, url }) =>
						setAttributes({
							[getAttrKey('riveId', attributes, manifest)]: id,
							[getAttrKey('riveUrl', attributes, manifest)]: url,
						})
					}
					allowedTypes={['application/octet-stream']}
					kind='rive'
				/>

				<ManageFileButton
					type='upload'
					onChange={({ id, url }) =>
						setAttributes({
							[getAttrKey('riveId', attributes, manifest)]: id,
							[getAttrKey('riveUrl', attributes, manifest)]: url,
						})
					}
					allowedTypes={['application/octet-stream']}
					kind='rive'
				/>
			</HStack>
		</MediaPlaceholder>
	);
};
