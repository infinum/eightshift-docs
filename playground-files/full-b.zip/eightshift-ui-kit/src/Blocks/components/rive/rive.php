<?php

/**
 * Rive component.
 *
 * @package EightshiftUIKit
 */

use EightshiftUIKitVendor\EightshiftLibs\Helpers\Helpers;

$additionalClass = $attributes['additionalClass'] ?? '';

$componentJsClass = "js-{$manifest['componentName']}";

$riveUrl = Helpers::checkAttr('riveUrl', $attributes, $manifest);
$riveLoop = Helpers::checkAttr('riveLoop', $attributes, $manifest);
$riveAutoplay = Helpers::checkAttr('riveAutoplay', $attributes, $manifest);
$riveFit = Helpers::checkAttr('riveFit', $attributes, $manifest);

if (!$riveUrl) {
	return;
}
?>

<canvas
	class="<?php echo esc_attr(Helpers::classnames([$componentJsClass, $additionalClass])); ?>"
	data-animation="<?php echo esc_url($riveUrl); ?>"
	data-fit="<?php echo esc_attr($riveFit); ?>"

	<?php if ($riveAutoplay) { ?>
		data-autoplay="true"
	<?php } ?>

	<?php if ($riveLoop) { ?>
		data-loop="true"
	<?php } ?>
>
</canvas>
