import { convert, hexToRGB, OKLCH, RGBToHex, sRGB } from '@texel/color';
import domReady from '@wordpress/dom-ready';
import Color from 'colorjs.io';
import { Pane } from 'tweakpane';

domReady(() => {
	if (!document.querySelector('.js-es-uic-tweaker')) {
		return;
	}

	const pane = new Pane({
		title: 'KitTweaker v1.0',
	});

	// Get css variables from body
	const bodyStyles = window.getComputedStyle(document.body);

	const colorNames = [
		'--color-primary-5',
		'--color-primary-10',
		'--color-primary-20',
		'--color-primary-30',
		'--color-primary-40',
		'--color-primary-50',
		'--color-primary-60',
		'--color-primary-70',
		'--color-primary-80',
		'--color-primary-90',
		'--color-neutral-5',
		'--color-neutral-20',
		'--color-neutral-30',
		'--color-neutral-40',
		'--color-neutral-50',
		'--color-neutral-60',
		'--color-neutral-80',
		'--color-error-10',
		'--color-error-30',
		'--color-error-50',
		'--color-error-80',
	];

	const colorShades = {};

	colorNames.forEach((colorName) => {
		const rawColor = bodyStyles.getPropertyValue(colorName);

		if (rawColor.includes('oklch')) {
			const rgb = convert(
				rawColor
					.replace('oklch(', '')
					.replace(')', '')
					.replace('%', '')
					.split(' ')
					.map((i, index) => (index === 0 ? i / 100 : i)),
				OKLCH,
				sRGB,
			);

			colorShades[colorName.replace('--color-', '')] = `${RGBToHex(rgb)}`;
		} else {
			const rawRgb = new Color(rawColor).to('sRGB');

			colorShades[colorName.replace('--color-', '')] = rawRgb.toString({ format: 'hex' });
		}
	});

	const folderPrimary = pane.addFolder({
		title: 'Colors',
		expanded: false,
	});

	Object.entries(colorShades).forEach(([key, value]) => {
		const binding = folderPrimary.addBinding(colorShades, key);

		binding.on('change', ({ value }) => {
			const [l, c, h] = convert(hexToRGB(value), sRGB, OKLCH);
			document.body.style.setProperty(`--color-${key}`, `oklch(${l * 100}% ${c} ${h})`);
		});
	});
});
