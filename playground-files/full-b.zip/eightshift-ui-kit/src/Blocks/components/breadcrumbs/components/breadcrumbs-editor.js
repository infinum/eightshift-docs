import { __ } from '@wordpress/i18n';
import manifest from './../manifest.json';
import { JsxSvg } from '@eightshift/ui-components/icons';
import { clsx } from '@eightshift/ui-components/utilities';

export const BreadcrumbsEditor = ({ breadcrumbsNoPadding, additionalClass }) => (
	<div
		className={clsx(
			'text-neutral-80 flex flex-wrap gap-8',
			!breadcrumbsNoPadding && 'block-inset-x py-12 sm:py-16',
			additionalClass,
		)}
	>
		<JsxSvg svg={manifest.resources.icons.home} />
		<JsxSvg
			svg={manifest.resources.icons.chevron}
			className='text-neutral-60 pointer-events-none select-none'
		/>
		&hellip;
	</div>
);
