<?php

/**
 * Breadcrumbs component.
 *
 * @package EightshiftUIKit
 */

use EightshiftUIKitVendor\EightshiftLibs\Helpers\Helpers;

global $post;

$breadcrumbsNoPadding = $attributes['breadcrumbsNoPadding'] ?? false;
$additionalClass = $attributes['additionalClass'] ?? '';

if (is_404()) {
	return;
}

$isHome = is_home() || is_front_page();

$interimPages = [];

// phpcs:ignore Squiz.NamingConventions.ValidVariableName.MemberNotCamelCaps
if (!$isHome && $post->post_parent) {
	$parentId = $post->post_parent; // phpcs:ignore Squiz.NamingConventions.ValidVariableName.MemberNotCamelCaps
	$breadcrumbsShowHome = false;

	while ($parentId) {
		$currentPage = get_post($parentId);
		$interimPages[] = $currentPage;
		$parentId = $currentPage->post_parent; // phpcs:ignore Squiz.NamingConventions.ValidVariableName.MemberNotCamelCaps
	}
}

$chevronIcon = str_replace('<svg', '<svg class="text-neutral-60 select-none pointer-events-none"', $manifest['resources']['icons']['chevron']);

$classes = Helpers::classnames([
	'flex flex-wrap gap-8 text-neutral-80',
	$breadcrumbsNoPadding ? '' : 'py-12 sm:py-16 block-inset-x',
	$additionalClass,
]);
?>

<div class="<?php echo esc_attr($classes); ?>">
	<a
		class="hover:text-primary-60 focus-visible:text-primary-60 focus-visible:outline-3 outline-offset-3 outline-primary-50 rounded-xs transition"
		href="<?php echo esc_url(get_bloginfo('url')) ?>"
	>
		<?php
		// phpcs:ignore Eightshift.Security.HelpersEscape.OutputNotEscaped
		echo $manifest['resources']['icons']['home'];
		?>
	</a>

	<?php
	if (!$isHome && count($interimPages) > 0) {
		// phpcs:ignore Eightshift.Security.HelpersEscape.OutputNotEscaped
		echo $chevronIcon;
	}
	?>

	<?php if (!$isHome && ($interimPages[count($interimPages) - 1] ?? false)) { ?>
		<a
			class="underline underline-offset-3 hover:text-primary-60 focus-visible:text-primary-60 focus-visible:outline-3 outline-offset-3 outline-primary-50 rounded-xs transition"
			href="<?php echo esc_url(get_the_permalink($interimPages[count($interimPages) - 1]->ID)); ?>"
		>
			<?php echo wp_kses_post($interimPages[count($interimPages) - 1]->post_title) ?>
		</a>
	<?php } ?>

	<?php if (count($interimPages) > 1) { ?>
		<?php
		// phpcs:ignore Eightshift.Security.HelpersEscape.OutputNotEscaped
		echo $chevronIcon;
		?>

		&hellip;
	<?php } ?>

	<?php
		// phpcs:ignore Eightshift.Security.HelpersEscape.OutputNotEscaped
		echo $chevronIcon;
	?>

	<span class="select-none basis-full sm:basis-auto">
		<?php echo wp_kses_post(get_the_title()); ?>
	</span>
</div>
