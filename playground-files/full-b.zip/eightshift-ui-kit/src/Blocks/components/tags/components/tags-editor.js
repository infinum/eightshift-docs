import { __ } from '@wordpress/i18n';
import { RichText } from '@wordpress/block-editor';
import { checkAttr, getAttrKey, tailwindClasses } from '@eightshift/frontend-libs-tailwind/scripts';
import { Button, Draggable, DraggableHandle, ItemCollection } from '@eightshift/ui-components';
import { icons } from '@eightshift/ui-components/icons';
import manifest from '../manifest.json';

export const TagsEditor = (attributes) => {
	const { setAttributes, additionalClass, placeholder = __('Add text', 'eightshift-ui-kit') } = attributes;

	const tagsUse = checkAttr('tagsUse', attributes, manifest);
	const tagsContent = checkAttr('tagsContent', attributes, manifest);

	if (!tagsUse) {
		return null;
	}

	return (
		<div className={tailwindClasses('base', attributes, manifest, additionalClass)}>
			<Draggable
				items={tagsContent}
				onChange={(value) => setAttributes({ [getAttrKey('tagsContent', attributes, manifest)]: value })}
				className='contents'
			>
				{(item) => {
					const { text, updateData, deleteItem } = item;

					return (
						<div className={tailwindClasses('tag', attributes, manifest)}>
							<DraggableHandle />

							<RichText
								className={tailwindClasses('base', attributes, manifest)}
								placeholder={placeholder}
								value={text}
								onChange={(value) => updateData({ text: value })}
								allowedFormats={[]}
								deleteEnter
							/>

							<Button
								size='small'
								type='dangerGhost'
								icon={icons.trash}
								onPress={deleteItem}
							/>
						</div>
					);
				}}
			</Draggable>

			<Button
				size='small'
				icon={icons.add}
				onPress={() =>
					setAttributes({ [getAttrKey('tagsContent', attributes, manifest)]: [...tagsContent, { text: '' }] })
				}
				aria-label={tagsContent?.length > 1 && __('Add a tag', 'eightshift-ui-kit')}
				tooltip={tagsContent?.length > 1}
			>
				{tagsContent?.length < 1 && __('Tag', 'eightshift-ui-kit')}
			</Button>
		</div>
	);
};
