import { __ } from '@wordpress/i18n';
import { checkAttr, getAttrKey, getHiddenOptions } from '@eightshift/frontend-libs-tailwind/scripts';
import { InputField, Spacer, Toggle, VStack } from '@eightshift/ui-components';
import { icons } from '@eightshift/ui-components/icons';
import manifest from '../manifest.json';

export const WrapperAdvancedOptions = ({ attributes, setAttributes }) => {
	const wrapperNoControls = checkAttr('wrapperNoControls', attributes, manifest);
	const wrapperHide = checkAttr('wrapperHide', attributes, manifest);
	const wrapperId = checkAttr('wrapperId', attributes, manifest);
	const wrapperDisabledOptions = checkAttr('wrapperDisabledOptions', attributes, manifest);

	const hiddenOptions = getHiddenOptions(wrapperDisabledOptions);

	if (wrapperNoControls || wrapperDisabledOptions === 'all') {
		return null;
	}

	return (
		<>
			<Spacer size='m' />

			<Toggle
				icon={icons.hide}
				label={__('Hide block', 'eightshift-ui-kit')}
				checked={wrapperHide}
				onChange={(value) => setAttributes({ [getAttrKey('wrapperHide', attributes, manifest)]: value })}
				hidden={hiddenOptions?.hide}
			/>

			<Spacer
				size='m'
				hidden={hiddenOptions?.id}
			/>

			<InputField
				icon={icons.id}
				label={__('Unique identifier', 'eightshift-ui-kit')}
				value={wrapperId}
				onChange={(value) => setAttributes({ [getAttrKey('wrapperId', attributes, manifest)]: value })}
				className='es-uic-font-mono'
				hidden={hiddenOptions?.id}
			/>
		</>
	);
};
