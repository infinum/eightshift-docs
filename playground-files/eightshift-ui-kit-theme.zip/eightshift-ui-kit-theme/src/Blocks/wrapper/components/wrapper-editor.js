import { checkAttr, tailwindClasses } from '@eightshift/frontend-libs-tailwind/scripts';
import manifest from './../manifest.json';

export const WrapperEditor = ({ attributes, children }) => {
	const wrapperUse = checkAttr('wrapperUse', attributes, manifest);
	const wrapperBackground = checkAttr('wrapperBackground', attributes, manifest);

	const copiedAttributes = { ...attributes };

	if (!wrapperUse) {
		return children;
	}

	let extraProps = {};

	if (wrapperBackground?.startsWith('#')) {
		extraProps.style = { '--bg-color': wrapperBackground };

		copiedAttributes.wrapperBackground = '_custom';
	}

	return (
		<div
			className={tailwindClasses('base', copiedAttributes, manifest)}
			{...extraProps}
		>
			{children}
		</div>
	);
};
