import { __ } from '@wordpress/i18n';
import { checkAttr, getAttrKey, getHiddenOptions, getOption } from '@eightshift/frontend-libs-tailwind/scripts';
import {
	BaseControl,
	ButtonGroup,
	ColorPicker,
	ColorSwatch,
	ContainerPanel,
	OptionSelect,
	SolidColorPicker,
	TriggeredPopover,
} from '@eightshift/ui-components';
import { icons } from '@eightshift/ui-components/icons';
import manifest from './../manifest.json';

export const WrapperOptions = ({ attributes, setAttributes }) => {
	const wrapperUse = checkAttr('wrapperUse', attributes, manifest);
	const wrapperNoControls = checkAttr('wrapperNoControls', attributes, manifest);
	const wrapperBackground = checkAttr('wrapperBackground', attributes, manifest);
	const wrapperBackgroundGradient = checkAttr('wrapperBackgroundGradient', attributes, manifest);
	const wrapperDisabledOptions = checkAttr('wrapperDisabledOptions', attributes, manifest);

	const hiddenOptions = getHiddenOptions(wrapperDisabledOptions);

	if (!wrapperUse || wrapperNoControls || wrapperDisabledOptions === 'all' || hiddenOptions?.backgroundType) {
		return null;
	}

	const colorOptions = getOption('wrapperBackground', attributes, manifest, true);

	let backgroundType = 'none';

	if (wrapperBackground.startsWith('#')) {
		backgroundType = 'custom';
	} else if (wrapperBackground === '_gradient') {
		backgroundType = 'projectGradient';
	} else if (wrapperBackground?.length > 0) {
		backgroundType = 'project';
	}

	return (
		<ContainerPanel className='es:py-2.5'>
			<BaseControl
				icon={icons.backgroundType}
				label={__('Block background', 'eightshift-ui-kit')}
				hidden={hiddenOptions?.backgroundType}
				inline
			>
				<ButtonGroup>
					<OptionSelect
						aria-label={__('Background type', 'eightshift-ui-kit')}
						value={backgroundType}
						options={[
							{ label: __('None', 'eightshift-ui-kit'), value: 'none', separator: 'below' },
							{ label: __('Project', 'eightshift-ui-kit'), endIcon: icons.paletteColor, value: 'project' },
							{
								label: __('Custom', 'eightshift-ui-kit'),
								endIcon: icons.eyedropper,
								value: 'custom',
								separator: 'below',
							},
							{ label: __('Gradient', 'eightshift-ui-kit'), endIcon: icons.gradient, value: 'projectGradient' },
						]}
						onChange={(value) => {
							let newValue = '';
							let gradientValue = 'none';

							if (value === 'project') {
								newValue = colorOptions[0].slug;
							}

							if (value === 'custom') {
								newValue = colorOptions[0].color;
							}

							if (value === 'projectGradient') {
								newValue = '_gradient';
								gradientValue = 'blue';
							}

							return setAttributes({
								[getAttrKey('wrapperBackground', attributes, manifest)]: newValue,
								[getAttrKey('wrapperBackgroundGradient', attributes, manifest)]: gradientValue,
							});
						}}
						type='menu'
						tooltip
						inline
					/>
					<ColorPicker
						aria-label={__('Project color', 'eightshift-ui-kit')}
						colors={colorOptions}
						onChange={(value) => setAttributes({ [getAttrKey('wrapperBackground', attributes, manifest)]: value })}
						value={wrapperBackground}
						hidden={backgroundType !== 'project'}
						noColorGroups
						tooltip
					/>
					<TriggeredPopover
						triggerButtonIcon={<ColorSwatch color={wrapperBackground} />}
						hidden={backgroundType !== 'custom'}
					>
						<SolidColorPicker
							value={wrapperBackground}
							onChange={(value) => setAttributes({ [getAttrKey('wrapperBackground', attributes, manifest)]: value })}
							noAdvancedOptions
						/>
					</TriggeredPopover>
					<OptionSelect
						aria-label={__('Gradient', 'eightshift-ui-kit')}
						value={wrapperBackgroundGradient}
						options={getOption('wrapperBackgroundGradient', attributes, manifest).map((item) => ({
							...item,
							icon: (
								<ColorSwatch
									className={manifest.tailwind.options.wrapperBackgroundGradient.twClasses[item.value]}
									customGradient
								/>
							),
						}))}
						onChange={(value) =>
							setAttributes({ [getAttrKey('wrapperBackgroundGradient', attributes, manifest)]: value })
						}
						type='menu'
						hidden={backgroundType !== 'projectGradient'}
						noTriggerLabel
						tooltip
					/>
				</ButtonGroup>
			</BaseControl>
		</ContainerPanel>
	);
};
