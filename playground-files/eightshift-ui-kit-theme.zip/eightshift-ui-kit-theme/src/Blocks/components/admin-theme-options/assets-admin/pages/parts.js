import { __ } from '@wordpress/i18n';
import { Select, OptionsPanel, OptionsPanelSection, Spacer, OptionsPanelIntro } from '@eightshift/ui-components';
import { icons } from '@eightshift/ui-components/icons';
import { useContext } from '@wordpress/element';
import { EsThemeOptionsContext } from '../theme-options-page';

export const Parts = ({ patterns }) => {
	const { settings, updateSettings } = useContext(EsThemeOptionsContext);

	return (
		<>
			<OptionsPanel
				title={__('Patterns', 'eightshift-ui-kit')}
				subtitle={__('Header, footer, 404, ...', 'eightshift-ui-kit')}
			>
				<OptionsPanelSection>
					<Select
						label={__('Header', 'eightshift-ui-kit')}
						icon={icons.header}
						value={settings?.header}
						onChange={(value) => updateSettings({ header: value })}
						options={patterns}
						className='es:w-48'
						simpleValue
						clearable
						inline
					/>

					<Select
						label={__('Footer', 'eightshift-ui-kit')}
						icon={icons.footer}
						value={settings?.footer}
						onChange={(value) => updateSettings({ footer: value })}
						options={patterns}
						className='es:w-48'
						simpleValue
						clearable
						inline
					/>

					<Spacer size='s' />

					<Select
						label={__('404 page', 'eightshift-ui-kit')}
						icon={icons.emptyCircle}
						value={settings?.fourOhFour}
						onChange={(value) => updateSettings({ fourOhFour: value })}
						options={patterns}
						className='es:w-48'
						simpleValue
						clearable
						inline
					/>
				</OptionsPanelSection>
			</OptionsPanel>
		</>
	);
};
