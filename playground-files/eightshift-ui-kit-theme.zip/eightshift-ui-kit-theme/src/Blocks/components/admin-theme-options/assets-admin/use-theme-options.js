import { __ } from '@wordpress/i18n';
import { useState } from '@wordpress/element';
import { toast } from 'sonner';
import apiFetch from '@wordpress/api-fetch';

export const useThemeOptions = (initial) => {
	const [settings, setSettings] = useState(initial);
	const [isLoading, setIsLoading] = useState(false);

	const saveSettings = async () => {
		setIsLoading(true);

		try {
			const { options } = await apiFetch({
				path: '/eightshift-ui-kit/v1/save-theme-options',
				method: 'POST',
				data: settings,
			});

			setSettings(options);

			toast.success(__('Saved successfully', 'eightshift-ui-kit'));
		} catch (error) {
			toast.error(__('Something went wrong while saving', 'eightshift-ui-kit'), {
				description: error.message,
			});
		} finally {
			setIsLoading(false);
		}
	};

	const updateSettings = (modified) => {
		Object.keys(modified).forEach((key) => {
			if (modified[key] === undefined) {
				modified[key] = null;
			}
		});

		setSettings((prev) => ({
			...prev,
			...modified,
		}));
	};

	return {
		isLoading,
		settings,
		saveSettings,
		setSettings,
		updateSettings,
	};
};
