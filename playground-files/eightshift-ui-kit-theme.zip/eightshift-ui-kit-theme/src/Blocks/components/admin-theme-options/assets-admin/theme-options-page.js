// Based on https://developer.wordpress.org/news/2024/03/26/how-to-use-wordpress-react-components-for-plugin-pages/

import { Toaster } from 'sonner';
import { __ } from '@wordpress/i18n';
import {
	Button,
	OptionsPanelHeader,
	Tabs,
	TabList,
	Tab,
	TabPanel,
	VStack,
	OptionsPanelIntro,
	HStack,
	Toggle,
	OptionsPanel,
	OptionsPanelSection,
} from '@eightshift/ui-components';
import { Parts } from './pages/parts';
import { icons } from '@eightshift/ui-components/icons';
import { createContext } from '@wordpress/element';
import { useThemeOptions } from './use-theme-options';
import { useSearchParams } from 'react-router';

export const EsThemeOptionsContext = createContext(null);

export const ThemeOptionsPage = ({ title = __('Theme options', 'eightshift-ui-kit'), initial, patterns }) => {
	const themeOptions = useThemeOptions(initial);
	const { isLoading, settings, updateSettings, saveSettings } = themeOptions;

	const [searchParams, setSearchParams] = useSearchParams();
	const page = searchParams.get('es-page') || 'dashboard';

	const navigateTo = (newPage = 'dashboard') => {
		const newParams = new URLSearchParams(searchParams);

		if (newPage === 'dashboard') {
			newParams.delete('es-page');
		} else {
			newParams.set('es-page', newPage);
		}

		setSearchParams(newParams);
	};

	const renderRoute = () => {
		if (page === 'lorem') {
			return (
				<>
					<OptionsPanelHeader
						title={__('Additional settings', 'eightshift-ui-kit')}
						actions={
							<HStack>
								<Button
									icon={icons.arrowLeft}
									onPress={() => navigateTo()}
								>
									{__('Back', 'eightshift-ui-kit')}
								</Button>

								<Button
									onPress={() => saveSettings()}
									disabled={isLoading}
									icon={isLoading ? icons.moreH : icons.save}
								>
									{isLoading ? __('Saving...', 'eightshift-ui-kit') : __('Save', 'eightshift-ui-kit')}
								</Button>
							</HStack>
						}
					/>

					<OptionsPanel title={__('Experimental options', 'eightshift-ui-kit')}>
						<OptionsPanelSection>
							<Toggle
								icon={icons.color}
								label={__('Color customizer', 'eightshift-ui-kit')}
								checked={settings?.colorCustomizer}
								onChange={(value) => updateSettings({ colorCustomizer: value })}
							/>
						</OptionsPanelSection>
					</OptionsPanel>
				</>
			);
		}

		if (page === 'dashboard') {
			return (
				<>
					<OptionsPanelHeader
						title={title}
						actions={
							<HStack>
								<Button
									icon={icons.experiment}
									onPress={() => navigateTo('lorem')}
									type='ghost'
									tooltip={__('Try a demo page', 'eightshift-ui-kit')}
								/>

								<Button
									onPress={() => saveSettings()}
									disabled={isLoading}
									icon={isLoading ? icons.moreH : icons.save}
								>
									{isLoading ? __('Saving...', 'eightshift-ui-kit') : __('Save', 'eightshift-ui-kit')}
								</Button>
							</HStack>
						}
					/>

					<Tabs vertical>
						<TabList>
							<Tab
								icon={icons.wrench}
								label={__('Parts', 'eightshift-ui-kit')}
							/>
						</TabList>
						<TabPanel>
							<Parts patterns={patterns} />
						</TabPanel>
					</Tabs>
				</>
			);
		}

		return (
			<VStack className='es:items-center'>
				<OptionsPanelIntro
					title='404'
					subtitle={__('Whoa! Nothing to see here 👀', 'eightshift-ui-kit')}
					className='es:text-center'
				/>

				<Button
					onPress={() => navigateTo()}
					icon={icons.arrowLeft}
				>
					{__('Settings home', 'eightshift-ui-kit')}
				</Button>
			</VStack>
		);
	};

	return (
		<>
			<EsThemeOptionsContext.Provider value={themeOptions}>{renderRoute()}</EsThemeOptionsContext.Provider>

			<Toaster richColors />
		</>
	);
};
