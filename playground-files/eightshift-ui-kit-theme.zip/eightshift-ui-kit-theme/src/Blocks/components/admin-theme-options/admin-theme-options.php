<?php

/**
 * Theme options settings screen component template.
 *
 * @package EightshiftUIKit
 */

use EightshiftUIKit\ThemeOptions\ThemeOptions;

$patterns = wp_json_encode(ThemeOptions::getPatterns());

$initialSettings = ThemeOptions::get();
$initialSettings = wp_json_encode($initialSettings);
?>

<input type="hidden" id="es-pattern-data" value="<?php echo esc_attr($patterns); ?>">
<input type="hidden" id="es-initial-settings" value="<?php echo esc_attr($initialSettings); ?>">

<div class="wrap es:css-reset" id="es-theme-options">
	<?php echo esc_html__('Loading...', 'eightshift-ui-kit'); ?>
</div>
