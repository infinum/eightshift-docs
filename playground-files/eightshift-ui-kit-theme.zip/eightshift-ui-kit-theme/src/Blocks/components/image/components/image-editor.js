import { __ } from '@wordpress/i18n';
import { checkAttr, getAttrKey, tailwindClasses } from '@eightshift/frontend-libs-tailwind/scripts';
import { RichText } from '@wordpress/block-editor';
import { ImagePlaceholder } from '@eightshift/ui-components';
import manifest from './../manifest.json';

export const ImageEditor = (attributes) => {
	const { additionalClass, setAttributes } = attributes;

	const imageUrl = checkAttr('imageUrl', attributes, manifest);
	const imageUse = checkAttr('imageUse', attributes, manifest);
	const imageCaptionUse = checkAttr('imageCaptionUse', attributes, manifest);
	const imageCaptionText = checkAttr('imageCaptionText', attributes, manifest);

	if (!imageUse) {
		return null;
	}

	const image = (
		<>
			{imageUrl && (
				<picture className={additionalClass?.picture ?? ''}>
					<img
						className={tailwindClasses('base', attributes, manifest, additionalClass?.image ?? additionalClass)}
						src={imageUrl}
					/>
				</picture>
			)}

			{!imageUrl && (
				<ImagePlaceholder
					style='simple'
					size='large'
					className={additionalClass?.imagePlaceholder}
				/>
			)}
		</>
	);

	if (!imageCaptionUse) {
		return image;
	}

	return (
		<figure>
			{image}

			<RichText
				identifier={getAttrKey('imageCaptionText', attributes, manifest)}
				className={tailwindClasses('caption', attributes, manifest, additionalClass?.caption)}
				placeholder={__('Add caption', 'eightshift-ui-kit')}
				value={imageCaptionText}
				onChange={(value) => setAttributes({ [getAttrKey('imageCaptionText', attributes, manifest)]: value })}
				allowedFormats={['core/bold', 'core/link', 'core/italic']}
				tagName='figcaption'
				deleteEnter
			/>
		</figure>
	);
};
