import { __ } from '@wordpress/i18n';
import { getOption, checkAttr, getAttrKey, getHiddenOptions } from '@eightshift/frontend-libs-tailwind/scripts';
import { ComponentToggle, HStack, OptionSelect } from '@eightshift/ui-components';
import { icons } from '@eightshift/ui-components/icons';
import { HeadingTagPicker } from '../../../assets/scripts/shared';
import manifest from './../manifest.json';

export const HeadingOptions = (attributes) => {
	const { setAttributes, hideOptions, additionalControls, ...rest } = attributes;

	const hiddenOptions = getHiddenOptions(hideOptions);

	const headingUse = checkAttr('headingUse', attributes, manifest);
	const headingSize = checkAttr('headingSize', attributes, manifest);
	const headingTag = checkAttr('headingTag', attributes, manifest);

	return (
		<ComponentToggle
			label={manifest.title}
			icon={icons.heading}
			onChange={(value) => setAttributes({ [getAttrKey('headingUse', attributes, manifest)]: value })}
			useComponent={headingUse}
			{...rest}
		>
			<HStack>
				<OptionSelect
					aria-label={__('Font size', 'eightshift-ui-kit')}
					options={getOption('headingSize', attributes, manifest)}
					onChange={(value) => setAttributes({ [getAttrKey('headingSize', attributes, manifest)]: value })}
					value={headingSize}
					hidden={hiddenOptions?.size}
					type='menu'
				/>

				<HeadingTagPicker
					value={headingTag}
					onChange={(value) => setAttributes({ [getAttrKey('headingTag', attributes, manifest)]: value })}
					hidden={hiddenOptions?.headingLevel}
				/>

				{additionalControls}
			</HStack>
		</ComponentToggle>
	);
};
