<?php

/**
 * Tags component.
 *
 * @package EightshiftUIKit
 */

use EightshiftUIKitVendor\EightshiftLibs\Helpers\Helpers;

$additionalClass = $attributes['additionalClass'] ?? '';

$tagsUse = Helpers::checkAttr('tagsUse', $attributes, $manifest);
$tagsContent = Helpers::checkAttr('tagsContent', $attributes, $manifest);

if (!$tagsUse || empty($tagsContent)) {
	return;
}
?>

<div class="<?php echo esc_attr(Helpers::tailwindClasses('base', $attributes, $manifest, $additionalClass)); ?>">
	<?php foreach ($tagsContent as $tagData) {
		if (empty($tagData['text'])) {
			continue;
		}
		?>
		<div class="<?php echo esc_attr(Helpers::tailwindClasses('tag', $attributes, $manifest)); ?>">
			<?php echo wp_kses_post($tagData['text']); ?>
		</div>
	<?php } ?>
</div>
