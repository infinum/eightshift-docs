import 'vidstack/player';
import 'vidstack/player/ui';
import 'vidstack/icons';
