import { __ } from '@wordpress/i18n';
import {
	getOption,
	checkAttr,
	getAttrKey,
	props,
	getOptions,
	wpSearchRoute,
	getHiddenOptions,
} from '@eightshift/frontend-libs-tailwind/scripts';
import { IconOptions } from '../../icon/components/icon-options';
import { ContainerPanel, InputField, LinkInput, OptionSelect, Spacer, Toggle } from '@eightshift/ui-components';
import { icons } from '@eightshift/ui-components/icons';
import manifest from './../manifest.json';

export const ButtonOptions = (attributes) => {
	const { setAttributes, hideOptions } = attributes;

	const hiddenOptions = getHiddenOptions(hideOptions);

	const buttonId = checkAttr('buttonId', attributes, manifest);
	const buttonAriaLabel = checkAttr('buttonAriaLabel', attributes, manifest);
	const buttonUrl = checkAttr('buttonUrl', attributes, manifest);
	const buttonIsAnchor = checkAttr('buttonIsAnchor', attributes, manifest);
	const buttonIsNewTab = checkAttr('buttonIsNewTab', attributes, manifest);
	const buttonVariant = checkAttr('buttonVariant', attributes, manifest);
	const buttonLabelUse = checkAttr('buttonLabelUse', attributes, manifest);

	const prefixedIconUse = attributes.prefix + 'IconUse';

	let buttonConfig = 'iconLabel';

	if (!buttonLabelUse) {
		buttonConfig = 'iconOnly';
	}

	if (!attributes[prefixedIconUse]) {
		buttonConfig = 'labelOnly';
	}

	const variantOptions = getOption('buttonVariant', attributes, manifest);

	return (
		<>
			<ContainerPanel
				icon={icons.design}
				title={__('Design', 'eightshift-ui-kit')}
				hidden={hiddenOptions?.variant && hiddenOptions?.icon && hiddenOptions?.label}
			>
				<OptionSelect
					icon={icons.componentOptions}
					label={__('Variant', 'eightshift-ui-kit')}
					value={buttonConfig}
					options={[
						{
							label: __('Icon and label', 'eightshift-ui-kit'),
							value: 'iconLabel',
						},
						{
							label: __('Icon only', 'eightshift-ui-kit'),
							value: 'iconOnly',
						},
						{
							label: __('Label only', 'eightshift-ui-kit'),
							value: 'labelOnly',
						},
					]}
					onChange={(value) => {
						if (value === 'iconLabel') {
							setAttributes({
								[getAttrKey('buttonLabelUse', attributes, manifest)]: true,
								[prefixedIconUse]: true,
							});
						} else if (value === 'iconOnly') {
							setAttributes({ [getAttrKey('buttonLabelUse', attributes, manifest)]: false, [prefixedIconUse]: true });
						} else {
							setAttributes({ [getAttrKey('buttonLabelUse', attributes, manifest)]: true, [prefixedIconUse]: false });
						}
					}}
					type='menu'
					inline
				/>

				<OptionSelect
					icon={icons[variantOptions.find((item) => item.value === buttonVariant)?.endIcon ?? 'buttonGhost']}
					label={__('Style', 'eightshift-ui-kit')}
					value={buttonVariant}
					onChange={(value) => setAttributes({ [getAttrKey('buttonVariant', attributes, manifest)]: value })}
					options={variantOptions}
					type='menu'
					inline
				/>
			</ContainerPanel>

			<ContainerPanel
				hidden={!attributes[prefixedIconUse] || hiddenOptions?.icon}
				icon={icons.iconGeneric}
				title={__('Icon', 'eightshift-ui-kit')}
			>
				<IconOptions
					{...props('icon', attributes, {
						options: getOptions(attributes, manifest),
					})}
					hideOptions='size'
					hidden={!attributes[prefixedIconUse] || hiddenOptions?.icon}
					controlOnly
				/>
			</ContainerPanel>

			<ContainerPanel
				icon={icons.pointerHand}
				title={__('Interactivity', 'eightshift-ui-kit')}
				startOpen
				closable
				hidden={hiddenOptions?.link}
			>
				<LinkInput
					icon={buttonIsAnchor ? icons.globeAnchor : icons.globe}
					url={buttonUrl}
					onChange={({ url, isAnchor }) => {
						setAttributes({
							[getAttrKey('buttonUrl', attributes, manifest)]: url,
							[getAttrKey('buttonIsAnchor', attributes, manifest)]: isAnchor ?? false,
						});
					}}
					fetchSuggestions={wpSearchRoute}
				/>

				<Spacer hidden={hiddenOptions?.link || hiddenOptions?.newTab} />

				<Toggle
					icon={icons.newTab}
					label={__('Open in new tab', 'eightshift-ui-kit')}
					checked={buttonIsNewTab}
					onChange={(value) => setAttributes({ [getAttrKey('buttonIsNewTab', attributes, manifest)]: value })}
					hidden={hiddenOptions?.newTab}
				/>
			</ContainerPanel>

			<ContainerPanel
				title={__('Accessibility', 'eightshift-ui-kit')}
				icon={icons.a11y}
				closable
			>
				<InputField
					icon={icons.ariaLabel}
					label={__('ARIA label', 'eightshift-ui-kit')}
					value={buttonAriaLabel}
					onChange={(value) => setAttributes({ [getAttrKey('buttonAriaLabel', attributes, manifest)]: value })}
					hidden={hiddenOptions?.ariaLabel}
				/>
			</ContainerPanel>

			<ContainerPanel
				title={__('Advanced', 'eightshift-ui-kit')}
				icon={icons.wrench}
				closable
				hidden={hiddenOptions?.uniqueId}
			>
				<InputField
					icon={icons.id}
					label={__('Unique identifier', 'eightshift-ui-kit')}
					value={buttonId}
					onChange={(value) => setAttributes({ [getAttrKey('buttonId', attributes, manifest)]: value })}
				/>
			</ContainerPanel>
		</>
	);
};
