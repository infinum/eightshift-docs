<?php

/**
 * Share component template.
 *
 * @package EightshiftUIKit
 */

use EightshiftUIKitVendor\EightshiftLibs\Helpers\Helpers;

$shareUse = Helpers::checkAttr('shareUse', $attributes, $manifest);

if (!$shareUse) {
	return;
}

$shareTargets = Helpers::checkAttr('shareTargets', $attributes, $manifest);
$shareMode = Helpers::checkAttr('shareMode', $attributes, $manifest);

$additionalClass = $attributes['additionalClass'] ?? '';

?>
<div
	class="<?php echo esc_attr(Helpers::tailwindClasses('base', $attributes, $manifest, $additionalClass, $manifest['componentJsClass'])); ?>"
	data-mode="<?php echo esc_attr($shareMode); ?>"
>
	<?php
	if ($shareMode === 'share') {
		foreach ($shareTargets as $networkName) {
			$shareUrl = $manifest['networks'][$networkName]['shareUrl'] ?? '';
			$shareUrl = str_replace('POST_TITLE', get_the_title(), $shareUrl);
			$shareUrl = str_replace('POST_URL', get_the_permalink(), $shareUrl);
			$shareUrl = str_replace('POST_FEATURED_IMAGE', get_the_post_thumbnail_url(get_the_ID(), 'large'), $shareUrl);

			echo Helpers::render('button', [
				'buttonLabelUse' => false,
				'buttonIconUse' => true,
				'buttonCustomIcon' => $manifest['networks'][$networkName]['icon'] ?? '',
				'buttonAriaLabel' => $manifest['networks'][$networkName]['title'] ?? '',
				'buttonVariant' => 'tertiary',
				'additionalAttributes' => [
					'data-network' => $networkName,
					'data-share-url' => $shareUrl,
					'data-page-title' => get_the_title(),
					'data-page-url' => get_the_permalink(),
				]
			], '', true);
		}
	} elseif ($shareMode === 'links') {
		foreach ($shareTargets as $networkName) {
			echo Helpers::render('button', [
				'buttonLabelUse' => false,
				'buttonIconUse' => true,
				'buttonCustomIcon' => $manifest['networks'][$networkName]['icon'] ?? '',
				'buttonAriaLabel' => $manifest['networks'][$networkName]['title'] ?? '',
				'buttonUrl' => $manifest['networks'][$networkName]['url'] ?? '',
				'buttonVariant' => 'tertiary',
				'buttonIsNewTab' => true,
			], '', true);
		}
	}
	?>
</div>
