import domReady from '@wordpress/dom-ready';
import manifest from '../manifest.json';
import lottie from 'lottie-web';

domReady(() => {
	const elements = document.querySelectorAll(`.js-${manifest.componentName}`);

	if (!elements.length) {
		return;
	}

	elements.forEach((element) => {
		if ((element?.dataset?.animation ?? '').length < 1) {
			return;
		}

		lottie.loadAnimation({
			container: element,
			renderer: 'svg',
			loop: element.hasAttribute('data-loop'),
			autoplay: element.hasAttribute('data-autoplay'),
			path: element.dataset.animation,
		});
	});
});
