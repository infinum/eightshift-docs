<?php

/**
 * Lottie component.
 *
 * @package EightshiftUIKit
 */

use EightshiftUIKitVendor\EightshiftLibs\Helpers\Helpers;

$additionalClass = $attributes['additionalClass'] ?? '';

$componentJsClass = "js-{$manifest['componentName']}";

$lottieUrl = Helpers::checkAttr('lottieUrl', $attributes, $manifest);
$lottieLoop = Helpers::checkAttr('lottieLoop', $attributes, $manifest);
$lottieAutoplay = Helpers::checkAttr('lottieAutoplay', $attributes, $manifest);

if (!$lottieUrl) {
	return;
}
?>

<div
	class="<?php echo esc_attr(Helpers::classnames([$componentJsClass, $additionalClass])); ?>"
	data-animation="<?php echo esc_url($lottieUrl); ?>"

	<?php if ($lottieAutoplay) { ?>
		data-autoplay="true"
	<?php } ?>

	<?php if ($lottieLoop) { ?>
		data-loop="true"
	<?php } ?>
>
</div>
