<?php

/**
 * Icon component template.
 *
 * @package EightshiftUIKit
 */

use EightshiftUIKitVendor\EightshiftLibs\Helpers\Helpers;

$iconUse = Helpers::checkAttr('iconUse', $attributes, $manifest);

if (!$iconUse) {
	return;
}

$additionalClass = $attributes['additionalClass'] ?? '';
$additionalAttributes = $attributes['additionalAttributes'] ?? '';
$iconCustom = $attributes['iconCustom'] ?? false;

$iconName = Helpers::checkAttr('iconName', $attributes, $manifest);
$iconAriaHidden = Helpers::checkAttr('iconAriaHidden', $attributes, $manifest);

if (!is_string($iconName)) {
	return;
}

if (!isset($manifest['icons'][$iconName])) {
	return;
}

$icon = $iconCustom ?: $manifest['icons'][$iconName];

$className = Helpers::tailwindClasses('base', $attributes, $manifest, $additionalClass);

if (!empty($className)) {
	$icon = str_replace('<svg ', '<svg class="' . esc_attr($className) . '" ', $icon);
}

if ($iconAriaHidden) {
	$icon = str_replace('<svg ', '<svg aria-hidden="true" ', $icon);
} else {
	$iconTitle = '';
	$iconOption = array_filter($manifest['options']['iconName'], fn($option) => $option['value'] === $iconName);

	if (!empty($iconOption)) {
		$iconTitle = reset($iconOption)['label'];
	}

	if (!empty($iconTitle)) {
		$titleTag = '<title>' . esc_html($iconTitle) . '</title>';
		$icon = str_replace('</svg>', $titleTag . '</svg>', $icon);
	}
}

if (!empty($additionalAttributes)) {
	$parsedAttributes = '';

	foreach ($additionalAttributes as $key => $value) {
		$parsedAttributes .= esc_attr("{$key}={$value}");
	}

	$icon = str_replace('<svg ', '<svg ' . $parsedAttributes . ' ', $icon);
}

// phpcs:ignore Eightshift.Security.HelpersEscape.OutputNotEscaped
echo $icon;
