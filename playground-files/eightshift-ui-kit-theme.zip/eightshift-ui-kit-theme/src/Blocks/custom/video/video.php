<?php

/**
 * Video block template.
 *
 * @package EightshiftUIKit
 */

use EightshiftUIKitVendor\EightshiftLibs\Helpers\Helpers;

echo Helpers::render('video', Helpers::props('video', $attributes, [
	'additionalClass' => [
		'base' => Helpers::tailwindClasses('base', $attributes, $manifest),
		'video' => Helpers::tailwindClasses('video', $attributes, $manifest),
		'caption' => Helpers::tailwindClasses('caption', $attributes, $manifest),
	]
]));
