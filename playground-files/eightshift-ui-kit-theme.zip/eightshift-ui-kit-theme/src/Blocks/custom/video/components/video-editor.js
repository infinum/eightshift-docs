import { props, tailwindClasses } from '@eightshift/frontend-libs-tailwind/scripts';
import { VideoEditor as EditorComponent } from '../../../components/video/components/video-editor';
import manifest from '../manifest.json';

export const VideoEditor = ({ attributes, setAttributes }) => {
	return (
		<EditorComponent
			{...props('video', attributes, {
				setAttributes,
				additionalClass: {
					base: tailwindClasses('base', attributes, manifest),
					video: tailwindClasses('video', attributes, manifest),
					caption: tailwindClasses('caption', attributes, manifest),
				},
			})}
		/>
	);
};
