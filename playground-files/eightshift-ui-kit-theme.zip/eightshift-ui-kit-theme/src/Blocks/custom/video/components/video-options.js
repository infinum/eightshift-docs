import { __ } from '@wordpress/i18n';
import { props } from '@eightshift/frontend-libs-tailwind/scripts';
import { VideoOptions as OptionsComponent } from '../../../components/video/components/video-options';
import { Toggle } from '@eightshift/ui-components';
import { icons } from '@eightshift/ui-components/icons';

export const VideoOptions = ({ attributes, setAttributes }) => {
	const { wrapperFullWidth } = attributes;

	return (
		<OptionsComponent
			{...props('video', attributes, { setAttributes })}
			additionalControls={
				<Toggle
					icon={icons.arrowsHorizontal}
					label={__('Full width', 'eightshift-ui-kit')}
					checked={wrapperFullWidth}
					onChange={(value) => setAttributes({ wrapperFullWidth: value })}
				/>
			}
			controlOnly
		/>
	);
};
