<?php

/**
 * Sub-section block.
 *
 * @package EightshiftUIKit
 */

use EightshiftUIKitVendor\EightshiftLibs\Helpers\Helpers;

$subSectionEyebrowText = Helpers::checkAttr('subSectionEyebrowText', $attributes, $manifest);
$subSectionTitleText = Helpers::checkAttr('subSectionTitleText', $attributes, $manifest);
$subSectionParagraphText = Helpers::checkAttr('subSectionParagraphText', $attributes, $manifest);
$subSectionEyebrowUse = Helpers::checkAttr('subSectionEyebrowUse', $attributes, $manifest);
$subSectionParagraphUse = Helpers::checkAttr('subSectionParagraphUse', $attributes, $manifest);
$subSectionTitleSize = Helpers::checkAttr('subSectionTitleSize', $attributes, $manifest);
$subSectionTitleTag = Helpers::checkAttr('subSectionTitleTag', $attributes, $manifest);

if (!$subSectionTitleText) {
	return;
}
?>

<div class="<?php echo esc_attr(Helpers::tailwindClasses('base', $attributes, $manifest)); ?>">
	<div class="<?php echo esc_attr(Helpers::tailwindClasses('content', $attributes, $manifest)); ?>">
		<?php if ($subSectionEyebrowUse && !empty($subSectionEyebrowText)) { ?>
			<p class="<?php echo esc_attr(Helpers::tailwindClasses('eyebrow', $attributes, $manifest)); ?>">
				<?php echo wp_kses_post($subSectionEyebrowText); ?>
			</p>
		<?php } ?>

		<<?php echo esc_attr($subSectionTitleTag); ?>
			class="<?php echo esc_attr(Helpers::tailwindClasses('heading', $attributes, $manifest)); ?>"
		>
			<?php echo wp_kses_post($subSectionTitleText); ?>
		</<?php echo esc_attr($subSectionTitleTag); ?>>

		<?php if ($subSectionParagraphUse && !empty($subSectionParagraphText)) { ?>
			<p class="<?php echo esc_attr(Helpers::tailwindClasses('paragraph', $attributes, $manifest)); ?>">
				<?php echo wp_kses_post($subSectionParagraphText); ?>
			</p>
		<?php } ?>
	</div>

	<?php
	echo Helpers::render('button', Helpers::props('cta', $attributes));
	?>
</div>
