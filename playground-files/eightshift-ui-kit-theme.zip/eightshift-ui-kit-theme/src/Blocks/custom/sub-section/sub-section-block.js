import { SubSectionEditor } from './components/sub-section-editor';
import { SubSectionOptions } from './components/sub-section-options';
import { GutenbergBlock } from '@eightshift/frontend-libs-tailwind/scripts';

export const SubSection = (props) => {
	return (
		<GutenbergBlock
			{...props}
			options={SubSectionOptions}
			editor={SubSectionEditor}
			noOptionsContainer
		/>
	);
};
