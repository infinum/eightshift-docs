import { __ } from '@wordpress/i18n';
import { checkAttr, getAttrKey, getOption, props } from '@eightshift/frontend-libs-tailwind/scripts';
import { OptionSelect, ContainerPanel, Tabs, Tab, TabList, TabPanel, Toggle } from '@eightshift/ui-components';
import { HeadingTagPicker } from '../../../assets/scripts/shared';
import { BlockIcon, icons } from '@eightshift/ui-components/icons';
import { ButtonOptions } from '../../../components/button/components/button-options';
import manifest from '../manifest.json';

export const SubSectionOptions = ({ attributes, setAttributes }) => {
	const subSectionTitleTag = checkAttr('subSectionTitleTag', attributes, manifest);
	const subSectionTitleSize = checkAttr('subSectionTitleSize', attributes, manifest);

	const subSectionCtaUse = checkAttr('subSectionCtaUse', attributes, manifest);
	const subSectionEyebrowUse = checkAttr('subSectionEyebrowUse', attributes, manifest);
	const subSectionParagraphUse = checkAttr('subSectionParagraphUse', attributes, manifest);

	const subSectionMarginTop = checkAttr('subSectionMarginTop', attributes, manifest);
	const subSectionMarginBottom = checkAttr('subSectionMarginBottom', attributes, manifest);

	return (
		<>
			<Tabs type='pillCompactInverse'>
				<TabList className='es:px-4 es:mt-3'>
					<Tab>{__('General', 'eightshift-ui-kit')}</Tab>
					<Tab invisible={!subSectionCtaUse}>{__('Call to action', 'eightshift-ui-kit')}</Tab>
				</TabList>
				<TabPanel className='space-y-0!'>
					<ContainerPanel
						icon={icons.componentGeneric}
						title={__('Parts', 'eightshift-ui-kit')}
					>
						<Toggle
							icon={icons.titleGeneric}
							label={__('Eyebrow', 'eightshift-ui-kit')}
							checked={subSectionEyebrowUse}
							onChange={(value) => setAttributes({ [getAttrKey('subSectionEyebrowUse', attributes, manifest)]: value })}
						/>

						<Toggle
							icon={icons.paragraph}
							label={__('Paragraph', 'eightshift-ui-kit')}
							checked={subSectionParagraphUse}
							onChange={(value) =>
								setAttributes({ [getAttrKey('subSectionParagraphUse', attributes, manifest)]: value })
							}
						/>

						<Toggle
							icon={icons.buttonOutline}
							label={__('Call to action', 'eightshift-ui-kit')}
							checked={subSectionCtaUse}
							onChange={(value) => setAttributes({ [getAttrKey('subSectionCtaUse', attributes, manifest)]: value })}
						/>
					</ContainerPanel>

					<ContainerPanel
						icon={icons.design}
						title={__('Design', 'eightshift-ui-kit')}
					>
						<OptionSelect
							icon={icons.spacingTopIn}
							label={__('Top margin', 'eightshift-ui-kit')}
							value={subSectionMarginTop}
							onChange={(value) => setAttributes({ [getAttrKey('subSectionMarginTop', attributes, manifest)]: value })}
							options={getOption('subSectionMargin', attributes, manifest)}
							type='menu'
							inline
						/>

						<OptionSelect
							icon={icons.spacingBottomIn}
							label={__('Bottom margin', 'eightshift-ui-kit')}
							value={subSectionMarginBottom}
							onChange={(value) =>
								setAttributes({ [getAttrKey('subSectionMarginBottom', attributes, manifest)]: value })
							}
							options={getOption('subSectionMargin', attributes, manifest)}
							type='menu'
							inline
						/>
					</ContainerPanel>

					<ContainerPanel
						icon={<BlockIcon iconName='es-heading' />}
						title={__('Title', 'eightshift-ui-kit')}
						startOpen
						closable
					>
						<HeadingTagPicker
							onChange={(value) => setAttributes({ [getAttrKey('subSectionTitleTag', attributes, manifest)]: value })}
							value={subSectionTitleTag}
							fullSize
						/>

						<OptionSelect
							value={subSectionTitleSize}
							onChange={(value) => setAttributes({ [getAttrKey('subSectionTitleSize', attributes, manifest)]: value })}
							options={getOption('subSectionTitleSize', attributes, manifest)}
							label={__('Font size', 'eightshift-ui-kit')}
							type='menu'
							inline
						/>
					</ContainerPanel>
				</TabPanel>

				<TabPanel className='space-y-0!'>
					<ButtonOptions
						{...props('cta', attributes, {
							setAttributes,
						})}
						hideOptions='variant'
					/>
				</TabPanel>
			</Tabs>
		</>
	);
};
