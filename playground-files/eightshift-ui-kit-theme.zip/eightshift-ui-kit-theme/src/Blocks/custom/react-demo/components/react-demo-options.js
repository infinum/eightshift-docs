import { __ } from '@wordpress/i18n';
import { checkAttr, getAttrKey } from '@eightshift/frontend-libs-tailwind/scripts';
import { ContainerPanel, InputField } from '@eightshift/ui-components';
import { icons } from '@eightshift/ui-components/icons';
import manifest from '../manifest.json';

export const ReactDemoOptions = ({ attributes, setAttributes }) => {
	const reactDemoLabel = checkAttr('reactDemoLabel', attributes, manifest);

	return (
		<ContainerPanel>
			<InputField
				icon={icons.experiment}
				label={__('Demo label', 'react-demo')}
				value={reactDemoLabel}
				onChange={(value) => setAttributes({ [getAttrKey('reactDemoLabel', attributes, manifest)]: value })}
			/>
		</ContainerPanel>
	);
};
