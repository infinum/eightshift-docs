import domReady from '@wordpress/dom-ready';
import { createRoot } from '@wordpress/element';
import { DemoComponent } from './demo-component';
import manifest from '../manifest.json';

domReady(() => {
	const selector = `.js-block-${manifest.blockName}`;
	const elements = document.querySelectorAll(selector);

	if (!elements.length) {
		return;
	}

	elements.forEach((element) => {
		const root = createRoot(element);

		const label = element.getAttribute('data-label');

		element.removeAttribute('data-label');

		root.render(<DemoComponent label={label} />);
	});
});
