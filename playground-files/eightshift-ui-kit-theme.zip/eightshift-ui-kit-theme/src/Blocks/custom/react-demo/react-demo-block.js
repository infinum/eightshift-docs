import { ReactDemoEditor } from './components/react-demo-editor';
import { ReactDemoOptions } from './components/react-demo-options';
import { GutenbergBlock } from '@eightshift/frontend-libs-tailwind/scripts';

export const ReactDemo = (props) => {
	return (
		<GutenbergBlock
			{...props}
			options={ReactDemoOptions}
			editor={ReactDemoEditor}
			noOptionsContainer
		/>
	);
};
