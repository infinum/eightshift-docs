<?php

/**
 * Accordion: Simple item block template.
 *
 * @package EightshiftUIKit
 */

use EightshiftUIKitVendor\EightshiftLibs\Helpers\Helpers;

$blockJsClass = $attributes['blockJsClass'] ?? '';

$uniqueId = Helpers::getUnique();

$panelId = "{$uniqueId}-panel";
$triggerId = "{$uniqueId}-header";

$accordionSimpleItemLabel = Helpers::checkAttr('accordionSimpleItemLabel', $attributes, $manifest);
?>

<details class="<?php echo esc_attr(Helpers::tailwindClasses('base', $attributes, $manifest)); ?>">
	<summary class="<?php echo esc_attr(Helpers::tailwindClasses('trigger', $attributes, $manifest)); ?>">
		<?php
		echo esc_attr($accordionSimpleItemLabel);
		?>

		<div class="<?php echo esc_attr(Helpers::tailwindClasses('icon', $attributes, $manifest)); ?>">
			<?php
			// phpcs:ignore Eightshift.Security.HelpersEscape.OutputNotEscaped
			echo $manifest['resources']['icon'];
			?>
		</div>
	</summary>

	<div class="<?php echo esc_attr(Helpers::tailwindClasses('content-container', $attributes, $manifest)); ?>">
		<?php
		// phpcs:ignore Eightshift.Security.HelpersEscape.OutputNotEscaped
		echo $renderContent;
		?>
	</div>
</details>
