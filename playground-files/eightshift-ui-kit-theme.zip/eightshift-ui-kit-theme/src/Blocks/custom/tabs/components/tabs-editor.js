import { useContext, useEffect } from 'react';
import { __ } from '@wordpress/i18n';
import { RichText, useBlockProps, useInnerBlocksProps } from '@wordpress/block-editor';
import { createBlock } from '@wordpress/blocks';
import { select, dispatch } from '@wordpress/data';
import { icons } from '@eightshift/ui-components/icons';
import { checkAttr, getAttrKey, getUnique, tailwindClasses } from '@eightshift/frontend-libs-tailwind/scripts';
import { TabContext } from '../tab-context';
import { Button } from '@eightshift/ui-components';
import manifest from '../manifest.json';

export const TabsEditor = ({ clientId, attributes, setAttributes, isSelected }) => {
	const { activeTab, setActiveTab } = useContext(TabContext);

	const innerBlocks = select('core/block-editor').getBlock(clientId)?.innerBlocks || [];

	// If no tab is active, make the first tab active.
	if (!activeTab) {
		setActiveTab(innerBlocks?.[0]?.clientId);
	}

	// Prepare the innerBlocks props.
	const blockProps = useBlockProps();
	const innerBlocksProps = useInnerBlocksProps(blockProps, {
		allowedBlocks: ['eightshift-boilerplate/tab'],
		renderAppender: false,
		orientation: 'horizontal',
		template: [['eightshift-boilerplate/tab', {}, [['eightshift-boilerplate/paragraph']]]],
	});

	// If the stored data is not up to date, update it.
	const tabsTabData = checkAttr('tabsTabData', attributes, manifest);

	const innerBlockData = innerBlocks.map((blockData) => ({
		id: blockData?.attributes?.tabId ?? '',
		title: blockData?.attributes?.tabTitle ?? '',
	}));

	if (JSON.stringify(tabsTabData) !== JSON.stringify(innerBlockData)) {
		setAttributes({
			[getAttrKey('tabsTabData', attributes, manifest)]: innerBlockData,
		});
	}

	// Add new tab action.
	const addInnerBlock = () => {
		const innerBlocks = select('core/block-editor').getBlock(clientId)?.innerBlocks || [];

		const block = createBlock(
			'eightshift-boilerplate/tab',
			{
				tabId: getUnique(),
			},
			[createBlock('eightshift-boilerplate/paragraph')],
		);
		dispatch('core/block-editor').insertBlock(block, innerBlocks?.length ?? 0, clientId);

		// Set the active tab after a bit of delay so it gets added.
		setTimeout(() => setActiveTab(block.clientId), 100);
	};
	// remove tab action.
	const removeInnerBlock = (id) => {
		dispatch('core/block-editor').removeBlock(id);
		let index = innerBlocks.findIndex((block) => block.clientId === id);
		setActiveTab(innerBlocks?.[index <= innerBlocks.length - 1 ? index + 1 : 0]?.clientId);
	};

	const resetInnerIds = () => {
		innerBlocks.forEach((block, index) => {
			const newId = getUnique();

			const newData = [...tabsTabData];
			const tabIndex = tabsTabData.findIndex((data) => data.id === block?.attributes?.tabId);

			if (tabIndex !== -1) {
				newData[index] = tabsTabData[tabIndex];
			} else if (typeof newData?.[index] === 'undefined') {
				// on first load block data is empty so to populate data use indexes instead of ids
				newData[index] = {};
			}

			newData[index].id = newId;

			setAttributes({
				[getAttrKey('tabsTabData', attributes, manifest)]: newData,
			});

			dispatch('core/block-editor').updateBlockAttributes(block.clientId, {
				tabId: newId,
				tabTitle: newData[index]?.title ?? '',
			});
		});
	};

	// Refresh IDs to prevent duplication.
	useEffect(resetInnerIds, []);
	useEffect(resetInnerIds, [clientId, innerBlocks?.length]);

	return (
		<div className={tailwindClasses('base', attributes, manifest)}>
			<div className={tailwindClasses('tabListContainer', attributes, manifest)}>
				{innerBlocks.map((block, index) => (
					<div
						key={index}
						className={tailwindClasses('tabListItem', attributes, manifest)}
						aria-selected={activeTab === block.clientId}
						onFocus={() => setActiveTab(block.clientId)}
						onClick={(e) => e.target.focus()}
					>
						<RichText
							identifier={`title-${block.clientId}`}
							value={block?.attributes?.tabTitle}
							onChange={(title) => {
								dispatch('core/block-editor').updateBlockAttributes(block.clientId, {
									tabTitle: title,
								});

								// Update the local state.
								const newData = [...tabsTabData];

								setAttributes({
									[getAttrKey('tabsTabData', attributes, manifest)]: newData,
								});
							}}
							placeholder={__('Tab title', 'eightshift-ui-kit')}
							withoutInteractiveFormatting
							allowedFormats={[]}
						/>

						<Button
							hidden={!isSelected || activeTab !== block.clientId}
							size='small'
							type='dangerGhost'
							icon={icons.trash}
							tooltip={__('Remove', 'eightshift-ui-kit')}
							onPress={() => removeInnerBlock(block.clientId)}
						/>
					</div>
				))}

				<Button
					hidden={innerBlocks.length > 6}
					onPress={addInnerBlock}
					icon={icons.add}
					className='self-center'
					aria-label={__('Add tab', 'eightshift-ui-kit')}
					size='small'
				/>
			</div>

			<div {...innerBlocksProps} />
		</div>
	);
};
