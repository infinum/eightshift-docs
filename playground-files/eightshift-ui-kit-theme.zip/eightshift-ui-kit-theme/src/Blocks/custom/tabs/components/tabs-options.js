import { __ } from '@wordpress/i18n';
import { icons } from '@eightshift/ui-components/icons';
import { checkAttr, getAttrKey } from '@eightshift/frontend-libs-tailwind/scripts';
import { ContainerPanel, Toggle } from '@eightshift/ui-components';
import manifest from '../manifest.json';

export const TabsOptions = ({ clientId, attributes, setAttributes, isSelected }) => {
	const tabsStandalone = checkAttr('tabsStandalone', attributes, manifest);

	return (
		<ContainerPanel>
			<Toggle
				icon={icons.expandXl}
				label={__('Spacing', 'eightshift-boilerplate')}
				checked={tabsStandalone}
				onChange={(value) => {
					setAttributes({ [getAttrKey('tabsStandalone', attributes, manifest)]: value });
				}}
			/>
		</ContainerPanel>
	);
};
