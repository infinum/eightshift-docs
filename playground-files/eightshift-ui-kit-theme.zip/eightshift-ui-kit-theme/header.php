<?php

/**
 * Main header file
 *
 * @package EightshiftUIKit
 */

use EightshiftUIKitVendor\EightshiftLibs\Helpers\Helpers;
use EightshiftUIKit\ThemeOptions\ThemeOptions;

?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<?php
	// Head component.
	echo Helpers::render('head');

	wp_head();
	?>
</head>
<body <?php body_class(); ?>>

<?php
// "Skip to content" anchor link.
echo Helpers::render('skip-link');

// Header reusable block.
ThemeOptions::renderPartial(ThemeOptions::get(ThemeOptions::HEADER));

if (ThemeOptions::get(ThemeOptions::COLOR_CUSTOMIZER)) {
	echo Helpers::render('tweaker');
}

?>

<main class="main-content layout-base selection:bg-primary-50 selection:text-white" id="main-content">
