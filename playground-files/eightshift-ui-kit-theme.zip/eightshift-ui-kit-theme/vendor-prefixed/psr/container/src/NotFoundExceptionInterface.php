<?php
/**
 * @license MIT
 *
 * Modified by eightshift-ui-kit on 15-July-2025 using {@see https://github.com/BrianHenryIE/strauss}.
 */

namespace EightshiftUIKitVendor\Psr\Container;

/**
 * No entry was found in the container.
 */
interface NotFoundExceptionInterface extends ContainerExceptionInterface
{
}
