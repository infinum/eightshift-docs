<?php

/**
 * Class that registers WP-CLI commands used as parent placeholders.
 *
 * @package EightshiftUIKitVendor\EightshiftLibs\Cli\ParentGroups
 *
 * @license MIT
 * Modified by eightshift-ui-kit on 15-July-2025 using {@see https://github.com/BrianHenryIE/strauss}.
 */

declare(strict_types=1);

namespace EightshiftUIKitVendor\EightshiftLibs\Cli\ParentGroups;

use WP_CLI_Command;

/**
 * Execute functionalities on you project like import/export, plugins updates, etc.
 */
class CliRun extends WP_CLI_Command
{
	/**
	 * Cli command name parent constant.
	 */
	public const COMMAND_NAME = 'run';
}
