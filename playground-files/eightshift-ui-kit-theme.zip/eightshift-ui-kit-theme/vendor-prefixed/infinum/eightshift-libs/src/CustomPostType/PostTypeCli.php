<?php

/**
 * Class that registers WP-CLI command for custom post type registration.
 *
 * @package EightshiftLibs\CustomPostType
 *
 * @license MIT
 * Modified by eightshift-ui-kit on 15-July-2025 using {@see https://github.com/BrianHenryIE/strauss}.
 */

declare(strict_types=1);

namespace EightshiftUIKitVendor\EightshiftLibs\CustomPostType;

use EightshiftUIKitVendor\EightshiftLibs\Cli\AbstractCli;
use EightshiftUIKitVendor\EightshiftLibs\Cli\ParentGroups\CliCreate;
use EightshiftUIKitVendor\EightshiftLibs\Helpers\Helpers;

/**
 * Class PostTypeCli
 */
class PostTypeCli extends AbstractCli
{
	/**
	 * Get WP-CLI command parent name
	 *
	 * @return string
	 */
	public function getCommandParentName(): string
	{
		return CliCreate::COMMAND_NAME;
	}

	/**
	 * Get WP-CLI command name
	 *
	 * @return string
	 */
	public function getCommandName(): string
	{
		return 'post-type';
	}

	/**
	 * Define default arguments.
	 *
	 * @return array<string, int|string|boolean>
	 */
	public function getDefaultArgs(): array
	{
		return [
			'label' => 'Product',
			'plural_label' => 'Products',
			'slug' => 'product',
			'rewrite_url' => 'product',
			'rest_endpoint_slug' => 'products',
			'capability' => 'post',
			'menu_position' => 20,
			'menu_icon' => 'dashicons-admin-settings',
		];
	}

	/**
	 * Get WP-CLI command doc
	 *
	 * @return array<string, array<int, array<string, bool|string>>|string>
	 */
	public function getDoc(): array
	{
		return [
			'shortdesc' => 'Create custom post type service class.',
			'synopsis' => [
				[
					'type' => 'assoc',
					'name' => 'label',
					'description' => 'The label of the custom post type to show in WP admin.',
					'optional' => false,
				],
				[
					'type' => 'assoc',
					'name' => 'plural_label',
					'description' => 'The plural label for the custom post type. Used for label generation. If not specified, the plural will be an "s" appended to the singular label.', // phpcs:ignore Generic.Files.LineLength.TooLong
					'optional' => false,
					'default' => $this->getDefaultArg('plural_label'),
				],
				[
					'type' => 'assoc',
					'name' => 'slug',
					'description' => 'The custom post type slug. Example: location.',
					'optional' => false,
				],
				[
					'type' => 'assoc',
					'name' => 'rewrite_url',
					'description' => 'The custom post type url. Example: location.',
					'optional' => false,
				],
				[
					'type' => 'assoc',
					'name' => 'rest_endpoint_slug',
					'description' => 'The name of the custom post type REST-API endpoint slug. Example: locations.',
					'optional' => false,
				],
				[
					'type' => 'assoc',
					'name' => 'capability',
					'description' => 'The default capability for the custom post types. Example: post.',
					'optional' => true,
					'default' => $this->getDefaultArg('capability'),
				],
				[
					'type' => 'assoc',
					'name' => 'menu_position',
					'description' => 'The default menu position for the custom post types. Example: 20.',
					'optional' => true,
					'default' => $this->getDefaultArg('menu_position'),
				],
				[
					'type' => 'assoc',
					'name' => 'menu_icon',
					'description' => 'The default menu icon for the custom post types. Example: dashicons-analytics.',
					'optional' => true,
					'default' => $this->getDefaultArg('menu_icon'),
				],
			],
			'longdesc' => $this->prepareLongDesc("
				## USAGE

				Used to create custom post type for all your custom data.

				## EXAMPLES

				# Create service class:
				$ wp {$this->commandParentName} {$this->getCommandParentName()} {$this->getCommandName()} --label='Jobs' --slug='jobs' --rewrite_url='jobs' --rest_endpoint_slug='jobs'

				## RESOURCES

				Service class will be created from this example:
				https://github.com/infinum/eightshift-libs/blob/develop/src/CustomPostType/PostTypeExample.php
			"),
		];
	}

	/* @phpstan-ignore-next-line */
	public function __invoke(array $args, array $assocArgs)
	{
		$assocArgs = $this->prepareArgs($assocArgs);

		$this->getIntroText($assocArgs);

		// Get Props.
		$label = $this->getArg($assocArgs, 'label');
		$slug = $this->prepareSlug($this->getArg($assocArgs, 'slug'));
		$rewriteUrl = $this->prepareSlug($this->getArg($assocArgs, 'rewrite_url'));
		$restEndpointSlug = $this->prepareSlug($this->getArg($assocArgs, 'rest_endpoint_slug'));
		$capability = $this->getArg($assocArgs, 'capability');
		$menuPosition = $this->getArg($assocArgs, 'menu_position');
		$menuIcon = $this->getArg($assocArgs, 'menu_icon');
		$pluralLabel = $this->getArg($assocArgs, 'plural_label');

		// Get full class name.
		$className = $this->getFileName($slug);
		$className = $className . $this->getClassShortName();

		// Read the template contents, and replace the placeholders with provided variables.
		$class = $this->getExampleTemplate(__DIR__, $this->getClassShortName())
			->renameClassNameWithPrefix($this->getClassShortName(), $className)
			->renameGlobals($assocArgs)
			->searchReplaceString($this->getArgTemplate('slug'), $slug)
			->searchReplaceString($this->getArgTemplate('rewrite_url'), $rewriteUrl)
			->searchReplaceString($this->getArgTemplate('rest_endpoint_slug'), $restEndpointSlug)
			->searchReplaceString($this->getArgTemplate('label'), $label)
			->searchReplaceString($this->getArgTemplate('plural_label'), $pluralLabel);

		if (!empty($capability)) {
			$class->searchReplaceString($this->getArgTemplate('capability'), $capability);
		}

		if (!empty($menuPosition)) {
			$class->searchReplaceString($this->getDefaultArg('menu_position'), $menuPosition);
		}

		if (!empty($menuIcon)) {
			$class->searchReplaceString($this->getArgTemplate('menu_icon'), $menuIcon);
		}

		// Output final class to new file/folder and finish.
		$class->outputWrite(Helpers::getProjectPaths('src', 'CustomPostType'), "{$className}.php", $assocArgs);
	}
}
