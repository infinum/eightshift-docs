<?php

/**
 * Class that registers WP-CLI command for Use WebP Media.
 *
 * @package EightshiftLibs\Media
 *
 * @license MIT
 * Modified by eightshift-ui-kit on 15-July-2025 using {@see https://github.com/BrianHenryIE/strauss}.
 */

declare(strict_types=1);

namespace EightshiftUIKitVendor\EightshiftLibs\Media;

use EightshiftUIKitVendor\EightshiftLibs\Cli\AbstractCli;
use EightshiftUIKitVendor\EightshiftLibs\Cli\ParentGroups\CliRun;
use WP_CLI;

/**
 * Class UseWebPMediaCli
 */
class UseWebPMediaCli extends AbstractCli
{
	/**
	 * Media WebP Trait.
	 */
	use MediaWebPTrait;

	/**
	 * Option name constant.
	 *
	 * @var string
	 */
	public const USE_WEBP_MEDIA_OPTION_NAME = 'es-use-webp-media';

	/**
	 * Get WP-CLI command parent name
	 *
	 * @return string
	 */
	public function getCommandParentName(): string
	{
		return CliRun::COMMAND_NAME;
	}

	/**
	 * Get WP-CLI command name
	 *
	 * @return string
	 */
	public function getCommandName(): string
	{
		return 'use-webp-media';
	}

	/**
	 * Get WP-CLI command doc
	 *
	 * @return array<string, array<int, array<string, bool|string>>|string>
	 */
	public function getDoc(): array
	{
		return [
			'shortdesc' => 'Toggle config flag to use WebP media or not.',
			'longdesc' => $this->prepareLongDesc("
				## USAGE

				Used as a project command to toggle global options flag to use or not to use WebP media on the frontend.

				## EXAMPLES

				# Toggle frontend media to use WebP format.
				$ wp {$this->commandParentName} {$this->getCommandParentName()} {$this->getCommandName()}
			"),
		];
	}

	/* @phpstan-ignore-next-line */
	public function __invoke(array $args, array $assocArgs)
	{
		$assocArgs = $this->prepareArgs($assocArgs);

		$this->getIntroText($assocArgs);

		if (\get_option(self::USE_WEBP_MEDIA_OPTION_NAME)) {
			\update_option(self::USE_WEBP_MEDIA_OPTION_NAME, false, true);

			WP_CLI::success('WebP Media use disabled.');
		} else {
			\update_option(self::USE_WEBP_MEDIA_OPTION_NAME, true, true);

			WP_CLI::success('WebP Media use enabled.');
		}
	}
}
