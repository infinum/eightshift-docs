<?php

/**
 * Projects MenuPositionsInterface interface.
 *
 * Used to define available menu positions in your project.
 *
 * @package EightshiftLibs\Menu
 *
 * @license MIT
 * Modified by eightshift-ui-kit on 15-July-2025 using {@see https://github.com/BrianHenryIE/strauss}.
 */

declare(strict_types=1);

namespace EightshiftUIKitVendor\EightshiftLibs\Menu;

/**
 * Interface MenuPositionsInterface
 */
interface MenuPositionsInterface
{
	/**
	 * Return all menu positions
	 *
	 * @return array<string, mixed> Of menu positions with name and slug.
	 */
	public function getMenuPositions(): array;
}
