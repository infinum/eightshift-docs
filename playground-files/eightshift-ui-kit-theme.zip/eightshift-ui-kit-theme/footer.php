<?php

/**
 * Display footer.
 *
 * @package EightshiftUIKit
 */

use EightshiftUIKit\ThemeOptions\ThemeOptions;

?>

</main>

<footer class="layout-base">
<?php
// Footer reusable block.
ThemeOptions::renderPartial(ThemeOptions::get(ThemeOptions::FOOTER));
?>
</footer>

<?php
wp_footer();
?>
</body>
</html>
